<script lang="ts" setup>
import Layout from "./components/Layout.vue";
import Progress from "./views/Index.vue";
import HelloWorld from "./components/HelloWorld.vue";
import Index from "./views/Index.vue";
</script>


<template>
  <n-message-provider>
    <!--  <Layout/>-->
    <Index/>
    <!--  <HelloWorld/>-->
  </n-message-provider>
</template>

<style>
</style>
