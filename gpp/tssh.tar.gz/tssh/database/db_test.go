package database

import (
	"database/sql"
	"os"

	"path/filepath"
	"strings"
	"testing"
	"time"
	"tssh/models"

	_ "github.com/mattn/go-sqlite3"
)

func TestMigrationSortAndLastConnected(t *testing.T) {
	dbPath := filepath.Join(t.TempDir(), "connections.db")
	legacy, err := sql.Open("sqlite3", dbPath)
	if err != nil {
		t.Fatal(err)
	}
	_, err = legacy.Exec(`CREATE TABLE ssh_connections (
		id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, host TEXT NOT NULL,
		port INTEGER NOT NULL, username TEXT NOT NULL, auth_type INTEGER NOT NULL,
		password TEXT, private_key TEXT)`)
	if err != nil {
		if strings.Contains(err.Error(), "CGO_ENABLED=0") {
			t.Skip("go-sqlite3 runtime test requires CGO_ENABLED=1")
		}
		t.Fatal(err)
	}
	_, err = legacy.Exec(`INSERT INTO ssh_connections
		(id,name,host,port,username,auth_type,password,private_key) VALUES
		(18,'bba1','203.18.2.79',22,'root',2,'',''),
		(6,'20270415','12.3.50.148',22222,'root',2,'','')`)
	if err != nil {
		t.Fatal(err)
	}
	if err := legacy.Close(); err != nil {
		t.Fatal(err)
	}

	db, err := NewDB(dbPath)
	if err != nil {
		t.Fatalf("migrate legacy database: %v", err)
	}
	defer db.Close()

	connections, err := db.GetAllConnections()
	if err != nil {
		t.Fatal(err)
	}
	if len(connections) != 2 || connections[0].ID != 6 || connections[1].ID != 18 {
		t.Fatalf("connections not sorted by ID: %+v", connections)
	}

	when := time.Date(2026, 9, 23, 14, 30, 45, 0, time.Local)
	want, err := db.UpdateLastConnected(18, when)
	if err != nil {
		t.Fatal(err)
	}
	got, err := db.GetConnection(18)
	if err != nil {
		t.Fatal(err)
	}
	if got.LastConnectedAt != want || got.LastConnectedAt != "2026-09-23 14:30:45" {
		t.Fatalf("unexpected last connected time: %q", got.LastConnectedAt)
	}
}

func TestJSONImportExportRoundTrip(t *testing.T) {
	db, err := NewDB(filepath.Join(t.TempDir(), "connections.db"))
	if err != nil {
		if strings.Contains(err.Error(), "CGO_ENABLED=0") {
			t.Skip("go-sqlite3 runtime test requires CGO_ENABLED=1")
		}
		t.Fatal(err)
	}
	defer db.Close()
	original := models.ConnInfo{Name: "prod", Host: "127.0.0.1", Port: 22, Username: "root", AuthType: models.UsePass, Password: "secret"}
	if err := db.AddConnection(original); err != nil {
		t.Fatal(err)
	}
	jsonPath := filepath.Join(t.TempDir(), "connections.json")
	if n, err := db.ExportConnections(jsonPath); err != nil || n != 1 {
		t.Fatalf("export: n=%d err=%v", n, err)
	}
	data, err := os.ReadFile(jsonPath)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(data), "thisis32byteslongsecretkey") {
		t.Fatal("export leaked encrypted implementation details")
	}
	other, err := NewDB(filepath.Join(t.TempDir(), "other.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer other.Close()
	if n, err := other.ImportConnections(jsonPath); err != nil || n != 1 {
		t.Fatalf("import: n=%d err=%v", n, err)
	}
	got, err := other.GetAllConnections()
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 {
		t.Fatalf("got %d connections", len(got))
	}
	password, err := models.DecryptString(got[0].Password)
	if err != nil || password != "secret" {
		t.Fatalf("password round trip: %q %v", password, err)
	}
}
