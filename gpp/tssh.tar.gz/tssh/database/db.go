package database

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	_ "github.com/mattn/go-sqlite3"
	"os"
	"strconv"
	"strings"
	"time"
	"tssh/models"
)

type DB struct{ *sql.DB }

func NewDB(dbPath string) (*DB, error) {
	db, err := sql.Open("sqlite3", dbPath)
	if err != nil {
		return nil, err
	}
	if err = db.Ping(); err != nil {
		return nil, err
	}
	if err = createTables(db); err != nil {
		return nil, err
	}
	return &DB{db}, nil
}

func createTables(db *sql.DB) error {
	_, err := db.Exec(`CREATE TABLE IF NOT EXISTS ssh_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, host TEXT NOT NULL,
        port INTEGER NOT NULL, username TEXT NOT NULL, auth_type INTEGER NOT NULL,
        password TEXT, private_key TEXT, last_connected_at TEXT)`)
	if err != nil {
		return err
	}
	if err = ensureColumn(db, "ssh_connections", "last_connected_at", "TEXT"); err != nil {
		return err
	}
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`)
	return err
}

func ensureColumn(db *sql.DB, table, column, definition string) error {
	rows, err := db.Query("PRAGMA table_info(" + table + ")")
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var cid int
		var name, dataType string
		var notNull, pk int
		var defaultValue any
		if err := rows.Scan(&cid, &name, &dataType, &notNull, &defaultValue, &pk); err != nil {
			return err
		}
		if name == column {
			return nil
		}
	}
	if err := rows.Err(); err != nil {
		return err
	}
	if err := rows.Close(); err != nil {
		return err
	}
	_, err = db.Exec(fmt.Sprintf("ALTER TABLE %s ADD COLUMN %s %s", table, column, definition))
	return err
}

func (db *DB) GetAllConnections() ([]models.ConnInfo, error) {
	rows, err := db.Query("SELECT id,name,host,port,username,auth_type,password,private_key,COALESCE(last_connected_at, '') FROM ssh_connections ORDER BY id ASC")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.ConnInfo
	for rows.Next() {
		var c models.ConnInfo
		if err := rows.Scan(&c.ID, &c.Name, &c.Host, &c.Port, &c.Username, &c.AuthType, &c.Password, &c.PrivateKey, &c.LastConnectedAt); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}
func (db *DB) GetConnection(id int64) (models.ConnInfo, error) {
	var c models.ConnInfo
	err := db.QueryRow("SELECT id,name,host,port,username,auth_type,password,private_key,COALESCE(last_connected_at, '') FROM ssh_connections WHERE id=?", id).Scan(&c.ID, &c.Name, &c.Host, &c.Port, &c.Username, &c.AuthType, &c.Password, &c.PrivateKey, &c.LastConnectedAt)
	return c, err
}
func (db *DB) AddConnection(c models.ConnInfo) error {
	if c.AuthType == models.UsePass {
		if c.Password == "" {
			return errors.New("password is required for password authentication")
		}
		var err error
		c.Password, err = models.EncryptString(c.Password)
		if err != nil {
			return err
		}
	}
	_, err := db.Exec("INSERT INTO ssh_connections (name,host,port,username,auth_type,password,private_key) VALUES (?,?,?,?,?,?,?)", c.Name, c.Host, c.Port, c.Username, c.AuthType, c.Password, c.PrivateKey)
	return err
}

// ExportConnections writes portable JSON with passwords decrypted for import into
// another tssh profile. IDs and connection timestamps are intentionally omitted.
func (db *DB) ExportConnections(path string) (int, error) {
	connections, err := db.GetAllConnections()
	if err != nil {
		return 0, err
	}
	for i := range connections {
		connections[i].ID = 0
		connections[i].LastConnectedAt = ""
		if connections[i].AuthType == models.UsePass && connections[i].Password != "" {
			connections[i].Password, err = models.DecryptString(connections[i].Password)
			if err != nil {
				return 0, fmt.Errorf("decrypt %q: %w", connections[i].Name, err)
			}
		}
	}
	b, err := json.MarshalIndent(connections, "", "  ")
	if err != nil {
		return 0, err
	}
	if err = os.WriteFile(path, append(b, '\n'), 0600); err != nil {
		return 0, err
	}
	return len(connections), nil
}

// ImportConnections adds every connection from a JSON array. A wrapper object
// with a "connections" array is accepted as well.
func (db *DB) ImportConnections(path string) (int, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0, err
	}
	var connections []models.ConnInfo
	if err = json.Unmarshal(b, &connections); err != nil {
		var wrapper struct {
			Connections []models.ConnInfo `json:"connections"`
		}
		if err = json.Unmarshal(b, &wrapper); err != nil {
			return 0, err
		}
		connections = wrapper.Connections
	}
	if len(connections) == 0 {
		return 0, errors.New("JSON contains no connections")
	}
	for i := range connections {
		connections[i].ID = 0
		connections[i].LastConnectedAt = ""
		connections[i].Name = strings.TrimSpace(connections[i].Name)
		connections[i].Host = strings.TrimSpace(connections[i].Host)
		connections[i].Username = strings.TrimSpace(connections[i].Username)
		if connections[i].Name == "" || connections[i].Host == "" || connections[i].Username == "" || connections[i].Port <= 0 {
			return i, fmt.Errorf("invalid connection at index %d", i)
		}
		if connections[i].AuthType != models.UsePass && connections[i].AuthType != models.UseKey {
			return i, fmt.Errorf("invalid auth_type at index %d", i)
		}
		if connections[i].AuthType == models.UsePass && connections[i].Password == "" {
			return i, fmt.Errorf("password is required at index %d", i)
		}
		if err = db.AddConnection(connections[i]); err != nil {
			return i, err
		}
	}
	return len(connections), nil
}

func (db *DB) UpdateConnection(c models.ConnInfo) error {
	if c.AuthType == models.UsePass && c.Password != "" {
		var err error
		c.Password, err = models.EncryptString(c.Password)
		if err != nil {
			return err
		}
	} else {
		old, err := db.GetConnection(c.ID)
		if err != nil {
			return err
		}
		if c.AuthType == models.UsePass && old.Password == "" {
			return errors.New("password is required for password authentication")
		}
		c.Password = old.Password
	}
	_, err := db.Exec("UPDATE ssh_connections SET name=?,host=?,port=?,username=?,auth_type=?,password=?,private_key=? WHERE id=?", c.Name, c.Host, c.Port, c.Username, c.AuthType, c.Password, c.PrivateKey, c.ID)
	return err
}
func (db *DB) UpdateLastConnected(id int64, connectedAt time.Time) (string, error) {
	value := connectedAt.Local().Format("2006-01-02 15:04:05")
	_, err := db.Exec("UPDATE ssh_connections SET last_connected_at=? WHERE id=?", value, id)
	return value, err
}

func (db *DB) DeleteConnection(id int64) error {
	_, err := db.Exec("DELETE FROM ssh_connections WHERE id=?", id)
	return err
}

func (db *DB) GetProxyConfig() (models.ProxyConfig, error) {
	var p models.ProxyConfig
	var host, port string
	err := db.QueryRow("SELECT value FROM app_settings WHERE key='socks5_host'").Scan(&host)
	if err == sql.ErrNoRows {
		return p, nil
	}
	if err != nil {
		return p, err
	}
	if err = db.QueryRow("SELECT value FROM app_settings WHERE key='socks5_port'").Scan(&port); err != nil && err != sql.ErrNoRows {
		return p, err
	}
	p.Host = host
	_, _ = fmt.Sscanf(port, "%d", &p.Port)
	return p, nil
}
func (db *DB) SaveProxyConfig(p models.ProxyConfig) error {
	tx, err := db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for k, v := range map[string]string{"socks5_host": p.Host, "socks5_port": strconv.Itoa(p.Port)} {
		if _, err = tx.Exec("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", k, v); err != nil {
			return err
		}
	}
	return tx.Commit()
}
