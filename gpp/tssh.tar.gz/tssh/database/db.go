package database

import (
	"database/sql"
	"errors"
	"fmt"
	_ "github.com/mattn/go-sqlite3"
	"strconv"
	"tssh/models"
)

type DB struct{ *sql.DB }

func NewDB(dbPath string) (*DB, error) {
	db, err := sql.Open("sqlite3", dbPath)
	if err != nil {
		return nil, err
	}
	if err = db.Ping(); err != nil {
		return nil, err
	}
	if err = createTables(db); err != nil {
		return nil, err
	}
	return &DB{db}, nil
}

func createTables(db *sql.DB) error {
	_, err := db.Exec(`CREATE TABLE IF NOT EXISTS ssh_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, host TEXT NOT NULL,
        port INTEGER NOT NULL, username TEXT NOT NULL, auth_type INTEGER NOT NULL,
        password TEXT, private_key TEXT)`)
	if err != nil {
		return err
	}
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`)
	return err
}

func (db *DB) GetAllConnections() ([]models.ConnInfo, error) {
	rows, err := db.Query("SELECT id,name,host,port,username,auth_type,password,private_key FROM ssh_connections ORDER BY name")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.ConnInfo
	for rows.Next() {
		var c models.ConnInfo
		if err := rows.Scan(&c.ID, &c.Name, &c.Host, &c.Port, &c.Username, &c.AuthType, &c.Password, &c.PrivateKey); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}
func (db *DB) GetConnection(id int64) (models.ConnInfo, error) {
	var c models.ConnInfo
	err := db.QueryRow("SELECT id,name,host,port,username,auth_type,password,private_key FROM ssh_connections WHERE id=?", id).Scan(&c.ID, &c.Name, &c.Host, &c.Port, &c.Username, &c.AuthType, &c.Password, &c.PrivateKey)
	return c, err
}
func (db *DB) AddConnection(c models.ConnInfo) error {
	if c.AuthType == models.UsePass {
		if c.Password == "" {
			return errors.New("password is required for password authentication")
		}
		var err error
		c.Password, err = models.EncryptString(c.Password)
		if err != nil {
			return err
		}
	}
	_, err := db.Exec("INSERT INTO ssh_connections (name,host,port,username,auth_type,password,private_key) VALUES (?,?,?,?,?,?,?)", c.Name, c.Host, c.Port, c.Username, c.AuthType, c.Password, c.PrivateKey)
	return err
}
func (db *DB) UpdateConnection(c models.ConnInfo) error {
	if c.AuthType == models.UsePass && c.Password != "" {
		var err error
		c.Password, err = models.EncryptString(c.Password)
		if err != nil {
			return err
		}
	} else {
		old, err := db.GetConnection(c.ID)
		if err != nil {
			return err
		}
		if c.AuthType == models.UsePass && old.Password == "" {
			return errors.New("password is required for password authentication")
		}
		c.Password = old.Password
	}
	_, err := db.Exec("UPDATE ssh_connections SET name=?,host=?,port=?,username=?,auth_type=?,password=?,private_key=? WHERE id=?", c.Name, c.Host, c.Port, c.Username, c.AuthType, c.Password, c.PrivateKey, c.ID)
	return err
}
func (db *DB) DeleteConnection(id int64) error {
	_, err := db.Exec("DELETE FROM ssh_connections WHERE id=?", id)
	return err
}

func (db *DB) GetProxyConfig() (models.ProxyConfig, error) {
	var p models.ProxyConfig
	var host, port string
	err := db.QueryRow("SELECT value FROM app_settings WHERE key='socks5_host'").Scan(&host)
	if err == sql.ErrNoRows {
		return p, nil
	}
	if err != nil {
		return p, err
	}
	if err = db.QueryRow("SELECT value FROM app_settings WHERE key='socks5_port'").Scan(&port); err != nil && err != sql.ErrNoRows {
		return p, err
	}
	p.Host = host
	_, _ = fmt.Sscanf(port, "%d", &p.Port)
	return p, nil
}
func (db *DB) SaveProxyConfig(p models.ProxyConfig) error {
	tx, err := db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for k, v := range map[string]string{"socks5_host": p.Host, "socks5_port": strconv.Itoa(p.Port)} {
		if _, err = tx.Exec("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", k, v); err != nil {
			return err
		}
	}
	return tx.Commit()
}
