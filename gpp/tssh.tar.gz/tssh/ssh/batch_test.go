package ssh

import (
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"tssh/models"
)

func TestBuildCommandSpecForKey(t *testing.T) {
	conn := models.ConnInfo{Host: "example.test", Port: 2222, Username: "root", AuthType: models.UseKey, PrivateKey: "missing-key"}
	spec, err := buildCommandSpec(conn, models.ProxyConfig{}, "uname -a")
	if err != nil {
		t.Fatal(err)
	}
	if spec.name != "ssh" {
		t.Fatalf("executable = %q", spec.name)
	}
	wantTail := []string{"root@example.test", "uname -a"}
	if len(spec.args) < len(wantTail) {
		t.Fatalf("args too short: %#v", spec.args)
	}
	for i := range wantTail {
		got := spec.args[len(spec.args)-len(wantTail)+i]
		if got != wantTail[i] {
			t.Fatalf("tail[%d] = %q, want %q; all args: %#v", i, got, wantTail[i], spec.args)
		}
	}
}

func TestBuildCommandSpecUsesConfiguredProxy(t *testing.T) {
	conn := models.ConnInfo{Host: "example.test", Port: 22, Username: "root", AuthType: models.UseKey}
	spec, err := buildCommandSpec(conn, models.ProxyConfig{Host: "127.0.0.1", Port: 7891}, "id")
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(spec.args, " ")
	if !strings.Contains(joined, "--socks5-proxy %h %p 127.0.0.1:7891") {
		t.Fatalf("proxy command missing from args: %#v", spec.args)
	}
}

func TestBuildCommandSpecWithoutProxyHasNoProxyCommand(t *testing.T) {
	conn := models.ConnInfo{Host: "example.test", Port: 22, Username: "root", AuthType: models.UseKey}
	spec, err := buildCommandSpec(conn, models.ProxyConfig{}, "id")
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(strings.Join(spec.args, " "), "ProxyCommand") {
		t.Fatalf("unexpected proxy command: %#v", spec.args)
	}
}

func TestBuildPasswordCommandKeepsSecretOutOfArguments(t *testing.T) {
	encrypted, err := models.EncryptString("top-secret")
	if err != nil {
		t.Fatal(err)
	}
	conn := models.ConnInfo{Host: "example.test", Port: 22, Username: "root", AuthType: models.UsePass, Password: encrypted}
	spec, err := buildCommandSpec(conn, models.ProxyConfig{}, "id")
	if err != nil {
		t.Fatal(err)
	}
	if spec.name != "sshpass" || strings.Contains(strings.Join(spec.args, " "), "top-secret") {
		t.Fatalf("unsafe password command: %s %#v", spec.name, spec.args)
	}
	if !containsString(spec.env, "SSHPASS=top-secret") {
		t.Fatal("SSHPASS environment variable missing")
	}
}

func containsString(values []string, target string) bool {
	for _, value := range values {
		if value == target {
			return true
		}
	}
	return false
}

func TestExecuteBatchPreservesOrderAndBoundsConcurrency(t *testing.T) {
	connections := make([]models.ConnInfo, 12)
	for i := range connections {
		connections[i] = models.ConnInfo{ID: int64(i + 1), Name: fmt.Sprintf("host-%02d", i+1)}
	}
	var active int32
	var maximum int32
	var mu sync.Mutex
	results := executeBatchWith(connections, 3, func(conn models.ConnInfo) CommandResult {
		n := atomic.AddInt32(&active, 1)
		mu.Lock()
		if n > maximum {
			maximum = n
		}
		mu.Unlock()
		time.Sleep(5 * time.Millisecond)
		atomic.AddInt32(&active, -1)
		return CommandResult{Connection: conn, Output: conn.Name}
	})
	if maximum > 3 {
		t.Fatalf("maximum concurrency = %d, want <= 3", maximum)
	}
	for i, result := range results {
		if result.Connection.ID != connections[i].ID || result.Output != connections[i].Name {
			t.Fatalf("result %d out of order: %+v", i, result)
		}
	}
}

func TestExecuteBatchEmpty(t *testing.T) {
	results := ExecuteBatch(nil, models.ProxyConfig{}, "true", 0, time.Second)
	if len(results) != 0 {
		t.Fatalf("got %d results", len(results))
	}
}
