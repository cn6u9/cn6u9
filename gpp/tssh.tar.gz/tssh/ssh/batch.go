package ssh

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"

	"tssh/models"
)

const (
	DefaultBatchConcurrency = 10
	DefaultCommandTimeout   = 60 * time.Second
)

// CommandResult contains the captured output and status for one remote host.
type CommandResult struct {
	Connection models.ConnInfo
	Output     string
	Err        error
	Duration   time.Duration
}

type commandSpec struct {
	name string
	args []string
	env  []string
}

func buildCommandSpec(conn models.ConnInfo, proxyConfig models.ProxyConfig, command string) (commandSpec, error) {
	command = strings.TrimSpace(command)
	if command == "" {
		return commandSpec{}, fmt.Errorf("command is empty")
	}

	sshArgs := []string{
		"-o", "StrictHostKeyChecking=no",
		"-o", "ConnectTimeout=10",
		"-o", "LogLevel=ERROR",
		"-p", strconv.Itoa(conn.Port),
	}
	if proxyConfig.Enabled() {
		exe, err := os.Executable()
		if err != nil {
			return commandSpec{}, fmt.Errorf("resolve current executable: %w", err)
		}
		sshArgs = append(sshArgs, "-o", fmt.Sprintf("ProxyCommand=\"%s\" --socks5-proxy %%h %%p %s", exe, proxyConfig.Address()))
	}
	if conn.AuthType == models.UseKey {
		key := GetValidPath(strings.TrimSpace(conn.PrivateKey), "~/.ssh/id_rsa")
		sshArgs = append(sshArgs, "-i", key)
	}
	sshArgs = append(sshArgs, fmt.Sprintf("%s@%s", conn.Username, conn.Host), command)

	switch conn.AuthType {
	case models.UsePass:
		password, err := models.DecryptString(conn.Password)
		if err != nil {
			return commandSpec{}, fmt.Errorf("decrypt password: %w", err)
		}
		return commandSpec{
			name: "sshpass",
			args: append([]string{"-e", "ssh"}, sshArgs...),
			env:  append(os.Environ(), "SSHPASS="+password),
		}, nil
	case models.UseKey:
		return commandSpec{name: "ssh", args: sshArgs, env: os.Environ()}, nil
	default:
		return commandSpec{}, fmt.Errorf("unsupported auth type: %d", conn.AuthType)
	}
}

func executeCommand(conn models.ConnInfo, proxyConfig models.ProxyConfig, command string, timeout time.Duration) (result CommandResult) {
	if timeout <= 0 {
		timeout = DefaultCommandTimeout
	}
	result = CommandResult{Connection: conn}
	started := time.Now()
	defer func() { result.Duration = time.Since(started) }()

	spec, err := buildCommandSpec(conn, proxyConfig, command)
	if err != nil {
		result.Err = err
		return result
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, spec.name, spec.args...)
	cmd.Env = spec.env
	output, err := cmd.CombinedOutput()
	result.Output = strings.TrimSpace(string(output))
	if ctx.Err() == context.DeadlineExceeded {
		result.Err = fmt.Errorf("command timed out after %s", timeout)
	} else if err != nil {
		result.Err = err
	}
	return result
}

// ExecuteBatch runs one command on all supplied connections. Results preserve
// the same order as the input list, while execution is bounded concurrently.
func ExecuteBatch(connections []models.ConnInfo, proxyConfig models.ProxyConfig, command string, concurrency int, timeout time.Duration) []CommandResult {
	return executeBatchWith(connections, concurrency, func(conn models.ConnInfo) CommandResult {
		return executeCommand(conn, proxyConfig, command, timeout)
	})
}

func executeBatchWith(connections []models.ConnInfo, concurrency int, run func(models.ConnInfo) CommandResult) []CommandResult {
	if concurrency <= 0 {
		concurrency = DefaultBatchConcurrency
	}
	if concurrency > len(connections) && len(connections) > 0 {
		concurrency = len(connections)
	}
	results := make([]CommandResult, len(connections))
	if len(connections) == 0 {
		return results
	}

	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for index := range jobs {
				results[index] = run(connections[index])
			}
		}()
	}
	for i := range connections {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	return results
}
