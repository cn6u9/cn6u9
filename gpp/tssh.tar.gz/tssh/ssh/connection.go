package ssh

import (
	"fmt"
	"golang.org/x/net/proxy"
	"io"
	"net"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
	"tssh/models"
)

func GetValidPath(inputPath, defaultPath string) string {
	if inputPath != "" {
		if info, err := os.Stat(inputPath); err == nil && !info.IsDir() {
			return inputPath
		}
	}
	return defaultPath
}

// CheckAlive verifies that the SSH TCP endpoint accepts connections. It does not
// perform authentication, so it is safe to run in parallel for a whole list.
func CheckAlive(conn models.ConnInfo, timeout time.Duration) error {
	if timeout <= 0 {
		timeout = 3 * time.Second
	}
	c, err := net.DialTimeout("tcp", net.JoinHostPort(conn.Host, strconv.Itoa(conn.Port)), timeout)
	if err != nil {
		return err
	}
	return c.Close()
}

func Connect(rctx *models.RunContext) {
	conn := rctx.Context
	protArg := "-p"
	if rctx.Command == models.RunCommandSftp {
		protArg = "-P"
	}
	userHost := fmt.Sprintf("%s@%s", conn.Username, conn.Host)
	args := []string{string(rctx.Command), "-o", "StrictHostKeyChecking=no", protArg, fmt.Sprintf("%d", conn.Port)}
	if rctx.Proxy.Enabled() {
		exe, _ := os.Executable()
		args = append(args, "-o", fmt.Sprintf("ProxyCommand=\"%s\" --socks5-proxy %%h %%p %s", exe, rctx.Proxy.Address()))
	}
	args = append(args, userHost)
	var cmd *exec.Cmd
	switch conn.AuthType {
	case models.UsePass:
		pass, err := models.DecryptString(conn.Password)
		if err != nil {
			fmt.Printf("Failed to decrypt password: %v\n", err)
			return
		}
		cmd = exec.Command("sshpass", append([]string{"-p", pass}, args...)...)
	case models.UseKey:
		key := GetValidPath(strings.TrimSpace(conn.PrivateKey), "~/.ssh/id_rsa")
		cmd = exec.Command(string(rctx.Command), append([]string{"-i", key}, args...)...)
	}
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	fmt.Printf("Connecting to %s...\n", conn.Name)
	if err := cmd.Run(); err != nil {
		fmt.Printf("SSH connection failed: %v\n", err)
	}
}

func RunSocks5Proxy(args []string) error {
	if len(args) != 3 {
		return fmt.Errorf("usage: --socks5-proxy <target-host> <target-port> <proxy-host:port>")
	}
	d, err := proxy.SOCKS5("tcp", args[2], nil, proxy.Direct)
	if err != nil {
		return err
	}
	c, err := d.Dial("tcp", fmt.Sprintf("%s:%s", args[0], args[1]))
	if err != nil {
		return err
	}
	defer c.Close()
	go func() { _, _ = io.Copy(c, os.Stdin); _ = c.Close() }()
	_, err = io.Copy(os.Stdout, c)
	return err
}
