package main

import (
	"fmt"
	tea "github.com/charmbracelet/bubbletea"
	"os"
	"path/filepath"
	"tssh/database"
	"tssh/ssh"
	"tssh/ui"
)

func main() {
	if len(os.Args) > 1 && os.Args[1] == "--socks5-proxy" {
		if err := ssh.RunSocks5Proxy(os.Args[2:]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	homeDir, err := os.UserHomeDir()
	if err != nil {
		fmt.Printf("Error getting home directory: %v\n", err)
		os.Exit(1)
	}
	configDir := filepath.Join(homeDir, ".xssh")
	if err := os.MkdirAll(configDir, 0755); err != nil {
		fmt.Printf("Error creating config directory: %v\n", err)
		os.Exit(1)
	}
	db, err := database.NewDB(filepath.Join(configDir, "connections.db"))
	if err != nil {
		fmt.Printf("Error initializing database: %v\n", err)
		os.Exit(1)
	}
	defer db.Close()
	connections, err := db.GetAllConnections()
	if err != nil {
		fmt.Printf("Error getting connections: %v\n", err)
		os.Exit(1)
	}
	p := tea.NewProgram(ui.InitialModel(connections, db))
	m, err := p.Run()
	if err != nil {
		fmt.Printf("Error running program: %v\n", err)
		os.Exit(1)
	}
	if mm, ok := m.(*ui.MainModel); ok && mm.WillConn != nil {
		ssh.Connect(mm.WillConn)
	}
}
