package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"time"
	"tssh/database"
	"tssh/models"
	sshclient "tssh/ssh"

	"github.com/charmbracelet/bubbles/key"
	"github.com/charmbracelet/bubbles/table"
	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

var filterFocusStyle = footStyle.Foreground(lipgloss.Color("229"))
var filterBlurStyle = footStyle.Foreground(lipgloss.Color("240"))

const defaultJSONFile = "connections.json"

type FocusView int8

const (
	Table FocusView = iota
	FilterInput
	Confirm
)

type validationBatchMsg struct {
	results map[int64]connectionStatus
	total   int
}

type connectionStatus struct {
	state  string
	detail string
}

func formatLastConnected(value string) string {
	if value == "" {
		return "-"
	}
	return value
}
func genRow(conn *models.ConnInfo, status connectionStatus) table.Row {
	return table.Row{fmt.Sprintf("%d", conn.ID), conn.Name, conn.Host, fmt.Sprintf("%d", conn.Port), conn.Username, formatLastConnected(conn.LastConnectedAt), status.state}
}

type MainModel struct {
	table             table.Model
	connections       []models.ConnInfo
	currentItems      []*models.ConnInfo
	WillConn          *models.RunContext
	filter            string
	filterInput       textinput.Model
	db                *database.DB
	keyMap            *MainKeyMap
	proxy             models.ProxyConfig
	statuses          map[int64]connectionStatus
	statusText        string
	width             int
	height            int
	validationRunning bool
	batchRunning      bool
}

func initialColumns() []table.Column {
	return []table.Column{{Title: "ID", Width: 4}, {Title: "Name", Width: 13}, {Title: "Host", Width: 15}, {Title: "Port", Width: 5}, {Title: "Username", Width: 9}, {Title: "Last Connected", Width: 19}, {Title: "Status", Width: 10}}
}

func InitialModel(connections []models.ConnInfo, db *database.DB) tea.Model {
	proxy, _ := db.GetProxyConfig()
	statuses := make(map[int64]connectionStatus)
	rows := make([]table.Row, 0, len(connections))
	items := make([]*models.ConnInfo, 0, len(connections))
	for i := range connections {
		rows = append(rows, genRow(&connections[i], statuses[connections[i].ID]))
		items = append(items, &connections[i])
	}
	t := table.New(table.WithColumns(initialColumns()), table.WithRows(rows), table.WithFocused(true), table.WithHeight(19))
	s := table.DefaultStyles()
	s.Header = s.Header.BorderStyle(lipgloss.NormalBorder()).BorderForeground(lipgloss.Color("240")).BorderBottom(true).Bold(false)
	s.Selected = s.Selected.Foreground(lipgloss.Color("229")).Background(lipgloss.Color("57")).Bold(false)
	t.SetStyles(s)
	ti := textinput.New()
	ti.Prompt = "Filter: "
	ti.Width = 20
	ti.CharLimit = 50
	return &MainModel{table: t, connections: connections, currentItems: items, db: db, keyMap: NewMainKeyMap(), filterInput: ti, proxy: proxy, statuses: statuses, width: 80, height: 24}
}
func (m *MainModel) Cursor() *models.ConnInfo {
	idx := m.table.Cursor()
	if idx < 0 || idx >= len(m.currentItems) {
		return nil
	}
	return m.currentItems[idx]
}
func (m *MainModel) Init() tea.Cmd { m.SwitchFocus(Table); return nil }

func (m *MainModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		m.resizeTable()
		return m, nil
	case batchCommandCompleteMsg:
		m.batchRunning = false
		okCount := 0
		for _, result := range msg.results {
			status := connectionStatus{state: "ok", detail: "command completed"}
			if result.Err != nil {
				status = connectionStatus{state: "failed", detail: result.Err.Error()}
			} else {
				okCount++
				if value, err := m.db.UpdateLastConnected(result.Connection.ID, time.Now()); err == nil {
					for i := range m.connections {
						if m.connections[i].ID == result.Connection.ID {
							m.connections[i].LastConnectedAt = value
							break
						}
					}
				}
			}
			m.statuses[result.Connection.ID] = status
		}
		m.statusText = fmt.Sprintf("batch command finished: %d OK, %d failed", okCount, len(msg.results)-okCount)
		m.updateTable()
		results := newBatchResultsModel(m, msg)
		return results, nil
	case validationBatchMsg:
		for id, status := range msg.results {
			m.statuses[id] = status
		}
		m.validationRunning = false
		m.statusText = fmt.Sprintf("validated %d connections", msg.total)
		m.updateTable()
		return m, nil
	case tea.KeyMsg:
		switch {
		case key.Matches(msg, m.keyMap.Connect):
			if m.prepareConnection(models.RunCommandSsh) {
				return m, tea.Quit
			}
		case key.Matches(msg, m.keyMap.SftpConnect):
			if m.prepareConnection(models.RunCommandSftp) {
				return m, tea.Quit
			}
		case key.Matches(msg, m.keyMap.Proxy):
			return newProxySettingsModel(m, m.db, m.proxy), nil
		case key.Matches(msg, m.keyMap.Add):
			f := newFormModel(m, m.db, models.ConnInfo{Port: 22, AuthType: models.UsePass})
			return &f, nil
		case key.Matches(msg, m.keyMap.Edit):
			if c := m.Cursor(); c != nil {
				f := newFormModel(m, m.db, *c)
				return &f, nil
			}
		case key.Matches(msg, m.keyMap.Copy):
			return m.copyCurrent()
		case key.Matches(msg, m.keyMap.Delete):
			if c := m.Cursor(); c != nil {
				d := newConfirmModel(m, fmt.Sprintf("Are you sure you want to delete %s ?", c.Name))
				return &d, nil
			}
		case key.Matches(msg, m.keyMap.Import):
			return m.importJSON()
		case key.Matches(msg, m.keyMap.Export):
			return m.exportJSON()
		case key.Matches(msg, m.keyMap.Validate):
			return m.validateConnections()
		case key.Matches(msg, m.keyMap.Batch):
			if m.batchRunning {
				m.statusText = "batch command already running"
				return m, nil
			}
			batch := newBatchCommandModel(m)
			return batch, batch.Init()
		case key.Matches(msg, m.keyMap.Quit):
			return m, tea.Quit
		case key.Matches(msg, m.keyMap.Filter):
			m.SwitchFocus(FilterInput)
			return m, nil
		case key.Matches(msg, m.keyMap.FilterEnter):
			m.SwitchFocus(Table)
			return m, nil
		case key.Matches(msg, m.keyMap.FilterCancel):
			m.filterInput.SetValue("")
			m.filter = ""
			m.SwitchFocus(Table)
			m.updateTable()
			return m, nil
		}
	case DeleteConfirmMsg:
		if msg.context != nil {
			if err := m.db.DeleteConnection(msg.context.ID); err != nil {
				m.statusText = err.Error()
			} else {
				m.reloadConnections()
				m.statusText = "connection deleted"
			}
		}
	}
	var cmd tea.Cmd
	if m.filterInput.Focused() {
		m.filterInput, cmd = m.filterInput.Update(msg)
		m.filter = m.filterInput.Value()
		m.updateTable()
		return m, cmd
	}
	m.table, cmd = m.table.Update(msg)
	return m, cmd
}

func (m *MainModel) copyCurrent() (tea.Model, tea.Cmd) {
	c := m.Cursor()
	if c == nil {
		return m, nil
	}
	clone := *c
	clone.ID = 0
	clone.LastConnectedAt = ""
	clone.Name = clone.Name + " copy"
	if clone.AuthType == models.UsePass && clone.Password != "" {
		password, err := models.DecryptString(clone.Password)
		if err != nil {
			m.statusText = "copy failed: " + err.Error()
			return m, nil
		}
		clone.Password = password
	}
	if err := m.db.AddConnection(clone); err != nil {
		m.statusText = err.Error()
	} else {
		m.reloadConnections()
		m.statusText = "connection copied"
	}
	return m, nil
}
func (m *MainModel) jsonPath() string {
	if p := os.Getenv("TSSH_JSON_FILE"); p != "" {
		return p
	}
	return filepath.Join(mustGetwd(), defaultJSONFile)
}
func mustGetwd() string {
	p, err := os.Getwd()
	if err != nil {
		return "."
	}
	return p
}
func (m *MainModel) importJSON() (tea.Model, tea.Cmd) {
	p := m.jsonPath()
	n, err := m.db.ImportConnections(p)
	if err != nil {
		m.statusText = "import failed: " + err.Error()
	} else {
		m.reloadConnections()
		m.statusText = fmt.Sprintf("imported %d connections from %s", n, p)
	}
	return m, nil
}
func (m *MainModel) exportJSON() (tea.Model, tea.Cmd) {
	p := m.jsonPath()
	n, err := m.db.ExportConnections(p)
	if err != nil {
		m.statusText = "export failed: " + err.Error()
	} else {
		m.statusText = fmt.Sprintf("exported %d connections to %s", n, p)
	}
	return m, nil
}
func (m *MainModel) reloadConnections() {
	c, err := m.db.GetAllConnections()
	if err != nil {
		m.statusText = err.Error()
		return
	}
	m.connections = c
	m.statuses = make(map[int64]connectionStatus)
	m.updateTable()
}
func (m *MainModel) validateConnections() (tea.Model, tea.Cmd) {
	if m.validationRunning {
		m.statusText = "validation already running"
		return m, nil
	}
	m.validationRunning = true
	items := make([]models.ConnInfo, 0, len(m.currentItems))
	for _, c := range m.currentItems {
		items = append(items, *c)
		m.statuses[c.ID] = connectionStatus{state: "checking", detail: ""}
	}
	m.statusText = fmt.Sprintf("validating %d connections...", len(items))
	m.updateTable()
	return m, func() tea.Msg {
		results := make(map[int64]connectionStatus, len(items))
		var mu sync.Mutex
		var wg sync.WaitGroup
		sem := make(chan struct{}, 20)
		for _, item := range items {
			conn := item
			wg.Add(1)
			go func() {
				defer wg.Done()
				sem <- struct{}{}
				err := sshclient.CheckAlive(conn, 3*time.Second)
				<-sem
				status := connectionStatus{state: "alive", detail: "reachable"}
				if err != nil {
					status = connectionStatus{state: "dead", detail: err.Error()}
				}
				mu.Lock()
				results[conn.ID] = status
				mu.Unlock()
			}()
		}
		wg.Wait()
		return validationBatchMsg{results: results, total: len(items)}
	}
}

func (m *MainModel) prepareConnection(command models.RunCommand) bool {
	c := m.Cursor()
	if c == nil {
		return false
	}
	v, err := m.db.UpdateLastConnected(c.ID, time.Now())
	if err != nil {
		m.statusText = err.Error()
		return false
	}
	c.LastConnectedAt = v
	m.WillConn = &models.RunContext{Context: c, Command: command, Proxy: m.proxy}
	return true
}
func (m *MainModel) SwitchFocus(fi FocusView) {
	tableEnabled := fi == Table
	m.keyMap.Add.SetEnabled(tableEnabled)
	m.keyMap.Filter.SetEnabled(tableEnabled)
	m.keyMap.Edit.SetEnabled(tableEnabled)
	m.keyMap.Delete.SetEnabled(tableEnabled)
	m.keyMap.Quit.SetEnabled(tableEnabled)
	m.keyMap.Connect.SetEnabled(tableEnabled)
	m.keyMap.SftpConnect.SetEnabled(tableEnabled)
	m.keyMap.Proxy.SetEnabled(tableEnabled)
	m.keyMap.Copy.SetEnabled(tableEnabled)
	m.keyMap.Import.SetEnabled(tableEnabled)
	m.keyMap.Export.SetEnabled(tableEnabled)
	m.keyMap.Validate.SetEnabled(tableEnabled)
	m.keyMap.Batch.SetEnabled(tableEnabled)
	m.keyMap.FilterEnter.SetEnabled(!tableEnabled)
	if tableEnabled {
		m.filterInput.Blur()
		m.table.Focus()
	} else {
		m.filterInput.Focus()
		m.table.Blur()
	}
}
func (m *MainModel) updateTable() {
	rows := make([]table.Row, 0)
	m.currentItems = make([]*models.ConnInfo, 0)
	for i := range m.connections {
		c := &m.connections[i]
		if m.filter == "" || strings.Contains(strings.ToLower(c.Name), strings.ToLower(m.filter)) || strings.Contains(strings.ToLower(c.Host), strings.ToLower(m.filter)) || strings.Contains(strings.ToLower(c.Username), strings.ToLower(m.filter)) {
			rows = append(rows, genRow(c, m.statuses[c.ID]))
			m.currentItems = append(m.currentItems, c)
		}
	}
	m.table.SetRows(rows)
	m.table.SetCursor(0)
	m.resizeTable()
}
func (m *MainModel) resizeTable() {
	w := m.width - 2
	if w < 40 {
		w = 40
	}
	m.table.SetWidth(w)
	h := m.height - 7
	if h < 5 {
		h = 5
	}
	m.table.SetHeight(h)
	cols := initialColumns()
	if w > 90 {
		extra := w - 90
		cols[1].Width += extra / 3
		cols[2].Width += extra / 3
		cols[4].Width += extra - extra/3 - extra/3
	}
	m.table.SetColumns(cols)
}
func (m *MainModel) View() string {
	var s strings.Builder
	if m.filterInput.Focused() {
		s.WriteString(filterFocusStyle.Render(m.filterInput.View()))
	} else {
		s.WriteString(filterBlurStyle.Render(m.filterInput.View()))
	}
	s.WriteString("\n")
	s.WriteString(tableStyle.Render(m.table.View()))
	if m.statusText != "" {
		s.WriteString("\n" + noStyle.Render(m.statusText))
	}
	s.WriteString("\n" + helpStyle.Render(m.getHelpStr()) + "\n")
	return s.String()
}
func (m *MainModel) getHelpStr() string {
	v := reflect.ValueOf(m.keyMap).Elem()
	b := strings.Builder{}
	count := 0
	for i := 0; i < v.NumField(); i++ {
		k := v.Field(i).Interface().(key.Binding)
		if !k.Enabled() {
			continue
		}
		count++
		h := k.Help()
		b.WriteString("'" + h.Key + "'-" + h.Desc + "  ")
		if count%4 == 0 {
			b.WriteString("\n")
		}
	}
	return b.String()
}
