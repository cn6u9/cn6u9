package ui

import (
	"fmt"
	"strconv"
	"strings"
	"tssh/database"
	"tssh/models"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
)

const (
	proxyHostFocus = iota
	proxyPortFocus
	proxyCancelFocus
	proxySaveFocus
)

type proxySettingsModel struct {
	host, port textinput.Model
	focus      int
	main       *MainModel
	db         *database.DB
	err        error
}

func newProxySettingsModel(main *MainModel, db *database.DB, p models.ProxyConfig) proxySettingsModel {
	h := textinput.New()
	h.Prompt = "  SOCKS5 Host "
	h.Placeholder = "127.0.0.1"
	h.Width = 30
	h.SetValue(p.Host)
	q := textinput.New()
	q.Prompt = "  SOCKS5 Port "
	q.Placeholder = "7891"
	q.Width = 10
	if p.Port > 0 {
		q.SetValue(strconv.Itoa(p.Port))
	}
	m := proxySettingsModel{host: h, port: q, focus: proxyHostFocus, main: main, db: db}
	m.setFocus(proxyHostFocus)
	return m
}

func (m *proxySettingsModel) setFocus(focus int) {
	m.focus = focus
	m.host.Blur()
	m.port.Blur()
	if focus == proxyHostFocus {
		m.host.Focus()
	} else if focus == proxyPortFocus {
		m.port.Focus()
	}
}

func (m proxySettingsModel) Init() tea.Cmd { return textinput.Blink }

func (m proxySettingsModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if k, ok := msg.(tea.KeyMsg); ok {
		switch k.Type {
		case tea.KeyEsc:
			return m.main, nil
		case tea.KeyTab, tea.KeyDown:
			m.setFocus((m.focus + 1) % 4)
			return m, nil
		case tea.KeyShiftTab, tea.KeyUp:
			m.setFocus((m.focus + 3) % 4)
			return m, nil
		case tea.KeyEnter:
			switch m.focus {
			case proxyHostFocus:
				m.setFocus(proxyPortFocus)
				return m, nil
			case proxyPortFocus:
				m.setFocus(proxySaveFocus)
				return m, nil
			case proxyCancelFocus:
				return m.main, nil
			case proxySaveFocus:
				return m.save()
			}
		}
	}

	var cmd tea.Cmd
	if m.focus == proxyHostFocus {
		m.host, cmd = m.host.Update(msg)
	} else if m.focus == proxyPortFocus {
		m.port, cmd = m.port.Update(msg)
	}
	return m, cmd
}

func (m proxySettingsModel) save() (tea.Model, tea.Cmd) {
	p := models.ProxyConfig{Host: strings.TrimSpace(m.host.Value())}
	if strings.TrimSpace(m.port.Value()) != "" {
		var err error
		p.Port, err = strconv.Atoi(strings.TrimSpace(m.port.Value()))
		if err != nil {
			m.err = fmt.Errorf("SOCKS5 port must be a number")
			return m, nil
		}
	}
	if p.Host != "" && (p.Port < 1 || p.Port > 65535) {
		m.err = fmt.Errorf("SOCKS5 port must be 1-65535")
		return m, nil
	}
	if p.Host == "" {
		p.Port = 0
	}
	if err := m.db.SaveProxyConfig(p); err != nil {
		m.err = err
		return m, nil
	}
	m.main.proxy = p
	return m.main, nil
}

func (m proxySettingsModel) View() string {
	var b strings.Builder
	b.WriteString(titleStyle.Render("SOCKS5 Proxy") + "\n\n")
	b.WriteString(m.host.View() + "\n\n")
	b.WriteString(m.port.View() + "\n\n")
	if m.focus == proxyCancelFocus {
		b.WriteString(focusedStyle.Render("[ Cancel ]") + "    [ Save ]\n")
	} else if m.focus == proxySaveFocus {
		b.WriteString("[ Cancel ]    " + focusedStyle.Render("[ Save ]") + "\n")
	} else {
		b.WriteString("[ Cancel ]    [ Save ]\n")
	}
	b.WriteString("Tab/Up-Down switch, Enter confirm, Esc cancel\\n")
	if m.err != nil {
		b.WriteString(errorStyle.Render(m.err.Error()) + "\n")
	}
	return b.String()
}
