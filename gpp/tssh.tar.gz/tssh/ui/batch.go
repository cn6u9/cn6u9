package ui

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"tssh/models"
	sshclient "tssh/ssh"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
)

type batchCommandCompleteMsg struct {
	command    string
	results    []sshclient.CommandResult
	reportPath string
	reportErr  error
}

type batchCommandModel struct {
	main    *MainModel
	input   textinput.Model
	targets []models.ConnInfo
	err     error
}

func newBatchCommandModel(main *MainModel) batchCommandModel {
	input := textinput.New()
	input.Prompt = "Command: "
	input.Placeholder = "uname -a"
	input.Width = 72
	input.CharLimit = 4096
	input.Focus()
	targets := make([]models.ConnInfo, 0, len(main.currentItems))
	for _, item := range main.currentItems {
		targets = append(targets, *item)
	}
	return batchCommandModel{main: main, input: input, targets: targets}
}

func (m batchCommandModel) Init() tea.Cmd { return textinput.Blink }

func (m batchCommandModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if size, ok := msg.(tea.WindowSizeMsg); ok {
		m.input.Width = max(20, size.Width-12)
	}
	if key, ok := msg.(tea.KeyMsg); ok {
		switch key.Type {
		case tea.KeyEsc:
			return m.main, nil
		case tea.KeyEnter:
			command := strings.TrimSpace(m.input.Value())
			if command == "" {
				m.err = fmt.Errorf("command cannot be empty")
				return m, nil
			}
			if len(m.targets) == 0 {
				m.err = fmt.Errorf("no connections in the current view")
				return m, nil
			}
			m.main.batchRunning = true
			m.main.statusText = fmt.Sprintf("running command on %d connections...", len(m.targets))
			return m.main, executeBatchCommand(command, m.targets, m.main.proxy)
		}
	}
	var cmd tea.Cmd
	m.input, cmd = m.input.Update(msg)
	return m, cmd
}

func (m batchCommandModel) View() string {
	var b strings.Builder
	b.WriteString(titleStyle.Render("Batch Command") + "\n\n")
	b.WriteString(fmt.Sprintf("Targets: %d connection(s) from the current filtered view\n\n", len(m.targets)))
	b.WriteString(m.input.View() + "\n\n")
	b.WriteString("Enter execute, Esc cancel\n")
	if m.err != nil {
		b.WriteString(errorStyle.Render(m.err.Error()) + "\n")
	}
	return b.String()
}

func executeBatchCommand(command string, targets []models.ConnInfo, proxy models.ProxyConfig) tea.Cmd {
	return func() tea.Msg {
		concurrency := envPositiveInt("TSSH_BATCH_CONCURRENCY", sshclient.DefaultBatchConcurrency)
		timeoutSeconds := envPositiveInt("TSSH_BATCH_TIMEOUT", int(sshclient.DefaultCommandTimeout/time.Second))
		results := sshclient.ExecuteBatch(targets, proxy, command, concurrency, time.Duration(timeoutSeconds)*time.Second)
		path, err := writeBatchReport(command, results)
		return batchCommandCompleteMsg{command: command, results: results, reportPath: path, reportErr: err}
	}
}

func envPositiveInt(name string, fallback int) int {
	value, err := strconv.Atoi(strings.TrimSpace(os.Getenv(name)))
	if err != nil || value <= 0 {
		return fallback
	}
	return value
}

func writeBatchReport(command string, results []sshclient.CommandResult) (string, error) {
	path := filepath.Join(mustGetwd(), "batch-results-"+time.Now().Format("20060102-150405")+".txt")
	var b strings.Builder
	b.WriteString("Command: " + command + "\n")
	b.WriteString(fmt.Sprintf("Targets: %d\n", len(results)))
	b.WriteString("Generated: " + time.Now().Format(time.RFC3339) + "\n\n")
	for _, result := range results {
		status := "OK"
		if result.Err != nil {
			status = "FAILED: " + result.Err.Error()
		}
		b.WriteString(fmt.Sprintf("===== [%s] %s (%s:%d) %s =====\n", status, result.Connection.Name, result.Connection.Host, result.Connection.Port, result.Duration.Round(time.Millisecond)))
		if result.Output == "" {
			b.WriteString("(no output)\n")
		} else {
			b.WriteString(result.Output + "\n")
		}
		b.WriteString("\n")
	}
	if err := os.WriteFile(path, []byte(b.String()), 0600); err != nil {
		return "", err
	}
	return path, nil
}

type batchResultsModel struct {
	main       *MainModel
	command    string
	results    []sshclient.CommandResult
	reportPath string
	reportErr  error
	lines      []string
	offset     int
	width      int
	height     int
}

func newBatchResultsModel(main *MainModel, msg batchCommandCompleteMsg) batchResultsModel {
	m := batchResultsModel{main: main, command: msg.command, results: msg.results, reportPath: msg.reportPath, reportErr: msg.reportErr, width: main.width, height: main.height}
	m.lines = m.buildLines()
	return m
}

func (m batchResultsModel) Init() tea.Cmd { return nil }

func (m batchResultsModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		m.clampOffset()
	case tea.KeyMsg:
		switch msg.String() {
		case "q", "esc", "enter":
			return m.main, nil
		case "up", "k":
			m.offset--
		case "down", "j":
			m.offset++
		case "pgup", "u":
			m.offset -= m.pageHeight()
		case "pgdown", "d", " ":
			m.offset += m.pageHeight()
		case "home", "g":
			m.offset = 0
		case "end", "G":
			m.offset = len(m.lines)
		}
		m.clampOffset()
	}
	return m, nil
}

func (m batchResultsModel) pageHeight() int {
	return max(1, m.height-7)
}

func (m *batchResultsModel) clampOffset() {
	maximum := max(0, len(m.lines)-m.pageHeight())
	if m.offset < 0 {
		m.offset = 0
	}
	if m.offset > maximum {
		m.offset = maximum
	}
}

func (m batchResultsModel) buildLines() []string {
	lines := []string{fmt.Sprintf("Command: %s", m.command), ""}
	for _, result := range m.results {
		status := "OK"
		if result.Err != nil {
			status = "FAILED: " + result.Err.Error()
		}
		lines = append(lines, fmt.Sprintf("[%s] %s (%s:%d) - %s", status, result.Connection.Name, result.Connection.Host, result.Connection.Port, result.Duration.Round(time.Millisecond)))
		if result.Output == "" {
			lines = append(lines, "  (no output)")
		} else {
			for _, line := range strings.Split(result.Output, "\n") {
				lines = append(lines, "  "+line)
			}
		}
		lines = append(lines, "")
	}
	return lines
}

func (m batchResultsModel) View() string {
	pageHeight := m.pageHeight()
	end := min(len(m.lines), m.offset+pageHeight)
	visible := make([]string, 0, end-m.offset)
	for _, line := range m.lines[m.offset:end] {
		visible = append(visible, truncateRunes(line, max(20, m.width-2)))
	}
	okCount := 0
	for _, result := range m.results {
		if result.Err == nil {
			okCount++
		}
	}
	var b strings.Builder
	b.WriteString(titleStyle.Render(fmt.Sprintf("Batch Results: %d OK, %d failed", okCount, len(m.results)-okCount)) + "\n")
	b.WriteString(strings.Join(visible, "\n"))
	b.WriteString("\n")
	if m.reportErr != nil {
		b.WriteString(errorStyle.Render("Report write failed: "+m.reportErr.Error()) + "\n")
	} else {
		b.WriteString(noStyle.Render("Report: "+m.reportPath) + "\n")
	}
	b.WriteString(helpStyle.Render("Up/Down scroll, PgUp/PgDn page, Esc/Enter/q return"))
	return b.String()
}

func truncateRunes(value string, width int) string {
	runes := []rune(value)
	if len(runes) <= width {
		return value
	}
	if width <= 1 {
		return string(runes[:width])
	}
	return string(runes[:width-1]) + "…"
}
