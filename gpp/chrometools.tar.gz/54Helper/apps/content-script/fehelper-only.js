/**
 * 54Helper ContentScripts
 * @author lijian
 */
window.onload = function(){
    document.getElementById('btnInstallExtension').style.display = 'none';
};