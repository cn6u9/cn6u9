## 0.7.0
增加了https://github.com/fuckjsonp/FuckJsonp-RCE-CVE-2022-26809-SQL-XSS-FuckJsonp 中的一些域名

## 0.7.1
增加了对 210.13.121.28:9000 这种蜜罐中的一些对运营商脚本请求的识别
增加了对 HFISH 的绝大部分的 WEB 蜜罐的识别

## 0.7.2
一些bug的修复
增加了一个清空域名黑名单的功能