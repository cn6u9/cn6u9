document.addEventListener('DOMContentLoaded', function() {
  const proxySelect = document.getElementById('proxy-select');
  const toggleButton = document.getElementById('toggle-proxy');
  const addProxyButton = document.getElementById('add-proxy');
  const deleteProxyButton = document.getElementById('delete-proxy');
  const proxyNameInput = document.getElementById('proxy-name'); // Added proxy name input
  const proxyTypeInput = document.getElementById('proxy-type');
  const proxyHostInput = document.getElementById('proxy-host');
  const proxyPortInput = document.getElementById('proxy-port');
  const proxyUsernameInput = document.getElementById('proxy-username');
  const proxyPasswordInput = document.getElementById('proxy-password');
  const statusIndicator = document.getElementById('status-indicator');
  
  // Whitelist elements
  const whitelistItemsSelect = document.getElementById('whitelist-items');
  const removeWhitelistButton = document.getElementById('remove-whitelist');
  const batchWhitelistInput = document.getElementById('batch-whitelist');
  const batchAddWhitelistButton = document.getElementById('batch-add-whitelist');
  const clearWhitelistButton = document.getElementById('clear-whitelist');
  
  // Tab switching functionality
  const tabs = document.querySelectorAll('.tab');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', function() {
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      this.classList.add('active');
      const tabId = this.getAttribute('data-tab');
      document.getElementById(`${tabId}-tab`).classList.add('active');
    });
  });
  
  // Load proxies
  loadProxies();
  
  // Load whitelist
  loadWhitelist();
  
  // Add new proxy
  addProxyButton.addEventListener('click', function() {
    const name = proxyNameInput.value.trim(); // Get proxy name
    const type = proxyTypeInput.value;
    const host = proxyHostInput.value.trim();
    const port = proxyPortInput.value.trim();
    const username = proxyUsernameInput.value.trim();
    const password = proxyPasswordInput.value.trim();
    
    if (!name) {
      showMessage('请输入代理名称', 'error');
      return;
    }
    
    if (!host || !port) {
      showMessage('请输入代理主机和端口', 'error');
      return;
    }
    
    chrome.storage.sync.get(['proxies'], function(data) {
      const proxies = data.proxies || [];
      
      // Check if name already exists
      if (proxies.some(proxy => proxy.name === name)) {
        showMessage('代理名称已存在', 'error');
        return;
      }
      
      // Add new proxy with name
      proxies.push({
        name: name, // Add name to proxy object
        type: type,
        host: host,
        port: port,
        username: username,
        password: password
      });
      
      chrome.storage.sync.set({proxies: proxies}, function() {
        // Clear input fields
        proxyNameInput.value = '';
        proxyHostInput.value = '';
        proxyPortInput.value = '';
        proxyUsernameInput.value = '';
        proxyPasswordInput.value = '';
        
        // Reload proxy list
        loadProxies();
        
        // Select newly added proxy
        setTimeout(function() {
          proxySelect.selectedIndex = proxies.length - 1;
          proxySelect.dispatchEvent(new Event('change'));
        }, 100);
        
        // Switch to proxy settings tab after adding
        document.querySelector('.tab[data-tab="proxy"]').click();
      });
    });
  });
  
  // Delete selected proxy
  deleteProxyButton.addEventListener('click', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      showMessage('请选择要删除的代理', 'warning');
      return;
    }
    
    chrome.storage.sync.get(['proxies', 'currentProxy', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      
      proxies.splice(selectedIndex, 1);
      
      const updates = {proxies: proxies};
      
      if (data.isProxyEnabled && data.currentProxy === selectedIndex) {
        updates.isProxyEnabled = false;
        
        chrome.proxy.settings.set({
          value: {mode: 'direct'},
          scope: 'regular'
        });
      }
      
      if (data.currentProxy > selectedIndex) {
        updates.currentProxy = data.currentProxy - 1;
      }
      
      chrome.storage.sync.set(updates, function() {
        loadProxies();
        updateStatusIndicator(false);
      });
    });
  });
  
  // Toggle proxy status
  toggleButton.addEventListener('click', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      showMessage('请选择要使用的代理', 'warning');
      return;
    }
    
    chrome.storage.sync.get(['proxies', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      const currentProxy = proxies[selectedIndex];
      const newState = !data.isProxyEnabled;
      
      chrome.runtime.sendMessage({
        action: 'toggleProxy',
        enable: newState,
        proxyConfig: {
          type: currentProxy.type,
          host: currentProxy.host,
          port: currentProxy.port,
          username: currentProxy.username,
          password: currentProxy.password
        }
      }, function(response) {
        if (response && response.success) {
          chrome.storage.sync.set({
            isProxyEnabled: newState,
            currentProxy: selectedIndex
          }, function() {
            updateStatusIndicator(newState);
            toggleButton.textContent = newState ? '禁用代理' : '启用代理';
            toggleButton.className = newState ? 'btn-danger' : 'btn-success';
          });
        }
      });
    });
  });
  
  // Proxy selection change
  proxySelect.addEventListener('change', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      return;
    }
    
    chrome.storage.sync.get(['isProxyEnabled', 'currentProxy'], function(data) {
      if (data.isProxyEnabled && data.currentProxy === selectedIndex) {
        toggleButton.textContent = '禁用代理';
        toggleButton.className = 'btn-danger';
      } else {
        toggleButton.textContent = '启用代理';
        toggleButton.className = 'btn-success';
      }
    });
  });
  
  // Remove whitelist domain
  removeWhitelistButton.addEventListener('click', function() {
    const selectedIndex = whitelistItemsSelect.selectedIndex;
    if (selectedIndex === -1) {
      showMessage('请选择要移除的域名', 'warning');
      return;
    }
    
    const domain = whitelistItemsSelect.options[selectedIndex].value;
    chrome.runtime.sendMessage(
      { action: 'removeFromWhitelist', domain: domain },
      function(response) {
        if (response && response.success) {
          loadWhitelist();
          showMessage('域名已成功移除', 'success');
        } else {
          showMessage('移除失败', 'error');
        }
      }
    );
  });
  
  // Load proxy list
  function loadProxies() {
    chrome.storage.sync.get(['proxies', 'currentProxy', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      
      proxySelect.innerHTML = '';
      
      proxies.forEach(function(proxy, index) {
        const option = document.createElement('option');
        option.value = index;
        // Display proxy name first, then other details
        const authBadge = (proxy.username && proxy.password) ? ' 🔒' : '';
        option.textContent = `${proxy.name} - ${proxy.type.toUpperCase()} ${proxy.host}:${proxy.port}${authBadge}`;
        proxySelect.appendChild(option);
      });
      
      if (proxies.length === 0) {
        toggleButton.disabled = true;
        deleteProxyButton.disabled = true;
        
        const option = document.createElement('option');
        option.disabled = true;
        option.textContent = '没有可用的代理';
        proxySelect.appendChild(option);
        
        updateStatusIndicator(false);
      } else {
        toggleButton.disabled = false;
        deleteProxyButton.disabled = false;
        
        if (data.isProxyEnabled && data.currentProxy !== undefined) {
          proxySelect.selectedIndex = data.currentProxy;
          toggleButton.textContent = '禁用代理';
          toggleButton.className = 'btn-danger';
          updateStatusIndicator(true);
        } else {
          proxySelect.selectedIndex = 0;
          toggleButton.textContent = '启用代理';
          toggleButton.className = 'btn-success';
          updateStatusIndicator(false);
        }
      }
    });
  }
  
  // Load whitelist
  function loadWhitelist() {
    chrome.runtime.sendMessage(
      { action: 'getWhitelist' },
      function(response) {
        whitelistItemsSelect.innerHTML = '';
        
        if (response && response.whitelist && response.whitelist.length > 0) {
          response.whitelist.forEach(function(domain) {
            const option = document.createElement('option');
            option.value = domain;
            option.textContent = domain;
            whitelistItemsSelect.appendChild(option);
          });
        } else {
          const option = document.createElement('option');
          option.disabled = true;
          option.textContent = '白名单为空';
          whitelistItemsSelect.appendChild(option);
        }
      }
    );
  }
  
  // Update status indicator
  function updateStatusIndicator(isEnabled) {
    if (!statusIndicator) return;
    
    if (isEnabled) {
      statusIndicator.textContent = '代理已启用';
      statusIndicator.className = 'status-enabled';
    } else {
      statusIndicator.textContent = '代理已禁用';
      statusIndicator.className = 'status-disabled';
    }
  }
  
  // Batch add whitelist domains
  batchAddWhitelistButton.addEventListener('click', function() {
    const batchText = batchWhitelistInput.value.trim();
    if (!batchText) {
      showMessage('请输入要批量添加的域名', 'warning');
      return;
    }
    
    const domains = batchText.split('\n').map(d => d.trim()).filter(d => d);
    
    if (domains.length === 0) {
      showMessage('未找到有效的域名', 'warning');
      return;
    }
    
    chrome.runtime.sendMessage(
      { action: 'getWhitelist' },
      function(response) {
        if (response && response.whitelist) {
          const existingWhitelist = response.whitelist;
          const newDomains = [];
          const duplicateDomains = [];
          
          domains.forEach(domain => {
            if (existingWhitelist.includes(domain)) {
              duplicateDomains.push(domain);
            } else {
              newDomains.push(domain);
            }
          });
          
          if (newDomains.length === 0) {
            showMessage('所有域名已存在于白名单中', 'warning');
            return;
          }
          
          chrome.runtime.sendMessage(
            { action: 'batchAddToWhitelist', domains: newDomains },
            function(response) {
              if (response && response.success) {
                batchWhitelistInput.value = '';
                loadWhitelist();
                
                let message = `成功添加 ${newDomains.length} 个域名`;
                if (duplicateDomains.length > 0) {
                  message += `，${duplicateDomains.length} 个域名已存在`;
                }
                showMessage(message, 'success');
              } else {
                showMessage('批量添加失败', 'error');
              }
            }
          );
        }
      }
    );
  });
  
  // Clear whitelist
  clearWhitelistButton.addEventListener('click', function() {
    if (confirm('确定要清空所有白名单域名吗？此操作不可撤销。')) {
      chrome.runtime.sendMessage(
        { action: 'clearWhitelist' },
        function(response) {
          if (response && response.success) {
            loadWhitelist();
            showMessage('白名单已清空', 'success');
          } else {
            showMessage('清空白名单失败', 'error');
          }
        }
      );
    }
  });
  
  // Check current proxy state
  chrome.runtime.sendMessage({action: 'getProxyState'}, function(response) {
    if (response) {
      updateStatusIndicator(response.isEnabled);
    }
  });
});

// Show message function
function showMessage(message, type = 'error') {
  const container = document.getElementById('message-container');
  container.textContent = message;
  container.className = `message-container message-${type} message-show`;
  
  setTimeout(() => {
    container.className = 'message-container';
  }, 1000);
}