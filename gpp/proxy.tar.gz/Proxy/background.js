// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    proxies: [
      { name: 'proxy', type: 'socks5', host: '127.0.0.1', port: 7891 },
      { name: 'trojan', type: 'socks5', host: '127.0.0.1', port: 7892 }
    ],
    isProxyEnabled: false,
    currentProxy: 0,
    whitelist: ['192.168.0.240', 'example.com', 'localhost'], // 多个默认白名单
    autoToggleProxy: true
  }, function() {
    console.log('默认设置已完成');
    chrome.proxy.settings.set({
      value: { mode: 'direct' },
      scope: 'regular'
    });
  });
});

// Message handling
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'toggleProxy') {
    updateProxySettings(request.enable, request.proxyConfig);
    sendResponse({success: true});
  } else if (request.action === 'getProxyState') {
    chrome.proxy.settings.get({}, function(config) {
      sendResponse({
        isEnabled: config.value.mode !== 'direct',
        currentConfig: config.value
      });
    });
    return true;
  } else if (request.action === 'addToWhitelist') {
    addToWhitelist(request.domain, sendResponse);
    return true;
  } else if (request.action === 'removeFromWhitelist') {
    removeFromWhitelist(request.domain, sendResponse);
    return true;
  } else if (request.action === 'getWhitelist') {
    getWhitelist(sendResponse);
    return true;
  } else if (request.action === 'batchAddToWhitelist') {
    batchAddToWhitelist(request.domains, sendResponse);
    return true;
  } else if (request.action === 'clearWhitelist') {
    clearWhitelist(sendResponse);
    return true;
  }
});

// Whitelist functions
function addToWhitelist(domain, callback) {
  if (!domain) {
    callback({success: false, message: '域名不能为空'});
    return;
  }
  
  domain = formatDomain(domain);
  
  chrome.storage.sync.get(['whitelist'], function(data) {
    let whitelist = data.whitelist || [];
    
    if (whitelist.includes(domain)) {
      callback({success: false, message: '该域名已在白名单中'});
      return;
    }
    
    whitelist.push(domain);
    chrome.storage.sync.set({whitelist: whitelist}, function() {
      chrome.storage.sync.get(['isProxyEnabled', 'proxies', 'currentProxy'], function(data) {
        if (data.isProxyEnabled && data.proxies && data.proxies[data.currentProxy]) {
          updateProxySettings(true, data.proxies[data.currentProxy]);
        }
        callback({success: true, whitelist: whitelist});
      });
    });
  });
}

function removeFromWhitelist(domain, callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    let whitelist = data.whitelist || [];
    whitelist = whitelist.filter(item => item !== domain);
    
    chrome.storage.sync.set({whitelist: whitelist}, function() {
      chrome.storage.sync.get(['isProxyEnabled', 'proxies', 'currentProxy'], function(data) {
        if (data.isProxyEnabled && data.proxies && data.proxies[data.currentProxy]) {
          updateProxySettings(true, data.proxies[data.currentProxy]);
        }
        callback({success: true, whitelist: whitelist});
      });
    });
  });
}

function getWhitelist(callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    callback({whitelist: data.whitelist || []});
  });
}

function batchAddToWhitelist(domains, callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    const whitelist = data.whitelist || [];
    const newDomains = domains.map(formatDomain).filter(d => !whitelist.includes(d));
    
    if (newDomains.length === 0) {
      callback({success: false, message: '所有域名已存在于白名单中'});
      return;
    }
    
    const newWhitelist = [...whitelist, ...newDomains];
    chrome.storage.sync.set({whitelist: newWhitelist}, function() {
      chrome.storage.sync.get(['isProxyEnabled', 'proxies', 'currentProxy'], function(data) {
        if (data.isProxyEnabled && data.proxies && data.proxies[data.currentProxy]) {
          updateProxySettings(true, data.proxies[data.currentProxy]);
        }
        callback({success: true, added: newDomains.length});
      });
    });
  });
}

function clearWhitelist(callback) {
  chrome.storage.sync.set({whitelist: []}, function() {
    chrome.storage.sync.get(['isProxyEnabled', 'proxies', 'currentProxy'], function(data) {
      if (data.isProxyEnabled && data.proxies && data.proxies[data.currentProxy]) {
        updateProxySettings(true, data.proxies[data.currentProxy]);
      }
      callback({success: true});
    });
  });
}

function formatDomain(domain) {
  domain = domain.replace(/^(https?:\/\/)?(www\.)?/i, '');
  domain = domain.split('/')[0];
  return domain.trim().toLowerCase();
}

// Proxy settings
function updateProxySettings(enable, proxyConfig) {
  let config = {};
  
  if (enable && proxyConfig) {
    const scheme = proxyConfig.type.toLowerCase();
    
    chrome.storage.sync.get(['whitelist'], function(data) {
      const whitelist = data.whitelist || [];
      const formattedWhitelist = whitelist.map(domain => {
        return domain.startsWith('*.') ? domain : `*.${domain}`;
      });
      whitelist.forEach(domain => {
        formattedWhitelist.push(domain);
      });
      
      const bypassList = ['<local>', 'localhost', '127.0.0.1'].concat(formattedWhitelist);
      
      if (scheme === 'socks5' && proxyConfig.username && proxyConfig.password) {
        let bypassRules = '';
        if (whitelist.length > 0) {
          bypassRules = `
            if (${whitelist.map(domain => {
              const escapedDomain = domain.replace(/\./g, '\\.');
              return `(host === "${domain}" || host.endsWith(".${domain}"))`;
            }).join(' || ')}) {
              return "DIRECT";
            }
          `;
        }
        
        const pacScript = `
          function FindProxyForURL(url, host) {
            if (shExpMatch(host, "localhost") || shExpMatch(host, "127.0.0.1")) {
              return "DIRECT";
            }
            ${bypassRules}
            return "SOCKS5 ${proxyConfig.username}:${proxyConfig.password}@${proxyConfig.host}:${proxyConfig.port}";
          }
        `;
        
        config = {
          mode: 'pac_script',
          pacScript: {
            data: pacScript
          }
        };
      } else {
        config = {
          mode: 'fixed_servers',
          rules: {
            singleProxy: {
              scheme: scheme,
              host: proxyConfig.host,
              port: parseInt(proxyConfig.port)
            },
            bypassList: bypassList
          }
        };
      }
      
      chrome.proxy.settings.set({
        value: config,
        scope: 'regular'
      }, function() {
        if (chrome.runtime.lastError) {
          console.error('代理设置错误:', chrome.runtime.lastError);
        } else {
          console.log('代理设置已更新:', enable ? '启用' : '禁用');
          chrome.storage.sync.set({ isProxyEnabled: enable });
        }
      });
    });
  } else {
    config = { mode: 'direct' };
    chrome.proxy.settings.set({
      value: config,
      scope: 'regular'
    }, function() {
      if (chrome.runtime.lastError) {
        console.error('代理设置错误:', chrome.runtime.lastError);
      } else {
        console.log('代理设置已更新:', enable ? '启用' : '禁用');
        chrome.storage.sync.set({ isProxyEnabled: enable });
      }
    });
  }
}

// Handle proxy authentication
chrome.webRequest.onAuthRequired.addListener(
  function(details, callbackFn) {
    if (details.isProxy) {
      chrome.storage.sync.get(['proxies', 'currentProxy'], function(data) {
        if (data.proxies && data.proxies[data.currentProxy]) {
          const currentProxy = data.proxies[data.currentProxy];
          if (currentProxy.username && currentProxy.password) {
            callbackFn({
              authCredentials: {
                username: currentProxy.username,
                password: currentProxy.password
              }
            });
            return;
          }
        }
        callbackFn({});
      });
    } else {
      callbackFn({});
    }
  },
  {urls: ["<all_urls>"]},
  ["asyncBlocking"]
);


// 随机Header增强防识别
chrome.webRequest.onBeforeSendHeaders.addListener(
  function(details) {
    const headers = details.requestHeaders;

    // 生成随机字符串
    const randomString = () => Math.random().toString(36).substring(2, 10) + Date.now().toString(36);

    // 添加伪装 Header
    headers.push({ name: "X-Random-ID", value: randomString() });
    headers.push({ name: "X-Fake-Referer", value: "https://www.google.com" });
    headers.push({ name: "X-Session-Token", value: randomString() });
    headers.push({ name: "X-Client-Fingerprint", value: btoa(randomString()) });
    headers.push({ name: "X-Requested-With", value: "XMLHttpRequest" });
    headers.push({ name: "Accept-Language", value: "zh-CN,zh;q=0.9,en;q=0.8" });
    headers.push({ name: "DNT", value: "1" });

    // 伪造常见 User-Agent
    const userAgents = [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",
      "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0",
      "Mozilla/5.0 (Linux; Android 11; SM-G9730) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    ];
    const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];

    let uaFound = false;
    for (let i = 0; i < headers.length; i++) {
      if (headers[i].name.toLowerCase() === 'user-agent') {
        headers[i].value = randomUA;
        uaFound = true;
        break;
      }
    }
    if (!uaFound) {
      headers.push({ name: 'User-Agent', value: randomUA });
    }

    return { requestHeaders: headers };
  },
  { urls: ["<all_urls>"] },
  ["blocking", "requestHeaders"]
);
