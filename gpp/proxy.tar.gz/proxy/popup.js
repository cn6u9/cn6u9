document.addEventListener('DOMContentLoaded', function() {
  const proxySelect = document.getElementById('proxy-select');
  const toggleButton = document.getElementById('toggle-proxy');
  const addProxyButton = document.getElementById('add-proxy');
  const deleteProxyButton = document.getElementById('delete-proxy');
  const editProxyButton = document.getElementById('edit-proxy');
  const proxyNameInput = document.getElementById('proxy-name');
  const proxyTypeInput = document.getElementById('proxy-type');
  const proxyHostInput = document.getElementById('proxy-host');
  const proxyPortInput = document.getElementById('proxy-port');
  const proxyUsernameInput = document.getElementById('proxy-username');
  const proxyPasswordInput = document.getElementById('proxy-password');
  const statusIndicator = document.getElementById('status-indicator');
  const autoToggleCheckbox = document.getElementById('auto-toggle-proxy');
  
  // Whitelist elements
  const whitelistItemsSelect = document.getElementById('whitelist-items');
  const removeWhitelistButton = document.getElementById('remove-whitelist');
  const batchWhitelistInput = document.getElementById('batch-whitelist');
  const batchAddWhitelistButton = document.getElementById('batch-add-whitelist');
  const clearWhitelistButton = document.getElementById('clear-whitelist');
  
  // GFWList elements
  const gfwlistUrlInput = document.getElementById('gfwlist-url');
  const updateGfwlistButton = document.getElementById('update-gfwlist');
  const toggleGfwlistButton = document.getElementById('toggle-gfwlist');
  const gfwlistStatus = document.getElementById('gfwlist-status');
  
  // Tab switching
  const tabs = document.querySelectorAll('.tab');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', function() {
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      this.classList.add('active');
      const tabId = this.getAttribute('data-tab');
      document.getElementById(`${tabId}-tab`).classList.add('active');
    });
  });
  
  // Load saved settings
  chrome.storage.sync.get(['autoToggleProxy'], function(data) {
    autoToggleCheckbox.checked = data.autoToggleProxy !== false;
  });
  
  // Save auto-toggle preference
  autoToggleCheckbox.addEventListener('change', function() {
    chrome.storage.sync.set({autoToggleProxy: this.checked});
  });
  
  // Load proxies, whitelist and GFWList status
  loadProxies();
  loadWhitelist();
  loadGfwlistStatus();
  
  // Add new proxy (extracted as a named function so edit can reuse)
  function addNewProxy() {
    const name = proxyNameInput.value.trim();
    const type = proxyTypeInput.value;
    const host = proxyHostInput.value.trim();
    const port = proxyPortInput.value.trim();
    const username = proxyUsernameInput.value.trim();
    const password = proxyPasswordInput.value.trim();
    
    if (!name) {
      showMessage('请输入代理名称', 'error');
      return;
    }
    
    if (!host || !port) {
      showMessage('请输入代理主机和端口', 'error');
      return;
    }
    
    chrome.storage.sync.get(['proxies'], function(data) {
      const proxies = data.proxies || [];
      
      if (proxies.some(proxy => proxy.name === name)) {
        showMessage('代理名称已存在', 'error');
        return;
      }
      
      proxies.push({
        name: name,
        type: type,
        host: host,
        port: port,
        username: username,
        password: password
      });
      
      chrome.storage.sync.set({proxies: proxies}, function() {
        proxyNameInput.value = '';
        proxyHostInput.value = '';
        proxyPortInput.value = '';
        proxyUsernameInput.value = '';
        proxyPasswordInput.value = '';
        
        loadProxies();
        
        setTimeout(function() {
          proxySelect.selectedIndex = proxies.length - 1;
          proxySelect.dispatchEvent(new Event('change'));
        }, 100);
        
        document.querySelector('.tab[data-tab="proxy"]').click();
      });
    });
  }
  
  // Bind add proxy
  addProxyButton.addEventListener('click', addNewProxy);
  
  // 编辑代理按钮事件
  editProxyButton.addEventListener('click', function editProxy() {
    const selectedIndex = proxySelect.selectedIndex;
    if (selectedIndex === -1) {
      showMessage('请选择要编辑的代理', 'warning');
      return;
    }
    chrome.storage.sync.get(['proxies'], function(data) {
      const proxies = data.proxies || [];
      const proxy = proxies[selectedIndex];
      proxyNameInput.value = proxy.name;
      proxyTypeInput.value = proxy.type;
      proxyHostInput.value = proxy.host;
      proxyPortInput.value = proxy.port;
      proxyUsernameInput.value = proxy.username || '';
      proxyPasswordInput.value = proxy.password || '';
      document.querySelector('.tab[data-tab="add-proxy"]').click();
      addProxyButton.textContent = '更新代理';
      addProxyButton.removeEventListener('click', addNewProxy);

      function updateProxy() {
        const name = proxyNameInput.value.trim();
        const type = proxyTypeInput.value;
        const host = proxyHostInput.value.trim();
        const port = proxyPortInput.value.trim();
        const username = proxyUsernameInput.value.trim();
        const password = proxyPasswordInput.value.trim();

        if (!name) {
          showMessage('请输入代理名称', 'error');
          return;
        }
        if (!host || !port) {
          showMessage('请输入代理主机和端口', 'error');
          return;
        }
        if (proxies.some((p, i) => i !== selectedIndex && p.name === name)) {
          showMessage('代理名称已存在', 'error');
          return;
        }
        proxies[selectedIndex] = { name, type, host, port, username, password };
        chrome.storage.sync.set({proxies: proxies}, function() {
          proxyNameInput.value = '';
          proxyHostInput.value = '';
          proxyPortInput.value = '';
          proxyUsernameInput.value = '';
          proxyPasswordInput.value = '';
          addProxyButton.textContent = '添加代理';
          addProxyButton.removeEventListener('click', updateProxy);
          addProxyButton.addEventListener('click', addNewProxy);
          loadProxies();
          showMessage('代理已更新', 'success');
          document.querySelector('.tab[data-tab="proxy"]').click();
        });
      }

      addProxyButton.addEventListener('click', updateProxy);
    });
  });

  // Delete selected proxy
  deleteProxyButton.addEventListener('click', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      showMessage('请选择要删除的代理', 'warning');
      return;
    }
    
    chrome.storage.sync.get(['proxies', 'currentProxy', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      
      proxies.splice(selectedIndex, 1);
      
      const updates = {proxies: proxies};
      
      if (data.isProxyEnabled && data.currentProxy === selectedIndex) {
        updates.isProxyEnabled = false;
        
        chrome.proxy.settings.set({
          value: {mode: 'direct'},
          scope: 'regular'
        });
      }
      
      if (data.currentProxy > selectedIndex) {
        updates.currentProxy = data.currentProxy - 1;
      }
      
      chrome.storage.sync.set(updates, function() {
        loadProxies();
        updateStatusIndicator(false);
      });
    });
  });
  
  // Toggle proxy status
  toggleButton.addEventListener('click', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      showMessage('请选择要使用的代理', 'warning');
      return;
    }
    
    chrome.storage.sync.get(['proxies', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      const currentProxy = proxies[selectedIndex];
      const newState = !data.isProxyEnabled;
      
      chrome.runtime.sendMessage({
        action: 'toggleProxy',
        enable: newState,
        proxyConfig: {
          type: currentProxy.type,
          host: currentProxy.host,
          port: currentProxy.port,
          username: currentProxy.username,
          password: currentProxy.password
        }
      }, function(response) {
        if (response && response.success) {
          chrome.storage.sync.set({
            isProxyEnabled: newState,
            currentProxy: selectedIndex
          }, function() {
            updateStatusIndicator(newState);
            toggleButton.textContent = newState ? '禁用代理' : '启用代理';
            toggleButton.className = newState ? 'btn-danger' : 'btn-success';
          });
        }
      });
    });
  });
  
  // Proxy selection change with auto-toggle
  proxySelect.addEventListener('change', function() {
    const selectedIndex = proxySelect.selectedIndex;
    
    if (selectedIndex === -1) {
      return;
    }
    
    chrome.storage.sync.get(['isProxyEnabled', 'currentProxy', 'autoToggleProxy', 'proxies'], function(data) {
      const shouldAutoToggle = data.autoToggleProxy !== false;
      
      if (data.isProxyEnabled && data.currentProxy === selectedIndex) {
        toggleButton.textContent = '禁用代理';
        toggleButton.className = 'btn-danger';
      } else {
        toggleButton.textContent = '启用代理';
        toggleButton.className = 'btn-success';
        
        if (shouldAutoToggle && selectedIndex !== data.currentProxy) {
          const currentProxy = data.proxies[selectedIndex];
          
          chrome.runtime.sendMessage({
            action: 'toggleProxy',
            enable: true,
            proxyConfig: {
              type: currentProxy.type,
              host: currentProxy.host,
              port: currentProxy.port,
              username: currentProxy.username,
              password: currentProxy.password
            }
          }, function(response) {
            if (response && response.success) {
              chrome.storage.sync.set({
                isProxyEnabled: true,
                currentProxy: selectedIndex
              }, function() {
                updateStatusIndicator(true);
                toggleButton.textContent = '禁用代理';
                toggleButton.className = 'btn-danger';
              });
            }
          });
        }
      }
    });
  });
  
  // Whitelist functions
  removeWhitelistButton.addEventListener('click', removeFromWhitelist);
  batchAddWhitelistButton.addEventListener('click', batchAddToWhitelist);
  clearWhitelistButton.addEventListener('click', clearWhitelist);
  
  // GFWList functions
  updateGfwlistButton.addEventListener('click', updateGfwlist);
  toggleGfwlistButton.addEventListener('click', toggleGfwlist);
  
  // Load proxy list
  function loadProxies() {
    chrome.storage.sync.get(['proxies', 'currentProxy', 'isProxyEnabled'], function(data) {
      const proxies = data.proxies || [];
      
      proxySelect.innerHTML = '';
      
      proxies.forEach(function(proxy, index) {
        const option = document.createElement('option');
        option.value = index;
        const authBadge = (proxy.username && proxy.password) ? ' 🔒' : '';
        option.textContent = `${proxy.name} - ${proxy.type.toUpperCase()} ${proxy.host}:${proxy.port}${authBadge}`;
        proxySelect.appendChild(option);
      });
      
      if (proxies.length === 0) {
        toggleButton.disabled = true;
        deleteProxyButton.disabled = true;
        
        const option = document.createElement('option');
        option.disabled = true;
        option.textContent = '没有可用的代理';
        proxySelect.appendChild(option);
        
        updateStatusIndicator(false);
      } else {
        toggleButton.disabled = false;
        deleteProxyButton.disabled = false;
        
        if (data.isProxyEnabled && data.currentProxy !== undefined) {
          proxySelect.selectedIndex = data.currentProxy;
          toggleButton.textContent = '禁用代理';
          toggleButton.className = 'btn-danger';
          updateStatusIndicator(true);
        } else {
          proxySelect.selectedIndex = 0;
          toggleButton.textContent = '启用代理';
          toggleButton.className = 'btn-success';
          updateStatusIndicator(false);
        }
      }
    });
  }
  
  // Load whitelist
  function loadWhitelist() {
    chrome.runtime.sendMessage(
      { action: 'getWhitelist' },
      function(response) {
        whitelistItemsSelect.innerHTML = '';
        
        if (response && response.whitelist && response.whitelist.length > 0) {
          response.whitelist.forEach(function(domain) {
            const option = document.createElement('option');
            option.value = domain;
            option.textContent = domain;
            whitelistItemsSelect.appendChild(option);
          });
        } else {
          const option = document.createElement('option');
          option.disabled = true;
          option.textContent = '白名单为空';
          whitelistItemsSelect.appendChild(option);
        }
      }
    );
  }
  
  // Update status indicator
  function updateStatusIndicator(isEnabled) {
    if (!statusIndicator) return;
    
    if (isEnabled) {
      statusIndicator.textContent = '代理已启用';
      statusIndicator.className = 'status-enabled';
    } else {
      statusIndicator.textContent = '代理已禁用';
      statusIndicator.className = 'status-disabled';
    }
  }
  
  // Whitelist operations
  function removeFromWhitelist() {
    const selectedIndex = whitelistItemsSelect.selectedIndex;
    if (selectedIndex === -1) {
      showMessage('请选择要移除的域名', 'warning');
      return;
    }
    
    const domain = whitelistItemsSelect.options[selectedIndex].value;
    chrome.runtime.sendMessage(
      { action: 'removeFromWhitelist', domain: domain },
      function(response) {
        if (response && response.success) {
          loadWhitelist();
          showMessage('域名已成功移除', 'success');
        } else {
          showMessage('移除失败', 'error');
        }
      }
    );
  }
  
  function batchAddToWhitelist() {
    const batchText = batchWhitelistInput.value.trim();
    if (!batchText) {
      showMessage('请输入要批量添加的域名', 'warning');
      return;
    }
    
    const domains = batchText.split('\n').map(d => d.trim()).filter(d => d);
    
    if (domains.length === 0) {
      showMessage('未找到有效的域名', 'warning');
      return;
    }
    
    chrome.runtime.sendMessage(
      { action: 'batchAddToWhitelist', domains: domains },
      function(response) {
        if (response && response.success) {
          batchWhitelistInput.value = '';
          loadWhitelist();
          showMessage(`成功添加 ${domains.length} 个域名`, 'success');
        } else {
          showMessage('批量添加失败', 'error');
        }
      }
    );
  }
  
  function clearWhitelist() {
    if (confirm('确定要清空所有白名单域名吗？此操作不可撤销。')) {
      chrome.runtime.sendMessage(
        { action: 'clearWhitelist' },
        function(response) {
          if (response && response.success) {
            loadWhitelist();
            showMessage('白名单已清空', 'success');
          } else {
            showMessage('清空白名单失败', 'error');
          }
        }
      );
    }
  }
  

  // GFWList operations
  function loadGfwlistStatus() {
    if (!gfwlistStatus) return;

    chrome.runtime.sendMessage(
      { action: 'getGfwlistStatus' },
      function(response) {
        if (!response) {
          gfwlistStatus.textContent = '无法读取 GFWList 状态';
          return;
        }

        gfwlistUrlInput.value = response.url || gfwlistUrlInput.value;
        toggleGfwlistButton.dataset.enabled = response.enabled ? 'true' : 'false';
        toggleGfwlistButton.textContent = response.enabled ? '停用 GFWList 模式' : '启用 GFWList 模式';
        toggleGfwlistButton.className = response.enabled ? 'btn-danger' : 'btn-success';

        const updatedAt = response.updatedAt ? new Date(response.updatedAt).toLocaleString() : '未更新';
        const mode = response.enabled ? '已启用' : '未启用';
        const cache = response.hasRules ?
          `代理域名: ${response.proxyDomains} 条，直连例外: ${response.directDomains} 条` :
          '尚未解析规则缓存';
        const meta = response.title ? `\n列表: ${response.title}` : '';
        const lastModified = response.lastModified ? `\n上游: ${response.lastModified}` : '';

        gfwlistStatus.textContent = `模式: ${mode}\n缓存: ${cache}\n本地更新: ${updatedAt}${meta}${lastModified}`;
      }
    );
  }

  function updateGfwlist() {
    const url = gfwlistUrlInput.value.trim();
    updateGfwlistButton.disabled = true;
    updateGfwlistButton.textContent = '更新中...';
    gfwlistStatus.textContent = '正在下载并解析 GFWList...';

    chrome.runtime.sendMessage(
      { action: 'updateGfwlist', url: url },
      function(response) {
        updateGfwlistButton.disabled = false;
        updateGfwlistButton.textContent = '更新/解析 GFWList';

        if (response && response.success) {
          const status = response.status || {};
          showMessage(`GFWList 解析完成: ${status.proxyDomains || 0} 条代理域名`, 'success');
          loadGfwlistStatus();
        } else {
          gfwlistStatus.textContent = 'GFWList 更新失败';
          showMessage((response && response.message) || 'GFWList 更新失败', 'error');
        }
      }
    );
  }

  function toggleGfwlist() {
    const nextEnabled = toggleGfwlistButton.dataset.enabled !== 'true';
    toggleGfwlistButton.disabled = true;

    chrome.runtime.sendMessage(
      { action: 'setGfwlistEnabled', enabled: nextEnabled },
      function(response) {
        toggleGfwlistButton.disabled = false;

        if (response && response.success) {
          showMessage(response.message || 'GFWList 设置已更新', 'success');
          loadGfwlistStatus();
        } else {
          showMessage((response && response.message) || 'GFWList 设置失败', 'error');
          loadGfwlistStatus();
        }
      }
    );
  }

  // Check current proxy state
  chrome.runtime.sendMessage({action: 'getProxyState'}, function(response) {
    if (response) {
      updateStatusIndicator(response.isEnabled);
    }
  });
});

// Show message function
function showMessage(message, type = 'error') {
  const container = document.getElementById('message-container');
  container.textContent = message;
  container.className = `message-container message-${type} message-show`;
  
  setTimeout(() => {
    container.className = 'message-container';
  }, 3000);
}
