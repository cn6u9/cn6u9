const DEFAULT_GFWLIST_URL = 'https://raw.githubusercontent.com/gfwlist/gfwlist/refs/heads/master/gfwlist.txt';
const DEFAULT_PROXIES = [
  { name: 'proxy', type: 'socks5', host: '127.0.0.1', port: 7891 },
  { name: 'trojan', type: 'socks5', host: '127.0.0.1', port: 7892 },
  { name: 'anytls', type: 'socks5', host: '127.0.0.1', port: 7893 }
];
const DEFAULT_WHITELIST = ['192.168.0.240', 'example.com', 'localhost'];

// Initialize on install/update without overwriting existing user settings.
chrome.runtime.onInstalled.addListener((details) => {
  const defaults = {
    proxies: DEFAULT_PROXIES,
    isProxyEnabled: false,
    currentProxy: 0,
    whitelist: DEFAULT_WHITELIST,
    autoToggleProxy: true,
    gfwlistEnabled: false,
    gfwlistUrl: DEFAULT_GFWLIST_URL
  };

  chrome.storage.sync.get(Object.keys(defaults), function(data) {
    const updates = {};
    Object.keys(defaults).forEach(function(key) {
      if (typeof data[key] === 'undefined') {
        updates[key] = defaults[key];
      }
    });

    chrome.storage.sync.set(updates, function() {
      console.log('Default settings are ready');
    });
  });

  if (details.reason === 'install') {
    chrome.proxy.settings.set({
      value: { mode: 'direct' },
      scope: 'regular'
    });
  }
});

// Message handling
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'toggleProxy') {
    updateProxySettings(request.enable, request.proxyConfig);
    sendResponse({success: true});
  } else if (request.action === 'getProxyState') {
    chrome.proxy.settings.get({}, function(config) {
      sendResponse({
        isEnabled: config.value.mode !== 'direct',
        currentConfig: config.value
      });
    });
    return true;
  } else if (request.action === 'addToWhitelist') {
    addToWhitelist(request.domain, sendResponse);
    return true;
  } else if (request.action === 'removeFromWhitelist') {
    removeFromWhitelist(request.domain, sendResponse);
    return true;
  } else if (request.action === 'getWhitelist') {
    getWhitelist(sendResponse);
    return true;
  } else if (request.action === 'batchAddToWhitelist') {
    batchAddToWhitelist(request.domains, sendResponse);
    return true;
  } else if (request.action === 'clearWhitelist') {
    clearWhitelist(sendResponse);
    return true;
  } else if (request.action === 'updateGfwlist') {
    updateGfwlist(request.url, sendResponse);
    return true;
  } else if (request.action === 'getGfwlistStatus') {
    getGfwlistStatus(sendResponse);
    return true;
  } else if (request.action === 'setGfwlistEnabled') {
    setGfwlistEnabled(request.enabled, sendResponse);
    return true;
  }
});

// Whitelist functions
function addToWhitelist(domain, callback) {
  if (!domain) {
    callback({success: false, message: 'Domain cannot be empty'});
    return;
  }

  domain = formatDomain(domain);
  if (!domain) {
    callback({success: false, message: 'Invalid domain'});
    return;
  }

  chrome.storage.sync.get(['whitelist'], function(data) {
    let whitelist = data.whitelist || [];

    if (whitelist.includes(domain)) {
      callback({success: false, message: 'Domain already exists in whitelist'});
      return;
    }

    whitelist.push(domain);
    chrome.storage.sync.set({whitelist: whitelist}, function() {
      reapplyProxyIfEnabled(function() {
        callback({success: true, whitelist: whitelist});
      });
    });
  });
}

function removeFromWhitelist(domain, callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    let whitelist = data.whitelist || [];
    whitelist = whitelist.filter(item => item !== domain);

    chrome.storage.sync.set({whitelist: whitelist}, function() {
      reapplyProxyIfEnabled(function() {
        callback({success: true, whitelist: whitelist});
      });
    });
  });
}

function getWhitelist(callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    callback({whitelist: data.whitelist || []});
  });
}

function batchAddToWhitelist(domains, callback) {
  chrome.storage.sync.get(['whitelist'], function(data) {
    const whitelist = data.whitelist || [];
    const newDomains = (domains || [])
      .map(formatDomain)
      .filter(Boolean)
      .filter(d => !whitelist.includes(d));

    if (newDomains.length === 0) {
      callback({success: false, message: 'All domains already exist in whitelist'});
      return;
    }

    const newWhitelist = [...whitelist, ...newDomains];
    chrome.storage.sync.set({whitelist: newWhitelist}, function() {
      reapplyProxyIfEnabled(function() {
        callback({success: true, added: newDomains.length});
      });
    });
  });
}

function clearWhitelist(callback) {
  chrome.storage.sync.set({whitelist: []}, function() {
    reapplyProxyIfEnabled(function() {
      callback({success: true});
    });
  });
}

function formatDomain(domain) {
  domain = String(domain || '').trim();
  domain = domain.replace(/^(https?:\/\/)?(www\.)?/i, '');
  domain = domain.split(/[\/?#]/)[0];
  return normalizeDomainForPac(domain);
}

// GFWList download/parse/cache functions
function updateGfwlist(url, callback) {
  const sourceUrl = String(url || DEFAULT_GFWLIST_URL).trim() || DEFAULT_GFWLIST_URL;
  if (!/^https?:\/\//i.test(sourceUrl)) {
    callback({success: false, message: 'GFWList URL must start with http:// or https://'});
    return;
  }

  fetchWithTimeout(sourceUrl, 20000)
    .then(function(response) {
      if (!response.ok) {
        throw new Error('Download failed: HTTP ' + response.status);
      }
      return response.text();
    })
    .then(function(text) {
      const rules = parseGfwList(text);
      if (!rules.proxyDomains.length) {
        throw new Error('No usable proxy domain rules were parsed');
      }

      rules.url = sourceUrl;
      rules.updatedAt = Date.now();

      chrome.storage.local.set({gfwlistRules: rules}, function() {
        if (chrome.runtime.lastError) {
          callback({success: false, message: chrome.runtime.lastError.message});
          return;
        }

        chrome.storage.sync.set({gfwlistUrl: sourceUrl}, function() {
          reapplyProxyIfEnabled(function() {
            callback({
              success: true,
              message: 'GFWList was updated and parsed',
              status: summarizeGfwlistRules(rules, undefined, sourceUrl)
            });
          });
        });
      });
    })
    .catch(function(error) {
      callback({success: false, message: error.message || String(error)});
    });
}

function getGfwlistStatus(callback) {
  chrome.storage.sync.get(['gfwlistEnabled', 'gfwlistUrl'], function(syncData) {
    chrome.storage.local.get(['gfwlistRules'], function(localData) {
      callback(summarizeGfwlistRules(
        localData.gfwlistRules,
        syncData.gfwlistEnabled === true,
        syncData.gfwlistUrl || DEFAULT_GFWLIST_URL
      ));
    });
  });
}

function setGfwlistEnabled(enabled, callback) {
  const nextEnabled = enabled === true;

  if (nextEnabled) {
    chrome.storage.local.get(['gfwlistRules'], function(localData) {
      const rules = localData.gfwlistRules;
      if (!rules || !Array.isArray(rules.proxyDomains) || rules.proxyDomains.length === 0) {
        callback({success: false, message: 'Please update/parse GFWList first to create the local rule cache'});
        return;
      }

      persistGfwlistEnabled(nextEnabled, callback);
    });
  } else {
    persistGfwlistEnabled(nextEnabled, callback);
  }
}

function persistGfwlistEnabled(enabled, callback) {
  chrome.storage.sync.set({gfwlistEnabled: enabled}, function() {
    reapplyProxyIfEnabled(function(result) {
      callback({
        success: !result || result.success !== false,
        enabled: enabled,
        message: enabled ? 'GFWList smart proxy is enabled' : 'GFWList smart proxy is disabled'
      });
    });
  });
}

function fetchWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(function() {
    controller.abort();
  }, timeoutMs);

  return fetch(url, {cache: 'no-store', signal: controller.signal})
    .finally(function() {
      clearTimeout(timer);
    });
}

function parseGfwList(content) {
  const decodedText = decodeGfwListText(content).replace(/^\uFEFF/, '');
  const lines = decodedText.split(/\r?\n/);
  const proxyDomains = new Set();
  const directDomains = new Set();
  let parsedRules = 0;
  let unsupportedRules = 0;
  let title = '';
  let lastModified = '';
  let checksum = '';

  lines.forEach(function(rawLine) {
    let line = rawLine.trim();
    if (!line) {
      return;
    }

    if (line.startsWith('!')) {
      const titleMatch = line.match(/^!\s*Title:\s*(.+)$/i);
      const modifiedMatch = line.match(/^!\s*Last Modified:\s*(.+)$/i);
      const checksumMatch = line.match(/^!\s*Checksum:\s*(.+)$/i);
      if (titleMatch) title = titleMatch[1].trim();
      if (modifiedMatch) lastModified = modifiedMatch[1].trim();
      if (checksumMatch) checksum = checksumMatch[1].trim();
      return;
    }

    if (line.startsWith('[')) {
      return;
    }

    let isException = false;
    if (line.startsWith('@@')) {
      isException = true;
      line = line.slice(2).trim();
    }

    const optionIndex = line.indexOf('$');
    if (optionIndex >= 0) {
      line = line.slice(0, optionIndex).trim();
    }

    const domain = extractDomainFromGfwRule(line);
    if (domain) {
      (isException ? directDomains : proxyDomains).add(domain);
      parsedRules += 1;
    } else {
      unsupportedRules += 1;
    }
  });

  return {
    proxyDomains: Array.from(proxyDomains).sort(),
    directDomains: Array.from(directDomains).sort(),
    lineCount: lines.length,
    parsedRules: parsedRules,
    unsupportedRules: unsupportedRules,
    title: title,
    lastModified: lastModified,
    checksum: checksum
  };
}

function decodeGfwListText(content) {
  const text = String(content || '').trim();
  if (/^\[AutoProxy/i.test(text) || /(^|\n)\|\|/.test(text) || /(^|\n)!/.test(text)) {
    return text;
  }

  try {
    const binary = atob(text.replace(/\s+/g, ''));
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder('utf-8').decode(bytes);
  } catch (error) {
    console.warn('GFWList Base64 decode failed, parsing as plain text:', error);
    return text;
  }
}

function extractDomainFromGfwRule(rule) {
  let value = String(rule || '').trim();
  if (!value) return null;

  // Regex-only rules cannot be represented efficiently in this PAC fast path.
  if (value.startsWith('/') && value.lastIndexOf('/') > 0) {
    return null;
  }

  value = value.replace(/^\|\|/, '');
  value = value.replace(/^\|/, '');
  value = value.replace(/\|$/, '');
  value = value.replace(/^\*:\/\//, '');
  value = value.replace(/^[a-z][a-z0-9+.-]*:\/\//i, '');
  value = value.replace(/^\*\./, '');
  value = value.replace(/^\.+/, '');

  let candidate = value.split(/[\/\^\*\?#]/)[0];
  candidate = candidate.replace(/^\*\./, '').replace(/^\.+|\.+$/g, '');
  candidate = candidate.replace(/:\d+$/, '');

  let normalized = normalizeRuleDomain(candidate);
  if (normalized) {
    return normalized;
  }

  const matches = value.match(/[a-z0-9-]+(?:\.[a-z0-9-]+)+/ig);
  if (!matches) {
    return null;
  }

  matches.sort(function(a, b) {
    return b.length - a.length;
  });

  for (let i = 0; i < matches.length; i++) {
    normalized = normalizeRuleDomain(matches[i]);
    if (normalized) {
      return normalized;
    }
  }

  return null;
}

function normalizeRuleDomain(domain) {
  let value = String(domain || '').trim().toLowerCase();
  value = value.replace(/^\*\./, '').replace(/^\.+|\.+$/g, '');
  if (!value) return null;

  try {
    value = new URL('http://' + value).hostname.toLowerCase();
  } catch (error) {
    return null;
  }

  if (isIpv4(value)) {
    return value;
  }

  if (!value.includes('.') || value.length > 253) {
    return null;
  }

  const labels = value.split('.');
  for (let i = 0; i < labels.length; i++) {
    const label = labels[i];
    if (!label || label.length > 63) return null;
    if (!/^[a-z0-9-]+$/.test(label)) return null;
    if (label.startsWith('-') || label.endsWith('-')) return null;
  }

  return value;
}

function summarizeGfwlistRules(rules, enabled, url) {
  const hasRules = !!(rules && Array.isArray(rules.proxyDomains) && rules.proxyDomains.length > 0);
  return {
    enabled: enabled === true,
    url: url || (rules && rules.url) || DEFAULT_GFWLIST_URL,
    hasRules: hasRules,
    proxyDomains: hasRules ? rules.proxyDomains.length : 0,
    directDomains: hasRules && Array.isArray(rules.directDomains) ? rules.directDomains.length : 0,
    lineCount: hasRules ? (rules.lineCount || 0) : 0,
    parsedRules: hasRules ? (rules.parsedRules || 0) : 0,
    unsupportedRules: hasRules ? (rules.unsupportedRules || 0) : 0,
    updatedAt: hasRules ? (rules.updatedAt || 0) : 0,
    title: hasRules ? (rules.title || '') : '',
    lastModified: hasRules ? (rules.lastModified || '') : '',
    checksum: hasRules ? (rules.checksum || '') : ''
  };
}

// Proxy settings
function updateProxySettings(enable, proxyConfig, callback) {
  if (enable && proxyConfig) {
    chrome.storage.sync.get(['whitelist', 'gfwlistEnabled'], function(data) {
      const whitelist = normalizeDomainList(data.whitelist || []);

      if (data.gfwlistEnabled === true) {
        chrome.storage.local.get(['gfwlistRules'], function(localData) {
          const rules = localData.gfwlistRules;
          if (rules && Array.isArray(rules.proxyDomains) && rules.proxyDomains.length > 0) {
            const pacScript = buildGfwlistPacScript(proxyConfig, whitelist, rules);
            setProxyConfig({
              mode: 'pac_script',
              pacScript: { data: pacScript }
            }, enable, callback);
          } else {
            console.warn('GFWList cache is empty; falling back to the original full-proxy mode');
            applyOriginalProxySettings(proxyConfig, whitelist, enable, callback);
          }
        });
      } else {
        applyOriginalProxySettings(proxyConfig, whitelist, enable, callback);
      }
    });
  } else {
    setProxyConfig({ mode: 'direct' }, false, callback);
  }
}

function applyOriginalProxySettings(proxyConfig, whitelist, enable, callback) {
  const scheme = String(proxyConfig.type || 'http').toLowerCase();
  const bypassList = ['<local>', 'localhost', '127.0.0.1'].concat(buildFixedServerBypassList(whitelist));

  if (scheme === 'socks5' && proxyConfig.username && proxyConfig.password) {
    const proxyReturn = `SOCKS5 ${proxyConfig.username}:${proxyConfig.password}@${proxyConfig.host}:${proxyConfig.port}`;
    const pacScript = buildManualBypassPacScript(whitelist, proxyReturn);
    setProxyConfig({
      mode: 'pac_script',
      pacScript: { data: pacScript }
    }, enable, callback);
  } else {
    setProxyConfig({
      mode: 'fixed_servers',
      rules: {
        singleProxy: {
          scheme: scheme,
          host: proxyConfig.host,
          port: parseInt(proxyConfig.port, 10)
        },
        bypassList: bypassList
      }
    }, enable, callback);
  }
}

function setProxyConfig(config, enable, callback) {
  chrome.proxy.settings.set({
    value: config,
    scope: 'regular'
  }, function() {
    if (chrome.runtime.lastError) {
      console.error('Proxy settings error:', chrome.runtime.lastError);
      if (callback) callback({success: false, message: chrome.runtime.lastError.message});
    } else {
      console.log('Proxy settings updated:', enable ? 'enabled' : 'disabled');
      chrome.storage.sync.set({ isProxyEnabled: enable }, function() {
        if (callback) callback({success: true});
      });
    }
  });
}

function reapplyProxyIfEnabled(callback) {
  chrome.storage.sync.get(['isProxyEnabled', 'proxies', 'currentProxy'], function(data) {
    if (data.isProxyEnabled && data.proxies && data.proxies[data.currentProxy]) {
      updateProxySettings(true, data.proxies[data.currentProxy], callback);
    } else if (callback) {
      callback({success: true, applied: false});
    }
  });
}

function buildFixedServerBypassList(whitelist) {
  const formattedWhitelist = [];
  whitelist.forEach(function(domain) {
    formattedWhitelist.push(domain.startsWith('*.') ? domain : `*.${domain}`);
    formattedWhitelist.push(domain);
  });
  return formattedWhitelist;
}

function buildGfwlistPacScript(proxyConfig, whitelist, rules) {
  const directDomains = normalizeDomainList(whitelist.concat(rules.directDomains || []));
  const proxyDomains = normalizeDomainList(rules.proxyDomains || []);
  const directMap = domainListToMap(directDomains);
  const proxyMap = domainListToMap(proxyDomains);
  const proxyReturn = buildPacProxyReturn(proxyConfig);

  return buildPacScript(directMap, proxyMap, proxyReturn, true);
}

function buildManualBypassPacScript(whitelist, proxyReturn) {
  const directMap = domainListToMap(normalizeDomainList(whitelist));
  return buildPacScript(directMap, {}, proxyReturn, false);
}

function buildPacScript(directMap, proxyMap, proxyReturn, defaultDirect) {
  return `
var directDomains = ${JSON.stringify(directMap)};
var proxyDomains = ${JSON.stringify(proxyMap)};

function isLocalHost(host) {
  return isPlainHostName(host) ||
    host === "localhost" ||
    shExpMatch(host, "127.*") ||
    host === "::1";
}

function hostInMap(host, map) {
  if (!host) return false;
  host = host.toLowerCase();
  if (map[host]) return true;

  var parts = host.split(".");
  for (var i = 1; i < parts.length - 1; i++) {
    var suffix = parts.slice(i).join(".");
    if (map[suffix]) return true;
  }

  return false;
}

function FindProxyForURL(url, host) {
  host = (host || "").toLowerCase();

  if (isLocalHost(host) || hostInMap(host, directDomains)) {
    return "DIRECT";
  }

  if (hostInMap(host, proxyDomains)) {
    return ${JSON.stringify(proxyReturn)};
  }

  return ${defaultDirect ? '"DIRECT"' : JSON.stringify(proxyReturn)};
}
`;
}

function buildPacProxyReturn(proxyConfig) {
  const scheme = String(proxyConfig.type || 'http').toLowerCase();
  const host = String(proxyConfig.host || '').trim();
  const port = parseInt(proxyConfig.port, 10);

  if (scheme === 'socks5') {
    return `SOCKS5 ${host}:${port}`;
  }
  if (scheme === 'socks4') {
    return `SOCKS ${host}:${port}`;
  }
  if (scheme === 'https') {
    return `HTTPS ${host}:${port}`;
  }
  return `PROXY ${host}:${port}`;
}

function normalizeDomainList(domains) {
  const result = [];
  const seen = {};
  (domains || []).forEach(function(domain) {
    const normalized = normalizeDomainForPac(domain);
    if (normalized && !seen[normalized]) {
      seen[normalized] = true;
      result.push(normalized);
    }
  });
  return result;
}

function normalizeDomainForPac(domain) {
  let value = String(domain || '').trim().toLowerCase();
  value = value.replace(/^\*\./, '').replace(/^\.+|\.+$/g, '');
  value = value.replace(/:\d+$/, '');
  return value;
}

function domainListToMap(domains) {
  const map = {};
  (domains || []).forEach(function(domain) {
    const normalized = normalizeDomainForPac(domain);
    if (normalized) {
      map[normalized] = 1;
    }
  });
  return map;
}

function isIpv4(host) {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host);
}

// Handle proxy authentication
chrome.webRequest.onAuthRequired.addListener(
  function(details, callbackFn) {
    if (details.isProxy) {
      chrome.storage.sync.get(['proxies', 'currentProxy'], function(data) {
        if (data.proxies && data.proxies[data.currentProxy]) {
          const currentProxy = data.proxies[data.currentProxy];
          if (currentProxy.username && currentProxy.password) {
            callbackFn({
              authCredentials: {
                username: currentProxy.username,
                password: currentProxy.password
              }
            });
            return;
          }
        }
        callbackFn({});
      });
    } else {
      callbackFn({});
    }
  },
  {urls: ["<all_urls>"]},
  ["asyncBlocking"]
);


// Random header augmentation from the original extension.
// In MV3, blocking webRequest may be unavailable outside managed installs; keep
// the rest of the proxy/GFWList logic alive if the browser rejects this listener.
try {
chrome.webRequest.onBeforeSendHeaders.addListener(
  function(details) {
    const headers = details.requestHeaders;

    const randomString = () => Math.random().toString(36).substring(2, 10) + Date.now().toString(36);

    headers.push({ name: "X-Random-ID", value: randomString() });
    headers.push({ name: "X-Fake-Referer", value: "https://www.google.com" });
    headers.push({ name: "X-Session-Token", value: randomString() });
    headers.push({ name: "X-Client-Fingerprint", value: btoa(randomString()) });
    headers.push({ name: "X-Requested-With", value: "XMLHttpRequest" });
    headers.push({ name: "Accept-Language", value: "zh-CN,zh;q=0.9,en;q=0.8" });
    headers.push({ name: "DNT", value: "1" });

    const userAgents = [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",
      "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0",
      "Mozilla/5.0 (Linux; Android 11; SM-G9730) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    ];
    const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];

    let uaFound = false;
    for (let i = 0; i < headers.length; i++) {
      if (headers[i].name.toLowerCase() === 'user-agent') {
        headers[i].value = randomUA;
        uaFound = true;
        break;
      }
    }
    if (!uaFound) {
      headers.push({ name: 'User-Agent', value: randomUA });
    }

    return { requestHeaders: headers };
  },
  { urls: ["<all_urls>"] },
  ["blocking", "requestHeaders"]
);
} catch (error) {
  console.warn('Header augmentation listener is disabled:', error);
}
