# Capture the Ghost

Shell Manager.

## 命令执行

## 文件管理

> There is no Ghost in the shell.

## 

## Docker 

```bash
docker build --no-cache -t ctg:latest .
```