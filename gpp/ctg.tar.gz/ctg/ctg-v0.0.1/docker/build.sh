#!/bin/bash

# CTG Docker Build Script for Linux/macOS
# Build and run Docker image

set -e

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_message() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Project configuration
PROJECT_NAME="ctg"
VERSION=$(date +%Y%m%d_%H%M%S)
DOCKER_IMAGE="${PROJECT_NAME}:${VERSION}"
DOCKER_IMAGE_LATEST="${PROJECT_NAME}:latest"

# Show help
show_help() {
    echo "CTG Docker Build Script"
    echo ""
    echo "Usage: $0 [option]"
    echo ""
    echo "Options:"
    echo "  build     Build Docker image"
    echo "  run       Run Docker container"
    echo "  stop      Stop Docker container"
    echo "  restart   Restart Docker container"
    echo "  logs      View container logs"
    echo "  clean     Clean Docker resources"
    echo "  help      Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 build     # Build image"
    echo "  $0 run       # Run container"
    echo "  $0 stop      # Stop container"
}

# Check if command exists
check_command() {
    if ! command -v $1 &> /dev/null; then
        print_message $RED "Error: $1 command not found, please install $1 first"
        exit 1
    fi
}

# Build Docker image
build_image() {
    print_message $BLUE "Building Docker image..."
    
    if [ ! -f "Dockerfile" ]; then
        print_message $RED "Error: Dockerfile not found"
        exit 1
    fi
    
    print_message $YELLOW "Building image: ${DOCKER_IMAGE}"
    docker build -t ${DOCKER_IMAGE} -t ${DOCKER_IMAGE_LATEST} .
    
    if [ $? -eq 0 ]; then
        print_message $GREEN "Image build successful!"
        print_message $GREEN "Image tag: ${DOCKER_IMAGE}"
        print_message $GREEN "Latest tag: ${DOCKER_IMAGE_LATEST}"
    else
        print_message $RED "Image build failed"
        exit 1
    fi
}

# Run container
run_container() {
    print_message $BLUE "Starting CTG service..."
    
    if ! docker image inspect ${DOCKER_IMAGE_LATEST} &> /dev/null; then
        print_message $YELLOW "Image not found, building..."
        build_image
    fi
    
    docker-compose up -d
    
    if [ $? -eq 0 ]; then
        print_message $GREEN "Service started successfully!"
        print_message $GREEN "Access URL: http://localhost:8080"
        print_message $YELLOW "View logs: $0 logs"
    else
        print_message $RED "Service start failed"
        exit 1
    fi
}

# Stop container
stop_container() {
    print_message $YELLOW "Stopping CTG service..."
    docker-compose down
    print_message $GREEN "Service stopped"
}

# Restart container
restart_container() {
    print_message $YELLOW "Restarting CTG service..."
    docker-compose restart
    print_message $GREEN "Service restarted"
}

# Show logs
show_logs() {
    print_message $BLUE "Viewing service logs..."
    docker-compose logs -f
}

# Clean Docker resources
clean_docker() {
    print_message $YELLOW "Cleaning Docker resources..."
    
    docker-compose down -v
    
    docker rmi ${DOCKER_IMAGE_LATEST} 2>/dev/null || true
    docker rmi ${DOCKER_IMAGE} 2>/dev/null || true
    
    docker image prune -f
    
    print_message $GREEN "Cleanup completed"
}

# Main function
main() {
    check_command docker
    check_command docker-compose
    
    case "${1:-}" in
        build)
            build_image
            ;;
        run)
            run_container
            ;;
        stop)
            stop_container
            ;;
        restart)
            restart_container
            ;;
        logs)
            show_logs
            ;;
        clean)
            clean_docker
            ;;
        help|-h|--help)
            show_help
            ;;
        "")
            show_help
            ;;
        *)
            print_message $RED "Error: Unknown option '$1'"
            show_help
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"