package main

import (
	"encoding/json"
	"fmt"
	"time"

	"ctg-api/models"
)

// 示例：使用WebShell服务执行命令
func main() {
	// 创建示例WebShell配置（基于您提供的代码示例）
	webshell := &models.WebShell{
		Id:           1,
		Name:         "测试Godzilla WebShell",
		ScriptType:   models.ScriptTypeJSP,
		WebShellType: models.WebShellTypeGodzilla,
		URL:          "http://192.168.1.135:9976/2.jsp",
		Pass:         "pass",
		Key:          "key",
		Crypto:       models.CryptoTypeJavaAESRaw,
		Encoding:     models.EncodingTypeUTF8,
		Status:       models.StatusEnabled,
		Group:        "测试组",
		Tag:          "godzilla,jsp",
		Notes:        "基于xiecat/wsm包的示例WebShell",
		UserAgent:    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
		CreatedAt:    time.Now(),
		UpdatedAt:    time.Now(),
	}

	// 打印WebShell配置
	fmt.Println("=== WebShell 配置 ===")
	webshellJSON, _ := json.MarshalIndent(webshell, "", "  ")
	fmt.Println(string(webshellJSON))

	// 模拟测试连接
	fmt.Println("\n=== 测试连接 ===")
	fmt.Printf("测试WebShell: %s (%s)\n", webshell.Name, webshell.URL)
	fmt.Printf("脚本类型: %s\n", webshell.ScriptType)
	fmt.Printf("WebShell类型: %s\n", webshell.WebShellType)
	fmt.Printf("加密方式: %s\n", webshell.Crypto)
	fmt.Printf("编码方式: %s\n", webshell.Encoding)

	// 模拟命令执行
	fmt.Println("\n=== 命令执行示例 ===")
	commands := []string{
		"whoami /priv",
		"echo 你好",
		"dir",
		"pwd",
		"ls -la",
	}

	for _, cmd := range commands {
		fmt.Printf("执行命令: %s\n", cmd)
		// 注意：这里只是模拟，实际执行需要真实的WebShell环境
		// 在实际使用中，您需要通过API接口调用：
		// POST /api/webshell/{id}/execute
		// {
		//   "command": "whoami /priv",
		//   "timeout": 30
		// }
		fmt.Printf("模拟执行结果: 命令 '%s' 已提交\n", cmd)
	}

	fmt.Println("\n=== 使用说明 ===")
	fmt.Println("1. 确保WebShell配置正确（URL、密码、密钥等）")
	fmt.Println("2. 确保目标服务器可访问")
	fmt.Println("3. 使用API接口执行命令：")
	fmt.Println("   POST /api/webshell/{id}/execute")
	fmt.Println("   {\"command\": \"whoami\", \"timeout\": 30}")
	fmt.Println("4. 使用API接口测试连接：")
	fmt.Println("   POST /api/webshell/{id}/test")
	fmt.Println("5. 查看命令历史：")
	fmt.Println("   GET /api/webshell/{id}/history")

	fmt.Println("\n=== 注意事项 ===")
	fmt.Println("- 请确保在安全环境中使用")
	fmt.Println("- 建议实现用户权限控制")
	fmt.Println("- 记录所有操作日志")
	fmt.Println("- 合理设置超时时间")

	// 创建不同类型的WebShell示例
	createWebShellExamples()
}

// 示例：创建不同类型的WebShell
func createWebShellExamples() {
	examples := []*models.WebShell{
		// Godzilla JSP
		models.NewGodzillaWebShell("Godzilla JSP", "http://example.com/shell.jsp", "pass", "key"),

		// Behinder JSP
		models.NewBehinderWebShell("Behinder JSP", "http://example.com/shell.jsp", "pass", "key"),

		// 自定义PHP
		models.NewCustomWebShell("Custom PHP", models.ScriptTypePHP, "http://example.com/shell.php", "pass"),

		// 自定义ASP
		models.NewCustomWebShell("Custom ASP", models.ScriptTypeASP, "http://example.com/shell.asp", "pass"),
	}

	fmt.Println("\n=== WebShell 创建示例 ===")
	for i, ws := range examples {
		fmt.Printf("示例 %d:\n", i+1)
		fmt.Printf("  名称: %s\n", ws.Name)
		fmt.Printf("  类型: %s\n", ws.WebShellType)
		fmt.Printf("  脚本: %s\n", ws.ScriptType)
		fmt.Printf("  URL: %s\n", ws.URL)
		fmt.Printf("  状态: %s\n", ws.Status)
		fmt.Println()
	}
}
