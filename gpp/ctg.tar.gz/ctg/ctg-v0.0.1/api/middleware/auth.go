package middleware

import (
	"github.com/gin-gonic/gin"
)

// AuthMiddleware 认证中间件
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// TODO: 暂时注释掉认证逻辑，方便测试
		// 后续可以在这里添加JWT token验证等认证逻辑

		/*
			// 从请求头获取用户ID
			uidStr := c.GetHeader("X-User-ID")
			if uidStr == "" {
				c.JSON(http.StatusUnauthorized, gin.H{
					"error":   "未授权",
					"message": "缺少用户ID",
				})
				c.Abort()
				return
			}

			uid, err := strconv.Atoi(uidStr)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{
					"error":   "参数错误",
					"message": "无效的用户ID",
				})
				c.Abort()
				return
			}

			// 将用户ID存储到上下文中，供后续处理器使用
			c.Set("userID", uid)
		*/

		// 测试阶段：设置一个默认用户ID
		c.Set("userID", 1)

		c.Next()
	}
}

// GetUserID 从上下文中获取用户ID
func GetUserID(c *gin.Context) int {
	if userID, exists := c.Get("userID"); exists {
		if uid, ok := userID.(int); ok {
			return uid
		}
	}
	return 1 // 默认返回用户ID 1
}

// RequireAuth 要求认证的中间件（暂时禁用）
func RequireAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		// TODO: 暂时禁用认证要求
		// 后续可以在这里添加强制认证逻辑
		c.Next()
	}
}
