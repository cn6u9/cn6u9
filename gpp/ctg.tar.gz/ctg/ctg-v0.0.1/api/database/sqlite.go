package database

import (
	"fmt"
	"log"
	"reflect"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"xorm.io/xorm"

	"ctg-api/config"
	"ctg-api/models"
)

var Engine *xorm.Engine
var DatabaseName string = "./ctg.db"

// containsString 检查字符串切片中是否包含指定字符串
func containsString(slice []string, item string) bool {
	for _, s := range slice {
		if s == item {
			return true
		}
	}
	return false
}

// ConnectDateBase 连接数据库
func ConnectDateBase() {
	var err error
	Engine, err = xorm.NewEngine("sqlite3", DatabaseName)
	if err != nil {
		log.Fatalf("连接sqlite3数据库失败: %v", err)
	}

	// 同步所有模型到数据库
	err = Engine.Sync2(
		new(models.User),
		new(models.WebShell),
		new(models.File),
		new(models.Listener),
		new(models.History),
	)
	if err != nil {
		log.Fatalf("初始化数据库失败: %v", err)
	}

	// 从配置中获取管理员信息
	username, password := config.GetCredentials()

	var user models.User
	exists, err := Engine.Where("username = ?", username).Get(&user)
	if !exists {
		// 如果不存在管理员用户，插入从配置中读取的用户信息
		defaultUser := &models.User{
			Username: username,
			Password: password,
		}

		err = InsertData(Engine, defaultUser)
		if err != nil {
			log.Fatalf("插入管理员用户失败: %v", err)
		}
		log.Printf("成功创建管理员用户: %s", username)
	} else {
		log.Printf("管理员用户已存在: %s", username)
	}
}

// InsertData 函数用于插入任意表的数据
func InsertData(engine *xorm.Engine, table interface{}) error {
	// 使用反射获取表的信息
	valueOfTable := reflect.ValueOf(table)
	if valueOfTable.Kind() != reflect.Ptr || valueOfTable.Elem().Kind() != reflect.Struct {
		return fmt.Errorf("table parameter must be a pointer to a struct")
	}

	// 同步数据库结构
	err := engine.Sync2(table)
	if err != nil {
		return fmt.Errorf("failed to sync database structure: %v", err)
	}

	// 插入数据
	_, err = engine.Insert(table)
	if err != nil {
		return fmt.Errorf("failed to insert data: %v", err)
	}

	return nil
}

// ExecuteSQL 执行SQL语句
func ExecuteSQL(engine *xorm.Engine, sql string, args ...interface{}) error {
	_, err := engine.Exec(sql, args)
	if err != nil {
		return fmt.Errorf("failed to execute SQL: %v", err)
	}
	return nil
}

// QuerySQL 查询SQL语句
func QuerySQL(engine *xorm.Engine, sql string, args ...interface{}) ([]map[string]string, error) {
	results, err := engine.QueryString(sql, args)
	if err != nil {
		return nil, fmt.Errorf("failed to query SQL: %v", err)
	}
	return results, nil
}

// GetWebShellList 获取WebShell列表
func GetWebShellList() ([]models.WebShell, error) {
	var webshells []models.WebShell
	err := Engine.Find(&webshells)
	return webshells, err
}

// GetWebShellByID 根据ID获取WebShell
func GetWebShellByID(id int) (*models.WebShell, error) {
	var webshell models.WebShell
	has, err := Engine.ID(id).Get(&webshell)
	if err != nil {
		return nil, err
	}
	if !has {
		return nil, fmt.Errorf("WebShell not found")
	}
	return &webshell, nil
}

// CreateWebShell 创建WebShell
func CreateWebShell(webshell *models.WebShell) error {
	webshell.CreatedAt = time.Now()
	webshell.UpdatedAt = time.Now()
	_, err := Engine.Insert(webshell)
	return err
}

// UpdateWebShell 更新WebShell
func UpdateWebShell(webshell *models.WebShell) error {
	webshell.UpdatedAt = time.Now()
	log.Printf("UpdateWebShell: 开始更新数据库，ID: %d, 数据: %+v", webshell.Id, webshell)

	// 检查数据库表结构
	tableInfo, err := Engine.TableInfo(new(models.WebShell))
	if err != nil {
		log.Printf("UpdateWebShell: 获取表结构失败: %v", err)
	} else {
		log.Printf("UpdateWebShell: 表结构: %+v", tableInfo)
		for _, col := range tableInfo.Columns() {
			log.Printf("UpdateWebShell: 列名: %s", col.Name)
		}
	}

	// 使用Cols方法只更新非空字段，避免覆盖其他字段
	// 获取webshell结构体的所有字段名
	updateCols := []string{"updated_at"}

	// 检查并添加需要更新的字段
	// 使用反射检查字段是否被设置（非零值）
	webshellValue := reflect.ValueOf(webshell).Elem()
	webshellType := webshellValue.Type()

	for i := 0; i < webshellValue.NumField(); i++ {
		field := webshellValue.Field(i)
		fieldType := webshellType.Field(i)

		// 跳过ID、CreatedAt、UpdatedAt等系统字段
		if fieldType.Name == "Id" || fieldType.Name == "CreatedAt" || fieldType.Name == "UpdatedAt" {
			continue
		}

		// 检查字段是否被设置（非零值）
		if !field.IsZero() {
			// 根据字段名添加对应的数据库列名
			switch fieldType.Name {
			case "Name":
				updateCols = append(updateCols, "name")
			case "ScriptType":
				updateCols = append(updateCols, "script_type")
			case "WebShellType":
				updateCols = append(updateCols, "webshell_type")
			case "URL":
				updateCols = append(updateCols, "url")
			case "Pass":
				updateCols = append(updateCols, "pass")
			case "Key":
				updateCols = append(updateCols, "key")
			case "Crypto":
				updateCols = append(updateCols, "crypto")
			case "Encoding":
				updateCols = append(updateCols, "encoding")
			case "Group":
				updateCols = append(updateCols, "group")
			case "Tag":
				updateCols = append(updateCols, "tag")
			case "Notes":
				updateCols = append(updateCols, "notes")
			case "UserAgent":
				updateCols = append(updateCols, "user_agent")
			case "ProxyAddress":
				updateCols = append(updateCols, "proxy_address")
			case "Status":
				updateCols = append(updateCols, "status")
			case "FirstConnectTime":
				updateCols = append(updateCols, "first_connect_time")
			case "LastConnectTime":
				updateCols = append(updateCols, "last_connect_time")
			case "ExternalIP":
				updateCols = append(updateCols, "external_ip")
			case "Location":
				updateCols = append(updateCols, "location")
			case "InternalIP":
				updateCols = append(updateCols, "internal_ip")
			case "Hostname":
				updateCols = append(updateCols, "hostname")
			case "Username":
				updateCols = append(updateCols, "username")
			case "Architecture":
				updateCols = append(updateCols, "architecture")
			case "OperatingSystem":
				updateCols = append(updateCols, "operating_system")
			case "DatabaseType":
				updateCols = append(updateCols, "database_type")
			case "ServerType":
				updateCols = append(updateCols, "server_type")
			}
		}
	}

	// 构建更新查询
	query := Engine.ID(webshell.Id).Cols(updateCols...)
	log.Printf("UpdateWebShell: 更新查询: %v", query)

	affected, err := query.Update(webshell)
	if err != nil {
		log.Printf("UpdateWebShell: 数据库更新失败，ID: %d, 错误: %v", webshell.Id, err)
		return err
	}

	log.Printf("UpdateWebShell: 数据库更新成功，ID: %d, 影响行数: %d", webshell.Id, affected)
	return nil
}

// DeleteWebShell 删除WebShell
func DeleteWebShell(id int) error {
	_, err := Engine.ID(id).Delete(new(models.WebShell))
	return err
}

// GetUserList 获取用户列表
func GetUserList() ([]models.User, error) {
	var users []models.User
	err := Engine.Find(&users)
	return users, err
}

// GetUserByUsername 根据用户名获取用户
func GetUserByUsername(username string) (*models.User, error) {
	var user models.User
	has, err := Engine.Where("username = ?", username).Get(&user)
	if err != nil {
		return nil, err
	}
	if !has {
		return nil, fmt.Errorf("用户不存在")
	}
	return &user, nil
}

// CreateUser 创建用户
func CreateUser(user *models.User) error {
	user.CreatedAt = time.Now()
	user.UpdatedAt = time.Now()
	_, err := Engine.Insert(user)
	return err
}

// UpdateUser 更新用户
func UpdateUser(user *models.User) error {
	user.UpdatedAt = time.Now()
	_, err := Engine.ID(user.Uid).Update(user)
	return err
}

// DeleteUser 删除用户
func DeleteUser(uid int) error {
	_, err := Engine.ID(uid).Delete(new(models.User))
	return err
}
