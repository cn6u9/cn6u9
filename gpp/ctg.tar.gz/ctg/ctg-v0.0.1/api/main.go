package main

import (
	"log"
	"os"

	"ctg-api/config"
	"ctg-api/database"
	"ctg-api/routes"

	"github.com/gin-gonic/gin"
)

func main() {
	// 初始化配置
	if err := config.InitConfig(); err != nil {
		log.Printf("配置初始化失败: %v", err)
	}

	// 初始化数据库连接
	database.ConnectDateBase()

	// 设置 Gin 模式
	if os.Getenv("GIN_MODE") == "release" {
		gin.SetMode(gin.ReleaseMode)
	}

	// 创建 Gin 实例
	r := gin.Default()

	// 获取配置
	port := config.GetPort()
	basePath := config.GetBasePath()
	domainName := config.GetDomainName()
	ip := config.GetIP()

	// 创建路由组，所有路由都需要包含 base_path
	apiGroup := r.Group(basePath)

	// 添加路由到组
	routes.SetupAllRoutes(apiGroup)

	// 添加 404 处理，对于不包含 base_path 的请求返回 404
	r.NoRoute(func(c *gin.Context) {
		c.JSON(404, gin.H{
			"error":   "Not Found",
			"message": "API endpoint not found. All endpoints must include the base path.",
		})
	})

	log.Printf("Server starting on %s (%s):%s with base path: %s", domainName, ip, port, basePath)
	if err := r.Run(ip + ":" + port); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}
