package controllers

import (
	"net/http"

	"ctg-api/config"

	"github.com/gin-gonic/gin"
)

// ConfigController 配置控制器
type ConfigController struct{}

// GetConfig 获取配置信息
func (cc *ConfigController) GetConfig(c *gin.Context) {
	configData := gin.H{
		"domain_name": config.GetDomainName(),
		"ip":          config.GetIP(),
		"port":        config.GetPort(),
		"base_path":   config.GetBasePath(),
		"database":    config.GetDatabase(),
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    configData,
		"message": "配置获取成功",
	})
}

// GetBasePath 仅获取base_path
func (cc *ConfigController) GetBasePath(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"base_path": config.GetBasePath(),
		},
		"message": "base_path获取成功",
	})
}
