package controllers

import (
	"net/http"

	"ctg-api/services"

	"github.com/gin-gonic/gin"
)

// UserController 用户控制器
type UserController struct {
	userService *services.UserService
}

// NewUserController 创建用户控制器实例
func NewUserController() *UserController {
	return &UserController{
		userService: services.NewUserService(),
	}
}

// Login 用户登录
func (c *UserController) Login(ctx *gin.Context) {
	var loginReq struct {
		Username string `json:"username" binding:"required"`
		Password string `json:"password" binding:"required"`
	}

	if err := ctx.ShouldBindJSON(&loginReq); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": err.Error(),
		})
		return
	}

	// 验证用户
	user, err := c.userService.AuthenticateUser(loginReq.Username, loginReq.Password)
	if err != nil {
		ctx.JSON(http.StatusUnauthorized, gin.H{
			"error":   "认证失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"message": "登录成功",
		"data": gin.H{
			"user": gin.H{
				"uid":      user.Uid,
				"username": user.Username,
				"nickname": user.Nickname,
			},
		},
	})
}

// GetUserInfo 获取用户信息
func (c *UserController) GetUserInfo(ctx *gin.Context) {
	// TODO: 暂时注释掉认证检查，方便测试
	// 后续可以在这里添加完整的JWT token验证等认证逻辑

	/*
		// 从请求头获取用户ID（实际应该从JWT token中解析）
		uidStr := ctx.GetHeader("X-User-ID")
		if uidStr == "" {
			ctx.JSON(http.StatusUnauthorized, gin.H{
				"error":   "未授权",
				"message": "缺少用户ID",
			})
			return
		}

		uid, err := strconv.Atoi(uidStr)
		if err != nil {
			ctx.JSON(http.StatusBadRequest, gin.H{
				"error":   "参数错误",
				"message": "无效的用户ID",
			})
			return
		}
	*/

	// 测试阶段：使用默认用户ID 1
	uid := 1

	user, err := c.userService.GetUserByID(uid)
	if err != nil {
		ctx.JSON(http.StatusNotFound, gin.H{
			"error":   "用户不存在",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data": gin.H{
			"uid":      user.Uid,
			"username": user.Username,
			"nickname": user.Nickname,
		},
	})
}

// Logout 用户登出
func (c *UserController) Logout(ctx *gin.Context) {
	// TODO: 实现会话清理
	ctx.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"message": "登出成功",
	})
}
