package controllers

import (
	"log"
	"net/http"
	"strconv"

	"ctg-api/models"
	"ctg-api/services"

	"github.com/gin-gonic/gin"
)

// WebShellController WebShell控制器
type WebShellController struct {
	webshellService *services.WebShellService
}

// NewWebShellController 创建WebShell控制器实例
func NewWebShellController() *WebShellController {
	return &WebShellController{
		webshellService: services.NewWebShellService(),
	}
}

// GetWebShellList 获取WebShell列表
func (c *WebShellController) GetWebShellList(ctx *gin.Context) {
	webshells, err := c.webshellService.GetWebShellList()
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "获取WebShell列表失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   webshells,
	})
}

// GetWebShellByID 根据ID获取WebShell
func (c *WebShellController) GetWebShellByID(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	webshell, err := c.webshellService.GetWebShellByID(id)
	if err != nil {
		ctx.JSON(http.StatusNotFound, gin.H{
			"error":   "WebShell不存在",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   webshell,
	})
}

// CreateWebShell 创建WebShell
func (c *WebShellController) CreateWebShell(ctx *gin.Context) {
	var webshell models.WebShell
	if err := ctx.ShouldBindJSON(&webshell); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": err.Error(),
		})
		return
	}

	err := c.webshellService.CreateWebShell(&webshell)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "创建WebShell失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"message": "WebShell创建成功",
		"data":    webshell,
	})
}

// UpdateWebShell 更新WebShell
func (c *WebShellController) UpdateWebShell(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		log.Printf("UpdateWebShell: 无效ID %s: %v", idStr, err)
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	log.Printf("UpdateWebShell: 开始更新ID %d", id)

	var webshell models.WebShell
	if err := ctx.ShouldBindJSON(&webshell); err != nil {
		log.Printf("UpdateWebShell: JSON绑定失败: %v", err)
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": err.Error(),
		})
		return
	}

	log.Printf("UpdateWebShell: 接收到的数据: %+v", webshell)
	log.Printf("UpdateWebShell: URL字段值: '%s'", webshell.URL)
	log.Printf("UpdateWebShell: URL字段长度: %d", len(webshell.URL))

	webshell.Id = id
	err = c.webshellService.UpdateWebShell(&webshell)
	if err != nil {
		log.Printf("UpdateWebShell: 服务层更新失败: %v", err)
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "更新WebShell失败",
			"message": err.Error(),
		})
		return
	}

	log.Printf("UpdateWebShell: 更新成功，ID %d", id)

	ctx.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"message": "WebShell更新成功",
		"data":    webshell,
	})
}

// DeleteWebShell 删除WebShell
func (c *WebShellController) DeleteWebShell(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	err = c.webshellService.DeleteWebShell(id)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "删除WebShell失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status":  "ok",
		"message": "WebShell删除成功",
	})
}

// TestConnection 测试WebShell连接
func (c *WebShellController) TestConnection(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	result, err := c.webshellService.TestConnection(id)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "测试连接失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   result,
	})
}

// TestBasicInfo 获取WebShell基础信息
func (c *WebShellController) TestBasicInfo(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	result, err := c.webshellService.GetBasicInfo(id)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "获取基础信息失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   result,
	})
}

// GetWebShellStats 获取WebShell统计信息
func (c *WebShellController) GetWebShellStats(ctx *gin.Context) {
	stats, err := c.webshellService.GetWebShellStats()
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "获取统计信息失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   stats,
	})
}

// GetCommandHistory 获取WebShell命令历史记录
func (c *WebShellController) GetCommandHistory(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	// 获取查询参数
	limitStr := ctx.DefaultQuery("limit", "50")
	offsetStr := ctx.DefaultQuery("offset", "0")

	limit, err := strconv.Atoi(limitStr)
	if err != nil {
		limit = 50
	}

	offset, err := strconv.Atoi(offsetStr)
	if err != nil {
		offset = 0
	}

	history, err := c.webshellService.GetCommandHistory(id, limit, offset)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "获取命令历史失败",
			"message": err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   history,
	})
}

// ExecuteCommand 执行WebShell命令
func (c *WebShellController) ExecuteCommand(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	var request struct {
		Command string `json:"command" binding:"required"`
		Timeout int    `json:"timeout"` // 超时时间（秒）
	}

	if err := ctx.ShouldBindJSON(&request); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": err.Error(),
		})
		return
	}

	// 设置默认超时时间
	if request.Timeout <= 0 {
		request.Timeout = 30
	}

	result, err := c.webshellService.ExecuteCommand(id, request.Command, request.Timeout)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "执行命令失败",
			"message": err.Error(),
		})
		return
	}

	// 确保执行时间被正确设置
	if result != nil {
		if executionTime, exists := result["executionTime"]; exists {
			// 如果服务层返回的执行时间为0，说明需要从结果中获取
			if executionTime == 0.0 {
				// 这里可以添加额外的逻辑来处理执行时间
				// 目前服务层已经处理了执行时间
			}
		}
	}

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data":   result,
	})
}

// GetFileList 获取WebShell文件列表
func (c *WebShellController) GetFileList(ctx *gin.Context) {
	log.Printf("GetFileList: 收到请求 - URL: %s, Method: %s", ctx.Request.URL.String(), ctx.Request.Method)

	idStr := ctx.Param("id")
	log.Printf("GetFileList: WebShell ID: %s", idStr)

	id, err := strconv.Atoi(idStr)
	if err != nil {
		log.Printf("GetFileList: 无效的ID %s: %v", idStr, err)
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error":   "参数错误",
			"message": "无效的ID",
		})
		return
	}

	// 获取路径参数，默认为根目录
	dirPath := ctx.DefaultQuery("path", "/")
	if dirPath == "" {
		dirPath = "/"
	}

	log.Printf("GetFileList: 请求路径 - WebShell ID: %d, Path: %s", id, dirPath)

	fileList, err := c.webshellService.GetFileList(id, dirPath)
	if err != nil {
		log.Printf("GetFileList: 服务层错误: %v", err)
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error":   "获取文件列表失败",
			"message": err.Error(),
		})
		return
	}

	log.Printf("GetFileList: 成功获取文件列表 - 数量: %d", len(fileList))

	ctx.JSON(http.StatusOK, gin.H{
		"status": "ok",
		"data": gin.H{
			"path":     dirPath,
			"fileList": fileList,
			"count":    len(fileList),
		},
	})
}
