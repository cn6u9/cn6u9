package config

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"

	"ctg-api/utils"
)

type Config struct {
	DomainName string `json:"domain_name"`
	IP         string `json:"ip"`
	Port       string `json:"port"`
	BasePath   string `json:"base_path"`
	Username   string `json:"username"`
	Password   string `json:"password"`
	Database   string `json:"database"`
}

var AppConfig Config

// 动态生成 URL
func generateURL() string {
	if AppConfig.DomainName != "" && AppConfig.DomainName != "localhost" {
		return fmt.Sprintf("http://%s:%s%s", AppConfig.DomainName, AppConfig.Port, AppConfig.BasePath)
	}
	return fmt.Sprintf("http://%s:%s%s", AppConfig.IP, AppConfig.Port, AppConfig.BasePath)
}

// 从配置文件读取配置
func loadConfigFromFile() error {
	configPath := "./ctg.conf"

	// 检查配置文件是否存在
	if _, err := os.Stat(configPath); os.IsNotExist(err) {
		log.Println("配置文件不存在，将创建默认配置")
		return nil
	}

	// 读取配置文件
	data, err := os.ReadFile(configPath)
	if err != nil {
		return fmt.Errorf("读取配置文件失败: %v", err)
	}

	// 解析JSON配置
	if err := json.Unmarshal(data, &AppConfig); err != nil {
		return fmt.Errorf("解析配置文件失败: %v", err)
	}

	log.Println("成功从配置文件加载配置")
	return nil
}

// 保存配置到文件
func saveConfigToFile() error {
	configPath := "./ctg.conf"

	// 确保配置目录存在
	configDir := filepath.Dir(configPath)
	if err := os.MkdirAll(configDir, 0755); err != nil {
		return fmt.Errorf("创建配置目录失败: %v", err)
	}

	// 将配置转换为JSON
	data, err := json.MarshalIndent(AppConfig, "", "  ")
	if err != nil {
		return fmt.Errorf("序列化配置失败: %v", err)
	}

	// 写入文件
	if err := os.WriteFile(configPath, data, 0644); err != nil {
		return fmt.Errorf("写入配置文件失败: %v", err)
	}

	log.Printf("配置已保存到: %s", configPath)
	return nil
}

// 初始化配置
func InitConfig() error {
	// 尝试从文件加载配置
	if err := loadConfigFromFile(); err != nil {
		log.Printf("加载配置文件失败: %v", err)
	}

	if AppConfig.Username == "" || AppConfig.Password == "" {
		username, password := utils.GenerateRandomCredentials()
		AppConfig.Username = username
		AppConfig.Password = password
		log.Printf("生成随机账号: %s, 密码: %s", username, password)
	}

	// 设置默认值
	if AppConfig.Port == "" {
		AppConfig.Port = strconv.Itoa(utils.GenerateRandomPort())
	}

	if AppConfig.Database == "" {
		AppConfig.Database = "./database.db"
	}

	// 设置默认的 domain_name 和 ip
	if AppConfig.DomainName == "" {
		AppConfig.DomainName = "localhost"
	}

	if AppConfig.IP == "" {
		AppConfig.IP = "127.0.0.1"
	}

	// 设置默认的 base_path
	if AppConfig.BasePath == "" {
		AppConfig.BasePath = "/" + utils.GenerateRandomPath()
	}

	// 保存配置到文件
	if err := saveConfigToFile(); err != nil {
		log.Printf("保存配置文件失败: %v", err)
	}

	log.Println("配置初始化完成")
	return nil
}

// 获取配置
func GetConfig() Config {
	return AppConfig
}

// 获取动态生成的 URL
func GetBaseURL() string {
	return generateURL()
}

// 获取账号信息
func GetCredentials() (string, string) {
	return AppConfig.Username, AppConfig.Password
}

// 获取端口
func GetPort() string {
	return AppConfig.Port
}

// 获取数据库路径
func GetDatabase() string {
	return AppConfig.Database
}

// 获取域名
func GetDomainName() string {
	return AppConfig.DomainName
}

// 获取IP地址
func GetIP() string {
	return AppConfig.IP
}

// 获取基础路径
func GetBasePath() string {
	return AppConfig.BasePath
}

// 更新配置
func UpdateConfig(newConfig Config) error {
	AppConfig = newConfig
	return saveConfigToFile()
}
