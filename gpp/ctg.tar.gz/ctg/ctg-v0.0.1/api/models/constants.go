package models

type WebShellTypeEnum string

// WebShell类型常量
const (
	WebShellTypeBehinder WebShellTypeEnum = "Behinder"
	WebShellTypeGodzilla WebShellTypeEnum = "Godzilla"
	WebShellTypeAntword  WebShellTypeEnum = "Antword"
	WebShellTypeCustom   WebShellTypeEnum = "Custom"
	WebShellTypeOther    WebShellTypeEnum = "Other"
)

type ScriptTypeEnum string

// 脚本类型常量
const (
	ScriptTypePHP   ScriptTypeEnum = "PHP"
	ScriptTypeASP   ScriptTypeEnum = "ASP"
	ScriptTypeASPX  ScriptTypeEnum = "ASPX"
	ScriptTypeJSP   ScriptTypeEnum = "JSP"
	ScriptTypeJSPX  ScriptTypeEnum = "JSPX"
	ScriptTypeOther ScriptTypeEnum = "Other"
)

type CryptoTypeEnum string

// 加密方式常量
const (
	CryptoTypeJavaAESBase64   CryptoTypeEnum = "JAVA_AES_BASE64"
	CryptoTypeJavaAESRaw      CryptoTypeEnum = "JAVA_AES_RAW"
	CryptoTypeCSharpAESBase64 CryptoTypeEnum = "CSHARP_AES_BASE64"
	CryptoTypeCSharpAESRaw    CryptoTypeEnum = "CSHARP_AES_RAW"
	CryptoTypePHPXorBase64    CryptoTypeEnum = "PHP_XOR_BASE64"
	CryptoTypePHPXorRaw       CryptoTypeEnum = "PHP_XOR_RAW"
	CryptoTypeASPXorBase64    CryptoTypeEnum = "ASP_XOR_BASE64"
	CryptoTypeASPXorRaw       CryptoTypeEnum = "ASP_XOR_RAW"
	CryptoTypeDES             CryptoTypeEnum = "DES"
	CryptoTypeRSA             CryptoTypeEnum = "RSA"
	CryptoTypeBase64          CryptoTypeEnum = "BASE64"
	CryptoTypeNone            CryptoTypeEnum = "NONE"
)

type EncodingTypeEnum string

// 编码方式常量
const (
	EncodingTypeUTF8     EncodingTypeEnum = "UTF-8"
	EncodingTypeGBK      EncodingTypeEnum = "GBK"
	EncodingTypeGB2312   EncodingTypeEnum = "GB2312"
	EncodingTypeBIG5     EncodingTypeEnum = "BIG5"
	EncodingTypeGB18030  EncodingTypeEnum = "GB18030"
	EncodingTypeISO88591 EncodingTypeEnum = "ISO-8859-1"
	EncodingTypeLatin1   EncodingTypeEnum = "latin1"
	EncodingTypeUTF16    EncodingTypeEnum = "UTF16"
	EncodingTypeASCII    EncodingTypeEnum = "ascii"
	EncodingTypeCP850    EncodingTypeEnum = "cp850"
)

type StatusEnum string

// 状态常量
const (
	StatusDisabled     StatusEnum = "Disabled"
	StatusEnabled      StatusEnum = "Enabled"
	StatusConnected    StatusEnum = "Connected"
	StatusDisconnected StatusEnum = "Disconnected"
)

// 新增：架构常量
type ArchitectureEnum string

const (
	ArchitectureX86     ArchitectureEnum = "x86"
	ArchitectureX64     ArchitectureEnum = "x64"
	ArchitectureAMD64   ArchitectureEnum = "amd64"
	ArchitectureARM     ArchitectureEnum = "arm"
	ArchitectureARM64   ArchitectureEnum = "arm64"
	ArchitectureAARCH64 ArchitectureEnum = "aarch64"
	ArchitectureMIPS    ArchitectureEnum = "mips"
	ArchitectureMIPS64  ArchitectureEnum = "mips64"
	ArchitecturePPC     ArchitectureEnum = "ppc"
	ArchitecturePPC64   ArchitectureEnum = "ppc64"
	ArchitectureSPARC   ArchitectureEnum = "sparc"
	ArchitectureSPARC64 ArchitectureEnum = "sparc64"
	ArchitectureOther   ArchitectureEnum = "other"
)

// 新增：操作系统常量
type OperatingSystemEnum string

const (
	OSWindows OperatingSystemEnum = "Windows"
	OSLinux   OperatingSystemEnum = "Linux"
	OSMacOS   OperatingSystemEnum = "macOS"
	OSUnix    OperatingSystemEnum = "Unix"
	OSBSD     OperatingSystemEnum = "BSD"
	OSAndroid OperatingSystemEnum = "Android"
	OSiOS     OperatingSystemEnum = "iOS"
	OSOther   OperatingSystemEnum = "Other"
)

// 新增：Web框架常量
type WebFrameworkEnum string

const (
	FrameworkSpring      WebFrameworkEnum = "Spring"
	FrameworkShiro       WebFrameworkEnum = "Shiro"
	FrameworkStruts      WebFrameworkEnum = "Struts"
	FrameworkHibernate   WebFrameworkEnum = "Hibernate"
	FrameworkMyBatis     WebFrameworkEnum = "MyBatis"
	FrameworkLaravel     WebFrameworkEnum = "Laravel"
	FrameworkCodeIgniter WebFrameworkEnum = "CodeIgniter"
	FrameworkSymfony     WebFrameworkEnum = "Symfony"
	FrameworkYii         WebFrameworkEnum = "Yii"
	FrameworkASPNet      WebFrameworkEnum = "ASP.NET"
	FrameworkASPNetCore  WebFrameworkEnum = "ASP.NET Core"
	FrameworkExpress     WebFrameworkEnum = "Express.js"
	FrameworkKoa         WebFrameworkEnum = "Koa.js"
	FrameworkDjango      WebFrameworkEnum = "Django"
	FrameworkFlask       WebFrameworkEnum = "Flask"
	FrameworkFastAPI     WebFrameworkEnum = "FastAPI"
	FrameworkGin         WebFrameworkEnum = "Gin"
	FrameworkEcho        WebFrameworkEnum = "Echo"
	FrameworkOther       WebFrameworkEnum = "Other"
)

// 新增：数据库类型常量
type DatabaseTypeEnum string

const (
	DatabaseMySQL      DatabaseTypeEnum = "MySQL"
	DatabasePostgreSQL DatabaseTypeEnum = "PostgreSQL"
	DatabaseSQLite     DatabaseTypeEnum = "SQLite"
	DatabaseSQLServer  DatabaseTypeEnum = "SQL Server"
	DatabaseOracle     DatabaseTypeEnum = "Oracle"
	DatabaseMongoDB    DatabaseTypeEnum = "MongoDB"
	DatabaseRedis      DatabaseTypeEnum = "Redis"
	DatabaseMemcached  DatabaseTypeEnum = "Memcached"
	DatabaseOther      DatabaseTypeEnum = "Other"
)

// 新增：服务器类型常量
type ServerTypeEnum string

const (
	ServerApache    ServerTypeEnum = "Apache"
	ServerNginx     ServerTypeEnum = "Nginx"
	ServerIIS       ServerTypeEnum = "IIS"
	ServerTomcat    ServerTypeEnum = "Tomcat"
	ServerJBoss     ServerTypeEnum = "JBoss"
	ServerWebLogic  ServerTypeEnum = "WebLogic"
	ServerWebSphere ServerTypeEnum = "WebSphere"
	ServerGlassFish ServerTypeEnum = "GlassFish"
	ServerJetty     ServerTypeEnum = "Jetty"
	ServerUndertow  ServerTypeEnum = "Undertow"
	ServerOther     ServerTypeEnum = "Other"
)
