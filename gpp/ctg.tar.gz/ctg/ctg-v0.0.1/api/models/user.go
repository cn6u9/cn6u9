package models

import "time"

// User 用户数据模型
type User struct {
	Uid         int       `xorm:"pk autoincr" json:"uid"`
	Nickname    string    `json:"nickname"`    // 昵称
	Username    string    `json:"username"`    // 用户名
	Password    string    `json:"password"`    // 密码
	LastLoginAt time.Time `json:"lastLoginAt"` // 最后登录时间
	CreatedAt   time.Time `json:"createdAt"`   // 创建时间
	UpdatedAt   time.Time `json:"updatedAt"`   // 更新时间
}

// TableName 返回 User 结构体对应的数据库表名
func (User) TableName() string {
	return "users"
}
