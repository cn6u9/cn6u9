package models

import (
	"fmt"
	"time"
)

// WebShell WebShell数据模型
type WebShell struct {
	Id               int              `xorm:"pk autoincr" json:"id"`
	Name             string           `xorm:"name" json:"name"`                           // WebShell名称
	ScriptType       ScriptTypeEnum   `xorm:"script_type" json:"scriptType"`              // 脚本类型: PHP, ASP, ASPX, JSP, JSPX, Python
	WebShellType     WebShellTypeEnum `xorm:"webshell_type" json:"webshellType"`          // WebShell类型: Behinder, Godzilla, Antword, 自定义
	URL              string           `xorm:"url" json:"url"`                             // 目标URL
	Pass             string           `xorm:"pass" json:"pass"`                           // 密码
	Key              string           `xorm:"key" json:"key"`                             // 密钥
	Crypto           CryptoTypeEnum   `xorm:"crypto" json:"crypto"`                       // 加密方式: AES, DES, RSA, Base64, 无加密
	Encoding         EncodingTypeEnum `xorm:"encoding" json:"encoding"`                   // 编码方式: UTF-8, GBK, ASCII, Base64
	Group            string           `xorm:"group" json:"group"`                         // 分组
	Tag              string           `xorm:"tag" json:"tag"`                             // 标签
	Notes            string           `xorm:"notes" json:"notes"`                         // 备注
	UserAgent        string           `xorm:"user_agent" json:"userAgent"`                // User-Agent配置
	ProxyAddress     string           `xorm:"proxy_address" json:"proxyAddress"`          // 代理地址
	Status           StatusEnum       `xorm:"status" json:"status"`                       // 状态: 0-未启用, 1-已启用, 2-已连接, 3-已断开
	FirstConnectTime time.Time        `xorm:"first_connect_time" json:"firstConnectTime"` // 首次连接时间
	LastConnectTime  time.Time        `xorm:"last_connect_time" json:"lastConnectTime"`   // 最后连接时间
	ExternalIP       string           `xorm:"external_ip" json:"externalIP"`              // 外网IP
	Location         string           `xorm:"location" json:"location"`                   // 位置
	InternalIP       string           `xorm:"internal_ip" json:"internalIP"`              // 内网IP, FIXME: 多网卡支持
	Hostname         string           `xorm:"hostname" json:"hostname"`                   // 主机名
	Username         string           `xorm:"username" json:"username"`                   // 用户名
	CreatedAt        time.Time        `xorm:"created_at" json:"createdAt"`                // 创建时间
	UpdatedAt        time.Time        `xorm:"updated_at" json:"updatedAt"`                // 更新时间

	// 新增字段：系统信息
	Architecture    ArchitectureEnum    `xorm:"architecture" json:"architecture"`        // 系统架构: x86, x64, amd64, arm, arm64等
	OperatingSystem OperatingSystemEnum `xorm:"operating_system" json:"operatingSystem"` // 操作系统: Windows, Linux, macOS等
	DatabaseType    DatabaseTypeEnum    `xorm:"database_type" json:"databaseType"`       // 数据库类型: MySQL, PostgreSQL, SQLite等
	ServerType      ServerTypeEnum      `xorm:"server_type" json:"serverType"`           // 服务器类型: Apache, Nginx, IIS等
}

// NewWebShell 创建新的WebShell实例（默认构造函数）
func NewWebShell() *WebShell {
	now := time.Now()
	return &WebShell{
		Status:       StatusDisabled,                                                 // 默认状态：未启用
		ScriptType:   ScriptTypeJSP,                                                  // 默认脚本类型：JSP
		WebShellType: WebShellTypeGodzilla,                                           // 默认WebShell类型：Godzilla
		Crypto:       CryptoTypeJavaAESBase64,                                        // 默认加密方式：AES
		Encoding:     EncodingTypeUTF8,                                               // 默认编码方式：UTF-8
		UserAgent:    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", // 默认User-Agent
		Group:        "默认组",                                                          // 默认分组
		CreatedAt:    now,
		UpdatedAt:    now,
	}
}

// NewWebShellWithBasic 创建带基本信息的WebShell实例
func NewWebShellWithBasic(name string, scriptType ScriptTypeEnum, webshellType WebShellTypeEnum, url, pass string) *WebShell {
	webshell := NewWebShell()
	webshell.Name = name
	webshell.ScriptType = scriptType
	webshell.WebShellType = webshellType
	webshell.URL = url
	webshell.Pass = pass
	return webshell
}

// NewWebShellWithFull 创建带完整信息的WebShell实例
func NewWebShellWithFull(name string, scriptType ScriptTypeEnum, webshellType WebShellTypeEnum, url, pass, key string, crypto CryptoTypeEnum, encoding EncodingTypeEnum) *WebShell {
	webshell := NewWebShellWithBasic(name, scriptType, webshellType, url, pass)
	webshell.Key = key
	webshell.Crypto = crypto
	webshell.Encoding = encoding
	return webshell
}

// NewBehinderWebShell 创建Behinder类型的WebShell实例
func NewBehinderWebShell(name, url, pass, key string) *WebShell {
	return NewWebShellWithFull(name, ScriptTypeJSP, WebShellTypeGodzilla, url, pass, key, CryptoTypeJavaAESBase64, EncodingTypeUTF8)
}

// NewGodzillaWebShell 创建Godzilla类型的WebShell实例
func NewGodzillaWebShell(name, url, pass, key string) *WebShell {
	return NewWebShellWithFull(name, ScriptTypeJSP, WebShellTypeGodzilla, url, pass, key, CryptoTypeJavaAESBase64, EncodingTypeUTF8)
}

// NewCustomWebShell 创建自定义类型的WebShell实例
func NewCustomWebShell(name string, scriptType ScriptTypeEnum, url, pass string) *WebShell {
	return NewWebShellWithBasic(name, scriptType, WebShellTypeCustom, url, pass)
}

// SetName 设置WebShell名称（链式调用）
func (w *WebShell) SetName(name string) *WebShell {
	w.Name = name
	return w
}

// SetURL 设置目标URL（链式调用）
func (w *WebShell) SetURL(url string) *WebShell {
	w.URL = url
	return w
}

// SetCredentials 设置认证信息（链式调用）
func (w *WebShell) SetCredentials(pass, key string) *WebShell {
	w.Pass = pass
	w.Key = key
	return w
}

// SetEncryption 设置加密配置（链式调用）
func (w *WebShell) SetEncryption(crypto, encoding string) *WebShell {
	w.Crypto = CryptoTypeEnum(crypto)
	w.Encoding = EncodingTypeEnum(encoding)
	return w
}

// SetGroup 设置分组（链式调用）
func (w *WebShell) SetGroup(group string) *WebShell {
	w.Group = group
	return w
}

// SetTag 设置标签（链式调用）
func (w *WebShell) SetTag(tag string) *WebShell {
	w.Tag = tag
	return w
}

// SetNotes 设置备注（链式调用）
func (w *WebShell) SetNotes(notes string) *WebShell {
	w.Notes = notes
	return w
}

// SetUserAgent 设置User-Agent（链式调用）
func (w *WebShell) SetUserAgent(userAgent string) *WebShell {
	w.UserAgent = userAgent
	return w
}

// SetProxy 设置代理地址（链式调用）
func (w *WebShell) SetProxy(proxyAddress string) *WebShell {
	w.ProxyAddress = proxyAddress
	return w
}

// SetStatus 设置状态（链式调用）
func (w *WebShell) SetStatus(status string) *WebShell {
	w.Status = StatusEnum(status)
	return w
}

// Enable 启用WebShell（链式调用）
func (w *WebShell) Enable() *WebShell {
	w.Status = StatusEnabled
	w.UpdatedAt = time.Now()
	return w
}

// Disable 禁用WebShell（链式调用）
func (w *WebShell) Disable() *WebShell {
	w.Status = StatusDisabled
	w.UpdatedAt = time.Now()
	return w
}

// Connect 标记为已连接（链式调用）
func (w *WebShell) Connect() *WebShell {
	now := time.Now()
	w.Status = StatusConnected
	if w.FirstConnectTime.IsZero() {
		w.FirstConnectTime = now
	}
	w.LastConnectTime = now
	w.UpdatedAt = now
	return w
}

// Disconnect 标记为已断开（链式调用）
func (w *WebShell) Disconnect() *WebShell {
	w.Status = StatusDisconnected
	w.UpdatedAt = time.Now()
	return w
}

// SetNetworkInfo 设置网络信息（链式调用）
func (w *WebShell) SetNetworkInfo(externalIP, internalIP, hostname, username string) *WebShell {
	w.ExternalIP = externalIP
	w.InternalIP = internalIP
	w.Hostname = hostname
	w.Username = username
	w.UpdatedAt = time.Now()
	return w
}

// SetLocation 设置位置信息（链式调用）
func (w *WebShell) SetLocation(location string) *WebShell {
	w.Location = location
	w.UpdatedAt = time.Now()
	return w
}

// UpdateTimestamp 更新时间戳（链式调用）
func (w *WebShell) UpdateTimestamp() *WebShell {
	w.UpdatedAt = time.Now()
	return w
}

// IsEnabled 检查WebShell是否已启用
func (w *WebShell) IsEnabled() bool {
	return w.Status == StatusEnabled || w.Status == StatusConnected
}

// IsConnected 检查WebShell是否已连接
func (w *WebShell) IsConnected() bool {
	return w.Status == StatusConnected
}

// IsDisconnected 检查WebShell是否已断开
func (w *WebShell) IsDisconnected() bool {
	return w.Status == StatusDisconnected
}

// GetStatusText 获取状态文本描述
func (w *WebShell) GetStatusText() string {
	switch w.Status {
	case StatusDisabled:
		return "未启用"
	case StatusEnabled:
		return "已启用"
	case StatusConnected:
		return "已连接"
	case StatusDisconnected:
		return "已断开"
	default:
		return "未知状态"
	}
}

// Validate 验证WebShell配置是否完整
func (w *WebShell) Validate() error {
	if w.Name == "" {
		return fmt.Errorf("WebShell名称不能为空")
	}
	if w.URL == "" {
		return fmt.Errorf("目标URL不能为空")
	}
	if w.ScriptType == "" {
		return fmt.Errorf("脚本类型不能为空")
	}
	if w.WebShellType == "" {
		return fmt.Errorf("WebShell类型不能为空")
	}
	return nil
}

// Clone 克隆WebShell实例
func (w *WebShell) Clone() *WebShell {
	clone := *w
	clone.Id = 0 // 重置ID，避免重复
	clone.CreatedAt = time.Now()
	clone.UpdatedAt = time.Now()
	return &clone
}

// File 文件数据模型
type File struct {
	Id             int       `xorm:"pk autoincr" json:"id"`
	Name           string    `json:"name"`
	LocalPath      string    `json:"localPath"`      // 本地路径
	RemotePath     string    `json:"remotePath"`     // 远程路径
	Size           int       `json:"size"`           // 文件大小
	DownloadedSize int       `json:"downloadedSize"` // 已下载大小
	DownloadedTime time.Time `json:"downloadedTime"` // 下载时间
}

// Listener 监听器数据模型
type Listener struct {
	Id             int        `xorm:"pk autoincr" json:"id"`
	Type           string     `json:"type"`
	Port           int        `json:"port"`
	Password       string     `json:"password"`
	ListenAddress  string     `json:"listenAddress"`
	ConnectAddress string     `json:"connectAddress"`
	Status         StatusEnum `json:"status"` // 0: 未启用 1: 暂停 2: 已连接
}

// History 历史记录数据模型
type History struct {
	Id            int       `json:"id"`
	StartTime     time.Time `json:"startTime"`
	EndTime       time.Time `json:"endTime"`
	CommandInput  string    `json:"commandInput"`
	CommandOutput string    `json:"commandOutput"`
}

// TableName 方法用于为 XORM 或 GORM 等 ORM 框架指定数据库表名
// 当结构体名称与实际数据库表名不一致时，通过实现 TableName() 方法来自定义表名映射

// TableName 返回 WebShell 结构体对应的数据库表名
func (WebShell) TableName() string {
	return "webshells"
}

// TableName 返回 File 结构体对应的数据库表名
func (File) TableName() string {
	return "files"
}

// TableName 返回 Listener 结构体对应的数据库表名
func (Listener) TableName() string {
	return "listeners"
}

func (History) TableName() string {
	return "histories"
}
