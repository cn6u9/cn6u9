package test

import (
	"testing"
	"time"

	"ctg-api/models"
	"ctg-api/services"
)

func TestWebShellService_ExecuteCommand(t *testing.T) {
	// 创建WebShell服务实例
	service := services.NewWebShellService()

	// 创建测试用的WebShell
	webshell := &models.WebShell{
		Id:           1,
		Name:         "测试WebShell",
		ScriptType:   models.ScriptTypeJSP,
		WebShellType: models.WebShellTypeGodzilla,
		URL:          "http://192.168.1.135:9976/2.jsp",
		Pass:         "pass",
		Key:          "key",
		Crypto:       models.CryptoTypeJavaAESBase64,
		Encoding:     models.EncodingTypeUTF8,
		Status:       models.StatusEnabled,
		CreatedAt:    time.Now(),
		UpdatedAt:    time.Now(),
	}

	// 测试命令执行（这里只是测试方法调用，不实际执行）
	// 注意：实际执行需要真实的WebShell环境
	t.Logf("测试WebShell: %+v", webshell)
	t.Logf("脚本类型: %s", webshell.ScriptType)
	t.Logf("WebShell类型: %s", webshell.WebShellType)
	t.Logf("加密方式: %s", webshell.Crypto)
	t.Logf("编码方式: %s", webshell.Encoding)

	// 验证服务实例创建成功
	if service == nil {
		t.Error("WebShell服务创建失败")
	}
}

func TestWebShellService_ConvertFunctions(t *testing.T) {
	// 测试类型转换函数（通过反射或其他方式）
	// 这里我们只测试模型常量的正确性

	// 测试脚本类型
	if models.ScriptTypeJSP != "JSP" {
		t.Error("JSP脚本类型常量错误")
	}

	// 测试加密类型
	if models.CryptoTypeJavaAESBase64 != "JAVA_AES_BASE64" {
		t.Error("JAVA_AES_BASE64加密类型常量错误")
	}

	// 测试编码类型
	if models.EncodingTypeUTF8 != "utf8" {
		t.Error("UTF8编码类型常量错误")
	}

	t.Logf("所有类型常量验证通过")
}
