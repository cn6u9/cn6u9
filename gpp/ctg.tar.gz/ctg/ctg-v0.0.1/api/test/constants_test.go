package test

import (
	"testing"

	"ctg-api/models"

	"github.com/stretchr/testify/assert"
)

// 测试常量值
func TestConstants(t *testing.T) {
	// 测试WebShell类型常量
	assert.Equal(t, "Behinder", string(models.WebShellTypeBehinder))
	assert.Equal(t, "Godzilla", string(models.WebShellTypeGodzilla))
	assert.Equal(t, "Antword", string(models.WebShellTypeAntword))
	assert.Equal(t, "Custom", string(models.WebShellTypeCustom))
	assert.Equal(t, "Other", string(models.WebShellTypeOther))

	// 测试脚本类型常量
	assert.Equal(t, "PHP", string(models.ScriptTypePHP))
	assert.Equal(t, "ASP", string(models.ScriptTypeASP))
	assert.Equal(t, "ASPX", string(models.ScriptTypeASPX))
	assert.Equal(t, "JSP", string(models.ScriptTypeJSP))
	assert.Equal(t, "JSPX", string(models.ScriptTypeJSPX))
	assert.Equal(t, "Other", string(models.ScriptTypeOther))

	// 测试加密方式常量
	assert.Equal(t, "JAVA_AES_BASE64", string(models.CryptoTypeJavaAESBase64))
	assert.Equal(t, "DES", string(models.CryptoTypeDES))
	assert.Equal(t, "RSA", string(models.CryptoTypeRSA))
	assert.Equal(t, "BASE64", string(models.CryptoTypeBase64))
	assert.Equal(t, "NONE", string(models.CryptoTypeNone))

	// 测试编码方式常量
	assert.Equal(t, "utf8", string(models.EncodingTypeUTF8))
	assert.Equal(t, "gbk", string(models.EncodingTypeGBK))
	assert.Equal(t, "gb2312", string(models.EncodingTypeGB2312))
	assert.Equal(t, "BIG5", string(models.EncodingTypeBIG5))
	assert.Equal(t, "GB18030", string(models.EncodingTypeGB18030))
	assert.Equal(t, "ISO_8859_1", string(models.EncodingTypeISO88591))
	assert.Equal(t, "latin1", string(models.EncodingTypeLatin1))
	assert.Equal(t, "utf16", string(models.EncodingTypeUTF16))
	assert.Equal(t, "ascii", string(models.EncodingTypeASCII))
	assert.Equal(t, "cp850", string(models.EncodingTypeCP850))

	// 测试状态常量
	assert.Equal(t, "Disabled", string(models.StatusDisabled))
	assert.Equal(t, "Enabled", string(models.StatusEnabled))
	assert.Equal(t, "Connected", string(models.StatusConnected))
	assert.Equal(t, "Disconnected", string(models.StatusDisconnected))

	// 测试枚举类型
	assert.IsType(t, models.WebShellTypeEnum(""), models.WebShellTypeBehinder)
	assert.IsType(t, models.ScriptTypeEnum(""), models.ScriptTypePHP)
	assert.IsType(t, models.CryptoTypeEnum(""), models.CryptoTypeJavaAESBase64)
	assert.IsType(t, models.EncodingTypeEnum(""), models.EncodingTypeUTF8)
	assert.IsType(t, models.StatusEnum(""), models.StatusEnabled)

	t.Log("✅ 所有常量测试通过")
}
