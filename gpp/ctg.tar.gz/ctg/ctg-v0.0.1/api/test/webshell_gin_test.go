package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"ctg-api/config"
	"ctg-api/database"
	"ctg-api/models"
	"ctg-api/routes"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

// 测试前的设置
func setupTest() *gin.Engine {
	// 设置Gin为测试模式
	gin.SetMode(gin.TestMode)

	// 初始化配置
	if err := config.InitConfig(); err != nil {
		panic(fmt.Sprintf("配置初始化失败: %v", err))
	}

	// 初始化数据库连接
	database.ConnectDateBase()

	// 创建Gin引擎
	r := gin.New()

	// 设置路由
	apiGroup := r.Group("/api")
	routes.SetupAllRoutes(apiGroup)

	return r
}

// 清理测试数据
func cleanupTestData() {
	// 这里可以添加清理逻辑，比如删除测试创建的WebShell
	// 目前暂时跳过，因为测试数据不会影响功能
}

// 测试创建WebShell
func TestCreateWebShell(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 测试数据 - 使用唯一的URL
	testWebShell := models.NewBehinderWebShell(
		"测试WebShell",
		fmt.Sprintf("http://example.com/shell_%d.php", time.Now().Unix()),
		"pass",
		"key",
	).SetGroup("测试组").Enable()

	// 转换为JSON
	jsonData, _ := json.Marshal(testWebShell)

	// 创建POST请求
	req, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
	req.Header.Set("Content-Type", "application/json")

	// 创建响应记录器
	w := httptest.NewRecorder()

	// 执行请求
	router.ServeHTTP(w, req)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w.Code)

	// 解析响应
	var response map[string]interface{}
	err := json.Unmarshal(w.Body.Bytes(), &response)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", response["status"])
	assert.Equal(t, "WebShell创建成功", response["message"])

	fmt.Printf("✅ 创建WebShell测试通过: %s\n", response["message"])
}

// 测试URL去重功能
func TestWebShellURLDuplicate(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 第一个WebShell - 使用唯一URL
	uniqueURL := fmt.Sprintf("http://example.com/duplicate_%d.php", time.Now().Unix())
	webshell1 := models.NewBehinderWebShell(
		"测试WebShell1",
		uniqueURL,
		"pass1",
		"key1",
	).SetGroup("测试组")

	// 第二个WebShell（相同URL）
	webshell2 := models.NewBehinderWebShell(
		"测试WebShell2",
		uniqueURL, // 与第一个相同的URL
		"pass2",
		"key2",
	).SetGroup("测试组")

	// 创建第一个WebShell
	jsonData1, _ := json.Marshal(webshell1)
	req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData1))
	req1.Header.Set("Content-Type", "application/json")
	w1 := httptest.NewRecorder()
	router.ServeHTTP(w1, req1)

	// 第一个应该成功
	assert.Equal(t, http.StatusOK, w1.Code)

	// 尝试创建第二个WebShell（相同URL）
	jsonData2, _ := json.Marshal(webshell2)
	req2, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData2))
	req2.Header.Set("Content-Type", "application/json")
	w2 := httptest.NewRecorder()
	router.ServeHTTP(w2, req2)

	// 第二个应该失败（URL重复）
	assert.Equal(t, http.StatusInternalServerError, w2.Code)

	// 验证错误信息
	var errorResponse map[string]interface{}
	err := json.Unmarshal(w2.Body.Bytes(), &errorResponse)
	assert.NoError(t, err)
	assert.Contains(t, errorResponse["message"], "URL已存在")

	fmt.Printf("✅ URL去重测试通过: %s\n", errorResponse["message"])
}

// 测试获取WebShell列表
func TestGetWebShellList(t *testing.T) {
	router := setupTest()

	// 创建GET请求
	req, _ := http.NewRequest("GET", "/api/webshell", nil)
	w := httptest.NewRecorder()

	// 执行请求
	router.ServeHTTP(w, req)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w.Code)

	// 解析响应
	var response map[string]interface{}
	err := json.Unmarshal(w.Body.Bytes(), &response)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", response["status"])
	assert.NotNil(t, response["data"])

	fmt.Printf("✅ 获取WebShell列表测试通过，状态: %s\n", response["status"])
}

// 测试获取WebShell详情
func TestGetWebShellByID(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 先创建一个WebShell
	testWebShell := models.NewWebShell().
		SetName("详情测试WebShell").
		SetURL(fmt.Sprintf("http://example.com/detail_%d.php", time.Now().Unix())).
		SetCredentials("pass", "key").
		SetGroup("测试组")

	jsonData, _ := json.Marshal(testWebShell)
	req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
	req1.Header.Set("Content-Type", "application/json")
	w1 := httptest.NewRecorder()
	router.ServeHTTP(w1, req1)

	// 获取创建的WebShell的ID
	var createResponse map[string]interface{}
	json.Unmarshal(w1.Body.Bytes(), &createResponse)
	data := createResponse["data"].(map[string]interface{})
	webshellID := int(data["id"].(float64))

	// 测试获取详情
	req2, _ := http.NewRequest("GET", fmt.Sprintf("/api/webshell/%d", webshellID), nil)
	w2 := httptest.NewRecorder()
	router.ServeHTTP(w2, req2)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w2.Code)

	// 解析响应
	var detailResponse map[string]interface{}
	err := json.Unmarshal(w2.Body.Bytes(), &detailResponse)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", detailResponse["status"])
	assert.NotNil(t, detailResponse["data"])

	fmt.Printf("✅ 获取WebShell详情测试通过，ID: %d\n", webshellID)
}

// 测试更新WebShell
func TestUpdateWebShell(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 先创建一个WebShell
	testWebShell := models.NewWebShell().
		SetName("更新测试WebShell").
		SetURL(fmt.Sprintf("http://example.com/update_%d.php", time.Now().Unix())).
		SetCredentials("pass", "key").
		SetGroup("测试组")

	jsonData, _ := json.Marshal(testWebShell)
	req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
	req1.Header.Set("Content-Type", "application/json")
	w1 := httptest.NewRecorder()
	router.ServeHTTP(w1, req1)

	// 获取创建的WebShell的ID
	var createResponse map[string]interface{}
	json.Unmarshal(w1.Body.Bytes(), &createResponse)
	data := createResponse["data"].(map[string]interface{})
	webshellID := int(data["id"].(float64))

	// 准备更新数据
	updateData := map[string]interface{}{
		"name":   "更新后的WebShell",
		"notes":  "这是更新后的备注",
		"status": "1",
	}

	// 测试更新
	jsonUpdateData, _ := json.Marshal(updateData)
	req2, _ := http.NewRequest("PUT", fmt.Sprintf("/api/webshell/%d", webshellID), bytes.NewBuffer(jsonUpdateData))
	req2.Header.Set("Content-Type", "application/json")
	w2 := httptest.NewRecorder()
	router.ServeHTTP(w2, req2)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w2.Code)

	// 解析响应
	var updateResponse map[string]interface{}
	err := json.Unmarshal(w2.Body.Bytes(), &updateResponse)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", updateResponse["status"])
	assert.Equal(t, "WebShell更新成功", updateResponse["message"])

	fmt.Printf("✅ 更新WebShell测试通过: %s\n", updateResponse["message"])
}

// 测试删除WebShell
func TestDeleteWebShell(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 先创建一个WebShell
	testWebShell := models.NewWebShell().
		SetName("删除测试WebShell").
		SetURL(fmt.Sprintf("http://example.com/delete_%d.php", time.Now().Unix())).
		SetCredentials("pass", "key").
		SetGroup("测试组")

	jsonData, _ := json.Marshal(testWebShell)
	req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
	req1.Header.Set("Content-Type", "application/json")
	w1 := httptest.NewRecorder()
	router.ServeHTTP(w1, req1)

	// 获取创建的WebShell的ID
	var createResponse map[string]interface{}
	json.Unmarshal(w1.Body.Bytes(), &createResponse)
	data := createResponse["data"].(map[string]interface{})
	webshellID := int(data["id"].(float64))

	// 测试删除
	req2, _ := http.NewRequest("DELETE", fmt.Sprintf("/api/webshell/%d", webshellID), nil)
	w2 := httptest.NewRecorder()
	router.ServeHTTP(w2, req2)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w2.Code)

	// 解析响应
	var deleteResponse map[string]interface{}
	err := json.Unmarshal(w2.Body.Bytes(), &deleteResponse)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", deleteResponse["status"])
	assert.Equal(t, "WebShell删除成功", deleteResponse["message"])

	fmt.Printf("✅ 删除WebShell测试通过: %s\n", deleteResponse["message"])
}

// 测试命令执行功能
func TestExecuteCommand(t *testing.T) {
	router := setupTest()
	defer cleanupTestData()

	// 先创建一个WebShell
	testWebShell := models.NewWebShell().
		SetName("命令测试WebShell").
		SetURL(fmt.Sprintf("http://example.com/command_%d.php", time.Now().Unix())).
		SetCredentials("pass", "key").
		SetGroup("测试组")

	jsonData, _ := json.Marshal(testWebShell)
	req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
	req1.Header.Set("Content-Type", "application/json")
	w1 := httptest.NewRecorder()
	router.ServeHTTP(w1, req1)

	// 获取创建的WebShell的ID
	var createResponse map[string]interface{}
	json.Unmarshal(w1.Body.Bytes(), &createResponse)
	data := createResponse["data"].(map[string]interface{})
	webshellID := int(data["id"].(float64))

	// 准备命令执行数据
	commandData := map[string]interface{}{
		"command": "ls -la",
		"timeout": 30,
	}

	// 测试命令执行
	jsonCommandData, _ := json.Marshal(commandData)
	req2, _ := http.NewRequest("POST", fmt.Sprintf("/api/webshell/%d/execute", webshellID), bytes.NewBuffer(jsonCommandData))
	req2.Header.Set("Content-Type", "application/json")
	w2 := httptest.NewRecorder()
	router.ServeHTTP(w2, req2)

	// 断言响应状态码
	assert.Equal(t, http.StatusOK, w2.Code)

	// 解析响应
	var commandResponse map[string]interface{}
	err := json.Unmarshal(w2.Body.Bytes(), &commandResponse)
	assert.NoError(t, err)

	// 验证响应内容
	assert.Equal(t, "ok", commandResponse["status"])
	assert.NotNil(t, commandResponse["data"])

	fmt.Printf("✅ 命令执行测试通过，状态: %s\n", commandResponse["status"])
}

// 主测试函数
func TestAllWebShellFeatures(t *testing.T) {
	fmt.Println("🚀 开始WebShell API完整测试...")

	// 为每个子测试使用不同的时间戳，避免URL冲突
	timestamp := time.Now().Unix()

	t.Run("创建WebShell", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 测试数据 - 使用唯一的URL
		testWebShell := models.NewBehinderWebShell(
			"测试WebShell",
			fmt.Sprintf("http://example.com/shell_all_%d.php", timestamp),
			"pass",
			"key",
		).SetGroup("测试组").Enable()

		// 转换为JSON
		jsonData, _ := json.Marshal(testWebShell)

		// 创建POST请求
		req, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")

		// 创建响应记录器
		w := httptest.NewRecorder()

		// 执行请求
		router.ServeHTTP(w, req)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w.Code)

		// 解析响应
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", response["status"])
		assert.Equal(t, "WebShell创建成功", response["message"])

		fmt.Printf("✅ 创建WebShell测试通过: %s\n", response["message"])
	})

	t.Run("URL去重", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 第一个WebShell - 使用唯一URL
		uniqueURL := fmt.Sprintf("http://example.com/duplicate_all_%d.php", timestamp)
		webshell1 := models.NewBehinderWebShell(
			"测试WebShell1",
			uniqueURL,
			"pass1",
			"key1",
		).SetGroup("测试组")

		// 第二个WebShell（相同URL）
		webshell2 := models.NewBehinderWebShell(
			"测试WebShell2",
			uniqueURL, // 与第一个相同的URL
			"pass2",
			"key2",
		).SetGroup("测试组")

		// 创建第一个WebShell
		jsonData1, _ := json.Marshal(webshell1)
		req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData1))
		req1.Header.Set("Content-Type", "application/json")
		w1 := httptest.NewRecorder()
		router.ServeHTTP(w1, req1)

		// 第一个应该成功
		assert.Equal(t, http.StatusOK, w1.Code)

		// 尝试创建第二个WebShell（相同URL）
		jsonData2, _ := json.Marshal(webshell2)
		req2, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData2))
		req2.Header.Set("Content-Type", "application/json")
		w2 := httptest.NewRecorder()
		router.ServeHTTP(w2, req2)

		// 第二个应该失败（URL重复）
		assert.Equal(t, http.StatusInternalServerError, w2.Code)

		// 验证错误信息
		var errorResponse map[string]interface{}
		err := json.Unmarshal(w2.Body.Bytes(), &errorResponse)
		assert.NoError(t, err)
		assert.Contains(t, errorResponse["message"], "URL已存在")

		fmt.Printf("✅ URL去重测试通过: %s\n", errorResponse["message"])
	})

	t.Run("获取列表", func(t *testing.T) {
		router := setupTest()

		// 创建GET请求
		req, _ := http.NewRequest("GET", "/api/webshell", nil)
		w := httptest.NewRecorder()

		// 执行请求
		router.ServeHTTP(w, req)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w.Code)

		// 解析响应
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", response["status"])
		assert.NotNil(t, response["data"])

		fmt.Printf("✅ 获取WebShell列表测试通过，状态: %s\n", response["status"])
	})

	t.Run("获取详情", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 先创建一个WebShell
		testWebShell := models.NewWebShell().
			SetName("详情测试WebShell").
			SetURL(fmt.Sprintf("http://example.com/detail_all_%d.php", timestamp)).
			SetCredentials("pass", "key").
			SetGroup("测试组")

		jsonData, _ := json.Marshal(testWebShell)
		req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
		req1.Header.Set("Content-Type", "application/json")
		w1 := httptest.NewRecorder()
		router.ServeHTTP(w1, req1)

		// 获取创建的WebShell的ID
		var createResponse map[string]interface{}
		json.Unmarshal(w1.Body.Bytes(), &createResponse)
		data := createResponse["data"].(map[string]interface{})
		webshellID := int(data["id"].(float64))

		// 测试获取详情
		req2, _ := http.NewRequest("GET", fmt.Sprintf("/api/webshell/%d", webshellID), nil)
		w2 := httptest.NewRecorder()
		router.ServeHTTP(w2, req2)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w2.Code)

		// 解析响应
		var detailResponse map[string]interface{}
		err := json.Unmarshal(w2.Body.Bytes(), &detailResponse)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", detailResponse["status"])
		assert.NotNil(t, detailResponse["data"])

		fmt.Printf("✅ 获取WebShell详情测试通过，ID: %d\n", webshellID)
	})

	t.Run("更新WebShell", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 先创建一个WebShell
		testWebShell := models.NewWebShell().
			SetName("更新测试WebShell").
			SetURL(fmt.Sprintf("http://example.com/update_all_%d.php", timestamp)).
			SetCredentials("pass", "key").
			SetGroup("测试组")

		jsonData, _ := json.Marshal(testWebShell)
		req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
		req1.Header.Set("Content-Type", "application/json")
		w1 := httptest.NewRecorder()
		router.ServeHTTP(w1, req1)

		// 获取创建的WebShell的ID
		var createResponse map[string]interface{}
		json.Unmarshal(w1.Body.Bytes(), &createResponse)
		data := createResponse["data"].(map[string]interface{})
		webshellID := int(data["id"].(float64))

		// 准备更新数据
		updateData := map[string]interface{}{
			"name":   "更新后的WebShell",
			"notes":  "这是更新后的备注",
			"status": "1",
		}

		// 测试更新
		jsonUpdateData, _ := json.Marshal(updateData)
		req2, _ := http.NewRequest("PUT", fmt.Sprintf("/api/webshell/%d", webshellID), bytes.NewBuffer(jsonUpdateData))
		req2.Header.Set("Content-Type", "application/json")
		w2 := httptest.NewRecorder()
		router.ServeHTTP(w2, req2)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w2.Code)

		// 解析响应
		var updateResponse map[string]interface{}
		err := json.Unmarshal(w2.Body.Bytes(), &updateResponse)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", updateResponse["status"])
		assert.Equal(t, "WebShell更新成功", updateResponse["message"])

		fmt.Printf("✅ 更新WebShell测试通过: %s\n", updateResponse["message"])
	})

	t.Run("删除WebShell", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 先创建一个WebShell
		testWebShell := models.NewWebShell().
			SetName("删除测试WebShell").
			SetURL(fmt.Sprintf("http://example.com/delete_all_%d.php", timestamp)).
			SetCredentials("pass", "key").
			SetGroup("测试组")

		jsonData, _ := json.Marshal(testWebShell)
		req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
		req1.Header.Set("Content-Type", "application/json")
		w1 := httptest.NewRecorder()
		router.ServeHTTP(w1, req1)

		// 获取创建的WebShell的ID
		var createResponse map[string]interface{}
		json.Unmarshal(w1.Body.Bytes(), &createResponse)
		data := createResponse["data"].(map[string]interface{})
		webshellID := int(data["id"].(float64))

		// 测试删除
		req2, _ := http.NewRequest("DELETE", fmt.Sprintf("/api/webshell/%d", webshellID), nil)
		w2 := httptest.NewRecorder()
		router.ServeHTTP(w2, req2)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w2.Code)

		// 解析响应
		var deleteResponse map[string]interface{}
		err := json.Unmarshal(w2.Body.Bytes(), &deleteResponse)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", deleteResponse["status"])
		assert.Equal(t, "WebShell删除成功", deleteResponse["message"])

		fmt.Printf("✅ 删除WebShell测试通过: %s\n", deleteResponse["message"])
	})

	t.Run("命令执行", func(t *testing.T) {
		router := setupTest()
		defer cleanupTestData()

		// 先创建一个WebShell
		testWebShell := models.NewWebShell().
			SetName("命令测试WebShell").
			SetURL(fmt.Sprintf("http://example.com/command_all_%d.php", timestamp)).
			SetCredentials("pass", "key").
			SetGroup("测试组")

		jsonData, _ := json.Marshal(testWebShell)
		req1, _ := http.NewRequest("POST", "/api/webshell", bytes.NewBuffer(jsonData))
		req1.Header.Set("Content-Type", "application/json")
		w1 := httptest.NewRecorder()
		router.ServeHTTP(w1, req1)

		// 获取创建的WebShell的ID
		var createResponse map[string]interface{}
		json.Unmarshal(w1.Body.Bytes(), &createResponse)
		data := createResponse["data"].(map[string]interface{})
		webshellID := int(data["id"].(float64))

		// 准备命令执行数据
		commandData := map[string]interface{}{
			"command": "ls -la",
			"timeout": 30,
		}

		// 测试命令执行
		jsonCommandData, _ := json.Marshal(commandData)
		req2, _ := http.NewRequest("POST", fmt.Sprintf("/api/webshell/%d/execute", webshellID), bytes.NewBuffer(jsonCommandData))
		req2.Header.Set("Content-Type", "application/json")
		w2 := httptest.NewRecorder()
		router.ServeHTTP(w2, req2)

		// 断言响应状态码
		assert.Equal(t, http.StatusOK, w2.Code)

		// 解析响应
		var commandResponse map[string]interface{}
		err := json.Unmarshal(w2.Body.Bytes(), &commandResponse)
		assert.NoError(t, err)

		// 验证响应内容
		assert.Equal(t, "ok", commandResponse["status"])
		assert.NotNil(t, commandResponse["data"])

		fmt.Printf("✅ 命令执行测试通过，状态: %s\n", commandResponse["status"])
	})

	fmt.Println("🎉 所有测试完成!")
}
