package services

import (
	"fmt"
	"time"

	"ctg-api/database"
	"ctg-api/models"
)

// UserService 用户服务
type UserService struct{}

// NewUserService 创建用户服务实例
func NewUserService() *UserService {
	return &UserService{}
}

// CreateUser 创建用户
func (s *UserService) CreateUser(user *models.User) error {
	// 检查用户名是否已存在
	exists, err := s.IsUsernameExists(user.Username)
	if err != nil {
		return fmt.Errorf("检查用户名失败: %v", err)
	}
	if exists {
		return fmt.Errorf("用户名已存在")
	}

	// 明文存储密码，不进行加密

	// 设置默认值
	now := time.Now()
	user.CreatedAt = now
	user.UpdatedAt = now

	// 保存到数据库
	err = database.CreateUser(user)
	if err != nil {
		return fmt.Errorf("保存用户到数据库失败: %v", err)
	}

	return nil
}

// AuthenticateUser 用户认证
func (s *UserService) AuthenticateUser(username, password string) (*models.User, error) {
	// 从数据库查询用户
	user, err := database.GetUserByUsername(username)
	if err != nil {
		return nil, fmt.Errorf("用户名或密码错误")
	}

	// 验证密码（明文比较）
	if password != user.Password {
		return nil, fmt.Errorf("用户名或密码错误")
	}

	// 更新最后登录时间
	user.LastLoginAt = time.Now()
	err = database.UpdateUser(user)
	if err != nil {
		return nil, fmt.Errorf("更新登录时间失败: %v", err)
	}

	return user, nil
}

// IsUsernameExists 检查用户名是否已存在
func (s *UserService) IsUsernameExists(username string) (bool, error) {
	_, err := database.GetUserByUsername(username)
	if err != nil {
		return false, nil // 用户不存在
	}
	return true, nil // 用户存在
}

// GetUserByID 根据ID获取用户
func (s *UserService) GetUserByID(uid int) (*models.User, error) {
	var user models.User
	exists, err := database.Engine.ID(uid).Get(&user)
	if err != nil {
		return nil, fmt.Errorf("查询用户失败: %v", err)
	}
	if !exists {
		return nil, fmt.Errorf("用户不存在")
	}
	return &user, nil
}

// UpdateUser 更新用户信息
func (s *UserService) UpdateUser(user *models.User) error {
	err := database.UpdateUser(user)
	if err != nil {
		return fmt.Errorf("更新用户失败: %v", err)
	}
	return nil
}

// DeleteUser 删除用户
func (s *UserService) DeleteUser(uid int) error {
	err := database.DeleteUser(uid)
	if err != nil {
		return fmt.Errorf("删除用户失败: %v", err)
	}
	return nil
}
