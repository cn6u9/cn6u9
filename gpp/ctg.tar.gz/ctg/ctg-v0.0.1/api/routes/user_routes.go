package routes

import (
	"ctg-api/controllers"

	"github.com/gin-gonic/gin"
)

// SetupUserRoutes 设置用户相关路由
func SetupUserRoutes(router *gin.RouterGroup) {
	userController := controllers.NewUserController()

	// 用户认证相关路由
	auth := router.Group("/auth")
	{
		auth.POST("/login", userController.Login)
		auth.POST("/logout", userController.Logout)
	}

	// 用户信息相关路由
	user := router.Group("/user")
	{
		user.GET("/info", userController.GetUserInfo)
	}
}
