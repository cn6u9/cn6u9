package routes

import (
	"github.com/gin-gonic/gin"
)

// SetupAllRoutes 设置所有路由
func SetupAllRoutes(router *gin.RouterGroup) {
	// 设置用户相关路由
	SetupUserRoutes(router)

	// 设置WebShell相关路由
	SetupWebShellRoutes(router)

	// 设置配置相关路由
	SetupConfigRoutes(router)

	// 这里可以添加其他模块的路由
	// 例如：SetupFileRoutes(router)
}
