package routes

import (
	"ctg-api/controllers"

	"github.com/gin-gonic/gin"
)

// SetupConfigRoutes 设置配置相关路由
func SetupConfigRoutes(router *gin.RouterGroup) {
	configController := &controllers.ConfigController{}

	// 获取完整配置
	router.GET("/config", configController.GetConfig)

	// 仅获取base_path
	router.GET("/base-path", configController.GetBasePath)
}
