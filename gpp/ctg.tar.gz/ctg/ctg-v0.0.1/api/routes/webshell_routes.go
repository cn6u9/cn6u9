package routes

import (
	"ctg-api/controllers"

	"github.com/gin-gonic/gin"
)

// SetupWebShellRoutes 设置WebShell相关路由
func SetupWebShellRoutes(router *gin.RouterGroup) {
	webshellController := controllers.NewWebShellController()

	// WebShell管理路由
	webshell := router.Group("/webshell")
	{
		// 获取WebShell列表
		webshell.GET("", webshellController.GetWebShellList)

		// 获取WebShell统计信息
		webshell.GET("/stats", webshellController.GetWebShellStats)

		// 创建WebShell
		webshell.POST("", webshellController.CreateWebShell)

		// 根据ID操作WebShell
		webshell.GET("/:id", webshellController.GetWebShellByID)
		webshell.PUT("/:id", webshellController.UpdateWebShell)
		webshell.DELETE("/:id", webshellController.DeleteWebShell)

		// 测试WebShell连接
		webshell.POST("/:id/test", webshellController.TestConnection)
		// 获取WebShell基础信息
		webshell.POST("/:id/basic_info", webshellController.TestBasicInfo)
		// 获取WebShell命令历史记录
		webshell.GET("/:id/history", webshellController.GetCommandHistory)
		// 执行WebShell命令
		webshell.POST("/:id/execute", webshellController.ExecuteCommand)

		// 获取WebShell文件列表
		webshell.GET("/:id/files", webshellController.GetFileList)
	}
}
