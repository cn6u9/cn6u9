package utils

import (
	"testing"
)

func TestGetIPLocation(t *testing.T) {
	tests := []struct {
		name     string
		ip       string
		expected string
	}{
		{
			name:     "内网IP",
			ip:       "192.168.1.1",
			expected: "内网IP",
		},
		{
			name:     "本地IP",
			ip:       "127.0.0.1",
			expected: "本地IP",
		},
		{
			name:     "无效IP",
			ip:       "invalid-ip",
			expected: "未知",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			location := GetIPLocation(tt.ip)
			if location != tt.expected {
				t.Errorf("期望Location: %s, 得到: %s", tt.expected, location)
			}
		})
	}
}

func TestGetIPFromURL(t *testing.T) {
	tests := []struct {
		name     string
		url      string
		expected string
		hasError bool
	}{
		{
			name:     "IP地址URL",
			url:      "http://192.168.1.1:8080/shell.jsp",
			expected: "192.168.1.1",
			hasError: false,
		},
		{
			name:     "域名URL",
			url:      "http://example.com/shell.jsp",
			expected: "",
			hasError: false, // 域名解析可能成功
		},
		{
			name:     "本地主机URL",
			url:      "http://localhost:8080/shell.jsp",
			expected: "",
			hasError: false,
		},
		{
			name:     "无效URL",
			url:      "invalid-url",
			expected: "",
			hasError: true,
		},
		{
			name:     "空URL",
			url:      "",
			expected: "",
			hasError: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ip, err := GetIPFromURL(tt.url)

			if tt.hasError && err == nil {
				t.Errorf("期望有错误，但没有错误")
			}

			if !tt.hasError && err != nil {
				t.Errorf("不期望有错误，但得到错误: %v", err)
			}

			// 对于IP地址URL，检查结果
			if tt.url == "http://192.168.1.1:8080/shell.jsp" {
				if ip != tt.expected {
					t.Errorf("期望IP: %s, 得到: %s", tt.expected, ip)
				}
			}
		})
	}
}

func TestGetLocationFromURL(t *testing.T) {
	tests := []struct {
		name     string
		url      string
		hasError bool
	}{
		{
			name:     "内网IP URL",
			url:      "http://192.168.1.1:8080/shell.jsp",
			hasError: false,
		},
		{
			name:     "本地主机URL",
			url:      "http://localhost:8080/shell.jsp",
			hasError: false,
		},
		{
			name:     "无效URL",
			url:      "invalid-url",
			hasError: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ip, location, err := GetLocationFromURL(tt.url)

			if tt.hasError && err == nil {
				t.Errorf("期望有错误，但没有错误")
			}

			if !tt.hasError && err != nil {
				t.Errorf("不期望有错误，但得到错误: %v", err)
			}

			// 检查返回的IP和Location
			if !tt.hasError {
				if ip == "" {
					t.Errorf("IP地址不应为空")
				}
				if location == "" {
					t.Errorf("Location不应为空")
				}

				t.Logf("URL: %s, IP: %s, Location: %s", tt.url, ip, location)
			}
		})
	}
}

func TestUpdateWebShellLocation(t *testing.T) {
	tests := []struct {
		name     string
		url      string
		hasError bool
	}{
		{
			name:     "内网IP URL",
			url:      "http://192.168.1.1:8080/shell.jsp",
			hasError: false,
		},
		{
			name:     "本地主机URL",
			url:      "http://localhost:8080/shell.jsp",
			hasError: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ip, location, err := UpdateWebShellLocation(tt.url)

			if tt.hasError && err == nil {
				t.Errorf("期望有错误，但没有错误")
			}

			if !tt.hasError && err != nil {
				t.Errorf("不期望有错误，但得到错误: %v", err)
			}

			// 检查返回的IP和Location
			if !tt.hasError {
				if ip == "" {
					t.Errorf("IP地址不应为空")
				}
				if location == "" {
					t.Errorf("Location不应为空")
				}

				t.Logf("URL: %s, IP: %s, Location: %s", tt.url, ip, location)
			}
		})
	}
}
