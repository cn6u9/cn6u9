package utils

import (
	"crypto/rand"
	"fmt"
	"math/big"
	"net"
	"strconv"
)

// 生成包含数字和字母的随机字符串
func GenerateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)

	for i := range result {
		// 使用 crypto/rand 生成随机索引
		randomIndex, err := rand.Int(rand.Reader, big.NewInt(int64(len(charset))))
		if err != nil {
			// 如果 crypto/rand 失败，使用备用方法
			randomIndex = big.NewInt(int64(i*13+7) % int64(len(charset)))
		}
		result[i] = charset[randomIndex.Int64()]
	}

	return string(result)
}

// 检查端口是否被占用
func IsPortAvailable(port int) bool {
	address := ":" + strconv.Itoa(port)
	listener, err := net.Listen("tcp", address)
	if err != nil {
		return false // 端口被占用
	}
	listener.Close()
	return true // 端口可用
}

// 生成随机端口号 (1000-65535)，确保端口未被占用
func GenerateRandomPort() int {
	maxAttempts := 100 // 最大尝试次数
	attempts := 0

	for attempts < maxAttempts {
		portBytes := make([]byte, 2)
		rand.Read(portBytes)
		// 确保端口在 1000-65535 范围内
		port := 1000 + int(portBytes[0])%64535

		if IsPortAvailable(port) {
			return port
		}

		attempts++
	}

	// 如果无法找到可用端口，返回默认端口
	return 8080
}

// 生成随机路径
func GenerateRandomPath() string {
	// 生成 8-12 位随机字符串作为路径
	portBytes := make([]byte, 1)
	rand.Read(portBytes)
	length := 8 + int(portBytes[0])%5 // 8-12 位
	return GenerateRandomString(length)
}

// 生成随机URL
func GenerateRandomURL() string {
	port := GenerateRandomPort()
	path := GenerateRandomPath()
	return fmt.Sprintf("http://localhost:%d/%s", port, path)
}

// 生成随机账号密码
func GenerateRandomCredentials() (string, string) {
	username := "admin_" + GenerateRandomString(6)
	password := GenerateRandomString(12)
	return username, password
}
