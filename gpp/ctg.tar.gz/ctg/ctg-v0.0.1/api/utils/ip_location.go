package utils

import (
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// GetIPLocation 根据IP地址获取归属地信息
func GetIPLocation(ip string) string {
	// 验证IP地址格式
	if !isValidIP(ip) {
		return "未知"
	}

	// 检查是否为内网IP
	if isPrivateIP(ip) {
		return "内网"
	}

	// 检查是否为本地IP
	if isLocalIP(ip) {
		return "本地"
	}

	// 查询公网IP归属地
	location, err := queryPublicIPLocation(ip)
	if err != nil {
		return "未知"
	}

	return location
}

// GetIPFromURL 从URL中提取IP地址
func GetIPFromURL(urlStr string) (string, error) {
	// 解析URL
	parsedURL, err := url.Parse(urlStr)
	if err != nil {
		return "", fmt.Errorf("解析URL失败: %v", err)
	}

	// 获取主机名（hostname）
	host := parsedURL.Hostname()
	if host == "" {
		return "", fmt.Errorf("URL中未找到主机名")
	}

	// 检查是否为IP地址
	if net.ParseIP(host) != nil {
		return host, nil
	}

	// 如果不是IP地址，尝试解析主机名
	ips, err := net.LookupHost(host)
	if err != nil {
		return "", fmt.Errorf("解析主机名失败: %v", err)
	}

	if len(ips) == 0 {
		return "", fmt.Errorf("无法解析主机名: %s", host)
	}

	// 优先返回IPv4地址，如果没有则返回第一个地址
	for _, ip := range ips {
		if net.ParseIP(ip).To4() != nil {
			return ip, nil
		}
	}

	// 如果没有IPv4地址，返回第一个地址
	return ips[0], nil
}

// GetLocationFromURL 从URL获取IP地址并查询归属地信息
func GetLocationFromURL(urlStr string) (string, string, error) {
	// 从URL获取IP地址
	ip, err := GetIPFromURL(urlStr)
	if err != nil {
		return "", "", fmt.Errorf("获取IP地址失败: %v", err)
	}

	// 使用现有的GetIPLocation函数获取归属地信息
	location := GetIPLocation(ip)

	return ip, location, nil
}

// UpdateWebShellLocation 更新WebShell的Location和ExternalIP字段
func UpdateWebShellLocation(webshellURL string) (string, string, error) {
	// 获取IP地址和归属地
	ip, location, err := GetLocationFromURL(webshellURL)
	if err != nil {
		return "", "", err
	}

	return ip, location, nil
}

// isValidIP 验证IP地址格式
func isValidIP(ip string) bool {
	if ip == "" {
		return false
	}

	// 检查特殊值
	if ip == "localhost" || ip == "::1" {
		return true
	}

	// 简单的IP格式验证
	parts := strings.Split(ip, ".")
	if len(parts) != 4 {
		return false
	}

	for _, part := range parts {
		if part == "" {
			return false
		}
	}

	return true
}

// isPrivateIP 检查是否为内网IP
func isPrivateIP(ip string) bool {
	parts := strings.Split(ip, ".")
	if len(parts) != 4 {
		return false
	}

	// 192.168.x.x
	if parts[0] == "192" && parts[1] == "168" {
		return true
	}

	// 10.x.x.x
	if parts[0] == "10" {
		return true
	}

	// 172.16.x.x - 172.31.x.x
	if parts[0] == "172" {
		// 直接比较字符串，避免fmt.Sscanf的问题
		if parts[1] >= "16" && parts[1] <= "31" {
			return true
		}
	}

	return false
}

// isLocalIP 检查是否为本地IP
func isLocalIP(ip string) bool {
	return ip == "127.0.0.1" || ip == "localhost" || ip == "::1"
}

// queryPublicIPLocation 查询公网IP归属地
func queryPublicIPLocation(ip string) (string, error) {
	// 创建HTTP客户端
	client := &http.Client{
		Timeout: 5 * time.Second,
	}

	// 使用免费的IP查询API
	url := fmt.Sprintf("https://api.iping.cc/v1/query?ip=%s&language=zh", ip)

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", fmt.Errorf("创建请求失败: %v", err)
	}

	// 设置请求头
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
	req.Header.Set("Accept", "application/json")

	// 发送请求
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("请求失败: %v", err)
	}
	defer resp.Body.Close()

	// 读取响应
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("读取响应失败: %v", err)
	}

	// 解析JSON响应
	var result struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data struct {
			Country string `json:"country"`
			Region  string `json:"region"`
			ISP     string `json:"isp"`
		} `json:"data"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return "", fmt.Errorf("解析响应失败: %v", err)
	}

	// 检查API状态
	if result.Code != 200 || result.Msg != "success" {
		return "", fmt.Errorf("IP查询失败: %s", result.Msg)
	}

	// 构建位置信息
	parts := []string{}

	if result.Data.Region != "" {
		parts = append(parts, result.Data.Region)
	}
	if result.Data.ISP != "" {
		parts = append(parts, result.Data.ISP)
	}

	if len(parts) == 0 {
		return "未知", nil
	}

	return strings.Join(parts, ""), nil
}
