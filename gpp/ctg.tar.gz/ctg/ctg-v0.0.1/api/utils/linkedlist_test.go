package utils

import (
	"fmt"
	"testing"
)

func TestLinkedList(t *testing.T) {
	// 创建新的链表
	list := NewLinkedList()

	// 测试空链表
	if !list.IsEmpty() {
		t.Error("新创建的链表应该是空的")
	}

	if list.Length() != 0 {
		t.Error("新创建的链表长度应该是0")
	}

	// 测试添加元素
	list.Append("第一个元素")
	list.Append("第二个元素")
	list.Append("第三个元素")

	if list.Length() != 3 {
		t.Errorf("链表长度应该是3，实际是%d", list.Length())
	}

	// 测试在开头添加元素
	list.Prepend("零号元素")

	if list.Length() != 4 {
		t.Errorf("链表长度应该是4，实际是%d", list.Length())
	}

	// 测试获取元素
	if data, ok := list.GetAt(0); !ok || data != "零号元素" {
		t.Errorf("第0个元素应该是'零号元素'，实际是%v", data)
	}

	if data, ok := list.GetAt(1); !ok || data != "第一个元素" {
		t.Errorf("第1个元素应该是'第一个元素'，实际是%v", data)
	}

	// 测试删除元素
	if !list.DeleteAt(1) {
		t.Error("删除第1个元素应该成功")
	}

	if list.Length() != 3 {
		t.Errorf("删除后链表长度应该是3，实际是%d", list.Length())
	}

	// 测试边界情况
	if list.DeleteAt(-1) {
		t.Error("删除-1位置的元素应该失败")
	}

	if list.DeleteAt(10) {
		t.Error("删除超出范围的元素应该失败")
	}

	// 测试获取超出范围的元素
	if _, ok := list.GetAt(10); ok {
		t.Error("获取超出范围的元素应该失败")
	}

	// 测试查找功能
	if index, found := list.Find("第一个元素"); !found || index != 1 {
		t.Errorf("查找'第一个元素'应该在第1个位置，实际在%d", index)
	}

	// 测试转换为切片
	slice := list.ToSlice()
	if len(slice) != 3 {
		t.Errorf("切片长度应该是3，实际是%d", len(slice))
	}

	// 测试从切片创建链表
	newList := FromSlice(slice)
	if newList.Length() != 3 {
		t.Errorf("从切片创建的链表长度应该是3，实际是%d", newList.Length())
	}

	// 测试清空链表
	list.Clear()
	if !list.IsEmpty() {
		t.Error("清空后链表应该是空的")
	}

	fmt.Println("链表测试通过！")
}

// 演示链表的使用
func ExampleLinkedList() {
	// 创建链表
	list := NewLinkedList()

	// 添加元素
	list.Append("苹果")
	list.Append("香蕉")
	list.Append("橙子")

	// 在开头添加元素
	list.Prepend("葡萄")

	// 打印链表
	list.Print()

	// 获取元素
	if data, ok := list.GetAt(1); ok {
		fmt.Printf("第1个元素: %v\n", data)
	}

	// 删除元素
	list.DeleteAt(2)

	// 再次打印
	list.Print()

	// 输出:
	// 链表内容: 葡萄 -> 苹果 -> 香蕉 -> 橙子 -> nil
	// 第1个元素: 苹果
	// 链表内容: 葡萄 -> 苹果 -> 橙子 -> nil
}
