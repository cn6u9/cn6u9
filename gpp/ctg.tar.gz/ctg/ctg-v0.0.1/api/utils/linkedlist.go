package utils

import "fmt"

// ListNode 链表节点结构
type ListNode struct {
	Data interface{}
	Next *ListNode
}

// LinkedList 链表结构
type LinkedList struct {
	Head *ListNode
	Size int
}

// NewListNode 创建新的链表节点
func NewListNode(data interface{}) *ListNode {
	return &ListNode{
		Data: data,
		Next: nil,
	}
}

// NewLinkedList 创建新的链表
func NewLinkedList() *LinkedList {
	return &LinkedList{
		Head: nil,
		Size: 0,
	}
}

// Append 在链表末尾添加节点
func (list *LinkedList) Append(data interface{}) {
	newNode := NewListNode(data)

	if list.Head == nil {
		list.Head = newNode
	} else {
		current := list.Head
		for current.Next != nil {
			current = current.Next
		}
		current.Next = newNode
	}
	list.Size++
}

// Prepend 在链表开头添加节点
func (list *LinkedList) Prepend(data interface{}) {
	newNode := NewListNode(data)
	newNode.Next = list.Head
	list.Head = newNode
	list.Size++
}

// DeleteAt 删除指定位置的节点
func (list *LinkedList) DeleteAt(index int) bool {
	if index < 0 || index >= list.Size {
		return false
	}

	if index == 0 {
		list.Head = list.Head.Next
		list.Size--
		return true
	}

	current := list.Head
	for i := 0; i < index-1; i++ {
		current = current.Next
	}

	current.Next = current.Next.Next
	list.Size--
	return true
}

// GetAt 获取指定位置的节点数据
func (list *LinkedList) GetAt(index int) (interface{}, bool) {
	if index < 0 || index >= list.Size {
		return nil, false
	}

	current := list.Head
	for i := 0; i < index; i++ {
		current = current.Next
	}

	return current.Data, true
}

// Print 打印链表内容
func (list *LinkedList) Print() {
	current := list.Head
	fmt.Print("链表内容: ")
	for current != nil {
		fmt.Printf("%v -> ", current.Data)
		current = current.Next
	}
	fmt.Println("nil")
}

// Length 链表长度
func (list *LinkedList) Length() int {
	return list.Size
}

// IsEmpty 判断链表是否为空
func (list *LinkedList) IsEmpty() bool {
	return list.Size == 0
}

// Find 查找包含指定数据的节点
func (list *LinkedList) Find(data interface{}) (int, bool) {
	current := list.Head
	index := 0

	for current != nil {
		if current.Data == data {
			return index, true
		}
		current = current.Next
		index++
	}

	return -1, false
}

// Clear 清空链表
func (list *LinkedList) Clear() {
	list.Head = nil
	list.Size = 0
}

// ToSlice 将链表转换为切片
func (list *LinkedList) ToSlice() []interface{} {
	result := make([]interface{}, 0, list.Size)
	current := list.Head

	for current != nil {
		result = append(result, current.Data)
		current = current.Next
	}

	return result
}

// FromSlice 从切片创建链表
func FromSlice(data []interface{}) *LinkedList {
	list := NewLinkedList()
	for _, item := range data {
		list.Append(item)
	}
	return list
}
