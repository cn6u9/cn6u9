# CTG 配置同步指南

## 概述

CTG项目支持前后端配置自动同步，确保前端代理配置能够动态获取后端的 `base_path` 设置。

## 配置同步方式

### 1. 自动同步（推荐）

#### 使用npm脚本
```bash
# 在web目录下运行
cd web
npm run sync-config
```

#### 使用Node脚本
```bash
# 直接运行脚本
node scripts/sync-config.js
```

### 2. 手动配置

#### 环境变量方式
创建 `.env.local` 文件：
```bash
# 后端服务地址
BACKEND_URL=http://127.0.0.1:1225

# API基础路径
API_BASE_PATH=/uDVHAREj

# 代理目标地址
PROXY_TARGET=http://127.0.0.1:1225
```

#### 直接修改配置文件
编辑 `web/config/env.ts` 文件：
```typescript
export const API_CONFIG = {
  BACKEND_URL: 'http://127.0.0.1:1225',
  BASE_PATH: '/uDVHAREj',  // 修改这里的值
  PROXY_TARGET: 'http://127.0.0.1:1225',
};
```

## 配置同步流程

### 1. 后端配置接口

后端提供了配置获取接口：

- **完整配置**: `GET /uDVHAREj/config`
- **仅base_path**: `GET /uDVHAREj/base-path`

响应格式：
```json
{
  "success": true,
  "data": {
    "domain_name": "localhost",
    "ip": "127.0.0.1",
    "port": "1225",
    "base_path": "/uDVHAREj",
    "database": "./database.db"
  },
  "message": "配置获取成功"
}
```

### 2. 前端配置更新

配置同步脚本会：

1. 从后端获取配置
2. 更新 `web/config/env.ts` 文件
3. 创建 `.env.local` 环境变量文件
4. 更新代理配置

### 3. 代理配置

更新后的代理配置：
```typescript
// web/config/proxy.ts
import { API_CONFIG, getProxyRewrite } from './env';

export default {
  dev: {
    '/api/': {
      target: API_CONFIG.PROXY_TARGET,
      changeOrigin: true,
      pathRewrite: getProxyRewrite(), // 动态获取
    },
  },
};
```

## 使用场景

### 开发环境

1. **首次启动**：
   ```bash
   cd web
   npm run sync-config
   npm run start:dev
   ```

2. **配置变更后**：
   ```bash
   # 修改后端 ctg.conf 后
   npm run sync-config
   # 重启前端开发服务器
   ```

### 生产环境

1. **Docker构建**：
   ```dockerfile
   # Dockerfile 会自动运行配置同步
   RUN node scripts/sync-config.js
   RUN npm run build
   ```

2. **手动部署**：
   ```bash
   # 部署前同步配置
   npm run sync-config
   npm run build
   ```

## 故障排除

### 常见问题

1. **无法连接后端**
   ```
   ⚠️  无法获取后端配置，使用默认值: connect ECONNREFUSED
   ```
   - 确保后端服务已启动
   - 检查端口和地址配置

2. **配置同步失败**
   ```
   ❌ 配置同步失败: HTTP 404: Not Found
   ```
   - 检查后端路由是否正确配置
   - 确认 `base_path` 设置

3. **代理不生效**
   - 重启前端开发服务器
   - 检查浏览器网络请求
   - 确认代理配置已更新

### 调试方法

1. **检查配置状态**：
   ```bash
   # 查看当前配置
   cat web/config/env.ts
   cat web/.env.local
   ```

2. **测试后端接口**：
   ```bash
   curl http://127.0.0.1:1225/uDVHAREj/config
   ```

3. **查看同步日志**：
   ```bash
   npm run sync-config
   ```

## 最佳实践

### 1. 开发流程
- 修改后端配置后，立即运行 `npm run sync-config`
- 将配置同步脚本集成到开发工作流中
- 使用环境变量管理不同环境的配置

### 2. 配置管理
- 保持前后端配置的一致性
- 使用有意义的 `base_path` 值
- 定期检查和更新配置

### 3. 自动化
- 在CI/CD流程中集成配置同步
- 使用Docker构建时自动同步
- 配置变更后自动触发同步

## 配置示例

### 开发环境
```bash
# ctg.conf
{
  "port": "1225",
  "base_path": "/dev-api"
}

# 运行同步
npm run sync-config

# 结果：前端代理将 /api 重写为 /dev-api
```

### 生产环境
```bash
# ctg.conf
{
  "port": "8080",
  "base_path": "/api/v1"
}

# 运行同步
npm run sync-config

# 结果：前端代理将 /api 重写为 /api/v1
```

## 总结

通过配置同步机制，CTG项目实现了：

1. **动态配置**: 前端自动获取后端配置
2. **一致性**: 确保前后端配置同步
3. **灵活性**: 支持不同环境的配置
4. **自动化**: 减少手动配置错误

建议在开发过程中使用 `npm run sync-config` 命令来保持配置同步。
