import { AvatarDropdown, AvatarName, Footer, Question, GlobalNotification, GlobalStatusBar, GlobalSplitter } from '@/components';
// import { currentUser as queryCurrentUser } from '@/services/ant-design-pro/api';
import { LinkOutlined } from '@ant-design/icons';
import type { Settings as LayoutSettings } from '@ant-design/pro-components';
import { SettingDrawer } from '@ant-design/pro-components';
import type { RunTimeLayoutConfig } from '@umijs/max';
import { history, Link } from '@umijs/max';
import defaultSettings from '../config/defaultSettings';
import { errorConfig } from './requestErrorConfig';
import { getWebShellList } from '@/services/webshell';
import { useState, useEffect } from 'react';
import type { WebShell } from '@/services/webshell';

const isDev = process.env.NODE_ENV === 'development';
// const loginPath = '/user/login';

/**
 * @see  https://umijs.org/zh-CN/plugins/plugin-initial-state
 * */
export async function getInitialState(): Promise<{
  settings?: Partial<LayoutSettings>;
  currentUser?: API.CurrentUser;
  loading?: boolean;
  fetchUserInfo?: () => Promise<API.CurrentUser | undefined>;
}> {
  // 简化认证逻辑，直接返回默认设置
  return {
    fetchUserInfo: async () => {
      // 返回一个默认用户信息
      return {
        name: 'admin',
        avatar: '/icons/ctg_raw_256x256.png',
        userid: '1',
        email: 'admin@admin.com',
        signature: 'WebShell管理',
        title: '管理员',
        group: 'CTG团队',
        tags: [{ key: '0', label: '管理员' }],
        notifyCount: 0,
        unreadCount: 0,
        country: '中国',
        access: 'admin',
        geographic: {
          province: { label: '北京', key: '330000' },
          city: { label: '北京', key: '330100' },
        },
        address: '北京市朝阳区',
        phone: '0752-268888888',
      };
    },
    currentUser: {
      name: 'admin',
      avatar: '/icons/ctg_raw_256x256.png',
      userid: '1',
      email: 'admin@ctg.com',
      signature: 'WebShell管理',
      title: '管理员',
      group: 'CTG团队',
      tags: [{ key: '0', label: '管理员' }],
      notifyCount: 0,
      unreadCount: 0,
      country: '中国',
      access: 'admin',
      geographic: {
        province: { label: '北京', key: '330000' },
        city: { label: '北京', key: '330100' },
      },
      address: '北京市朝阳区',
      phone: '0752-268888888',
    },
    settings: defaultSettings as Partial<LayoutSettings>,
  };
}

// ProLayout 支持的api https://procomponents.ant.design/components/layout
export const layout: RunTimeLayoutConfig = ({ initialState, setInitialState }) => {
  return {
    actionsRender: () => [<Question key="doc" />],
    contentStyle: {
      margin: 0,
      padding: 0,
    },
    avatarProps: {
      src: initialState?.currentUser?.avatar,
      title: <AvatarName />,
      render: (_, avatarChildren) => {
        return <AvatarDropdown>{avatarChildren}</AvatarDropdown>;
      },
    },
    // footerRender: () => <Footer />,
    onPageChange: () => {
      // 简化页面变更逻辑，直接允许访问
      const { location } = history;
      // 暂时注释掉认证检查
      // if (!initialState?.currentUser && location.pathname !== loginPath) {
      //   history.push(loginPath);
      // }
    },
    bgLayoutImgList: [
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/D2LWSqNny4sAAAAAAAAAAAAAFl94AQBr',
        left: 85,
        bottom: 100,
        height: '303px',
      },
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/C2TWRpJpiC0AAAAAAAAAAAAAFl94AQBr',
        bottom: -68,
        right: -45,
        height: '303px',
      },
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/F6vSTbj8KpYAAAAAAAAAAAAAFl94AQBr',
        bottom: 0,
        left: 0,
        width: '331px',
      },
    ],
    links: [],
    menuHeaderRender: undefined,
    // 自定义 403 页面
    // unAccessible: <div>unAccessible</div>,
    // 增加一个 loading 的状态
    childrenRender: (children) => {
      // if (initialState?.loading) return <PageLoading />;
      
      // 创建WebShell数据管理组件
      const WebShellDataProvider = () => {
        const [webshells, setWebshells] = useState<WebShell[]>([]);
        const [splitterCollapsed, setSplitterCollapsed] = useState(false);
        
        useEffect(() => {
          const fetchWebShells = async () => {
            try {
              const data = await getWebShellList();
              setWebshells(data);
            } catch (error) {
              console.error('Failed to fetch WebShells:', error);
            }
          };
          
          fetchWebShells();
        }, []);

        // 监听localStorage变化来同步splitter状态
        useEffect(() => {
          const handleStorageChange = () => {
            const collapsed = localStorage.getItem('splitterCollapsed');
            setSplitterCollapsed(collapsed === 'true');
          };
          
          const handleCustomEvent = () => {
            // 直接从localStorage读取最新状态
            const collapsed = localStorage.getItem('splitterCollapsed');
            console.log('app.tsx handleCustomEvent: 从localStorage读取状态:', collapsed);
            setSplitterCollapsed(collapsed === 'true');
            console.log('app.tsx handleCustomEvent: 设置splitterCollapsed为:', collapsed === 'true');
          };
          
          // 初始检查
          handleStorageChange();
          
          // 监听storage事件（跨标签页）
          window.addEventListener('storage', handleStorageChange);
          
          // 监听自定义事件（同页面内的变化）
          window.addEventListener('splitterStateChange', handleCustomEvent);
          
          return () => {
            window.removeEventListener('storage', handleStorageChange);
            window.removeEventListener('splitterStateChange', handleCustomEvent);
          };
        }, []);

        // 监听splitterCollapsed状态变化
        useEffect(() => {
          console.log('app.tsx useEffect: splitterCollapsed changed to:', splitterCollapsed, 'height =', splitterCollapsed ? '40px' : '500px');
        }, [splitterCollapsed]);
        
        return (
          <>
            <div style={{ 
              position: 'relative',
              height: '100vh', // 固定高度100vh
              margin: 0,
              padding: 0
            }}>
              {/* 主内容区域 */}
              <div 
                data-main-content
                style={{ 
                  height: splitterCollapsed ? 'calc(100vh - 20px)' : 'calc(100vh - 500px)', // 根据splitter状态动态计算高度
                  overflow: 'auto', // 允许表格内部滚动
                  margin: 0,
                  padding: 0,
                  transition: 'height 0.3s ease' // 添加平滑过渡动画
                }}
              >
                {children}
              </div>
              
              {/* Splitter区域 - 固定在底部 */}
              <div style={{ 
                position: 'fixed',
                bottom: 0,
                left: 0,
                right: 0,
                height: splitterCollapsed ? '20px' : '500px', // 根据状态动态设置高度
                zIndex: 1000, // 确保在最上层
                margin: 0,
                padding: 0,
                transition: 'height 0.3s ease' // 添加平滑过渡动画
              }}>
                <GlobalSplitter webshells={webshells} />
              </div>
            </div>
            
            {/* 全局组件 */}
            <GlobalNotification />
            <GlobalStatusBar />
          </>
        );
      };
      
      return <WebShellDataProvider />;
    },
    ...initialState?.settings,
  };
};

/**
 * @name request 配置，可以配置错误处理
 * 它基于 axios 和 ahooks 的 useRequest 提供了一套统一的网络请求和错误处理方案。
 * @doc https://umijs.org/docs/max/request#配置
 */
export const request = {
  ...errorConfig,
};
