// 临时注释掉TableList页面
import React from 'react';

const TableList: React.FC = () => {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h2>TableList页面已暂时禁用</h2>
      <p>此页面功能正在开发中...</p>
    </div>
  );
};

export default TableList;
