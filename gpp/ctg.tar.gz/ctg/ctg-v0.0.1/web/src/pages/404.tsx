// 临时注释掉404页面
import React from 'react';

const NotFound: React.FC = () => {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h2>404页面已暂时禁用</h2>
      <p>此页面功能正在开发中...</p>
    </div>
  );
};

export default NotFound;
