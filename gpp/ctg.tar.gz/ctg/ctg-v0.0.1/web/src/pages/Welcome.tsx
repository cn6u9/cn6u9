// import { HeartTwoTone, SmileTwoTone } from '@ant-design/icons';
// import { PageContainer } from '@ant-design/pro-components';
// import '@umijs/max';
// import { Alert, Card, Typography } from 'antd';
// import React from 'react';
// import { useModel } from '@umijs/max';
// import styles from './Welcome.less';

// const Welcome: React.FC = () => {
//   const { initialState } = useModel('@@initialState');
//   return (
//     <PageContainer>
//       <Card>
//         <Alert
//           message={` 欢迎 ${initialState?.currentUser?.name}，这是一个管理页面。`}
//           type="success"
//           showIcon
//           banner
//           style={{
//             margin: -12,
//             marginBottom: 24,
//           }}
//         />
//         <Typography.Text strong>
//           高级表格{' '}
//           <a
//             href="https://procomponents.ant.design/components/table"
//             rel="noopener noreferrer"
//             target="__blank"
//           >
//             欢迎使用
//           </a>
//         </Typography.Text>
//       </Card>
//     </PageContainer>
//   );
// };

// export default Welcome;

// 临时注释掉Welcome页面
import React from 'react';

const Welcome: React.FC = () => {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h2>Welcome页面已暂时禁用</h2>
      <p>此页面功能正在开发中...</p>
    </div>
  );
};

export default Welcome;
