import {
  ProFormSelect,
  ProFormText,
  ProFormTextArea,
  ModalForm,
  ProFormGroup,
  ProForm,
} from '@ant-design/pro-components';
import '@umijs/max';
import { Button, Divider, message, Tag, Input, Flex, theme, Tooltip, Row, Col } from 'antd';
import type { InputRef } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import React, { useState, useEffect, useRef } from 'react';
import type { WebShell } from '@/services/webshell';

// UpdateTagInput组件
const UpdateTagInput: React.FC<{ value?: string; onChange?: (value: string) => void }> = ({ value, onChange }) => {
  const { token } = theme.useToken();
  const [tags, setTags] = useState<string[]>([]);
  const [inputVisible, setInputVisible] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [editInputIndex, setEditInputIndex] = useState(-1);
  const [editInputValue, setEditInputValue] = useState('');
  const inputRef = useRef<InputRef>(null);
  const editInputRef = useRef<InputRef>(null);

  // 初始化标签
  useEffect(() => {
    if (value) {
      const tagArray = value.split(',').map(tag => tag.trim()).filter(tag => tag);
      setTags(tagArray);
    }
  }, [value]);

  useEffect(() => {
    if (inputVisible) {
      inputRef.current?.focus();
    }
  }, [inputVisible]);

  useEffect(() => {
    editInputRef.current?.focus();
  }, [editInputValue]);

  const handleClose = (removedTag: string) => {
    const newTags = tags.filter((tag) => tag !== removedTag);
    setTags(newTags);
    onChange?.(newTags.join(','));
  };

  const showInput = () => {
    setInputVisible(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = () => {
    if (inputValue && !tags.includes(inputValue)) {
      const newTags = [...tags, inputValue];
      setTags(newTags);
      onChange?.(newTags.join(','));
    }
    setInputVisible(false);
    setInputValue('');
  };

  const handleEditInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditInputValue(e.target.value);
  };

  const handleEditInputConfirm = () => {
    const newTags = [...tags];
    newTags[editInputIndex] = editInputValue;
    setTags(newTags);
    onChange?.(newTags.join(','));
    setEditInputIndex(-1);
    setEditInputValue('');
  };

  const tagInputStyle: React.CSSProperties = {
    width: 64,
    height: 22,
    marginInlineEnd: 8,
    verticalAlign: 'top',
  };

  const tagPlusStyle: React.CSSProperties = {
    height: 22,
    background: token.colorBgContainer,
    borderStyle: 'dashed',
  };

  return (
    <Flex gap="4px 0" wrap>
      {tags.map<React.ReactNode>((tag, index) => {
        if (editInputIndex === index) {
          return (
            <Input
              ref={editInputRef}
              key={tag}
              size="small"
              style={tagInputStyle}
              value={editInputValue}
              onChange={handleEditInputChange}
              onBlur={handleEditInputConfirm}
              onPressEnter={handleEditInputConfirm}
            />
          );
        }
        const isLongTag = tag.length > 20;
        const tagElem = (
          <Tag
            key={tag}
            closable
            style={{ userSelect: 'none' }}
            onClose={() => handleClose(tag)}
          >
            <span
              onDoubleClick={(e) => {
                setEditInputIndex(index);
                setEditInputValue(tag);
                e.preventDefault();
              }}
            >
              {isLongTag ? `${tag.slice(0, 20)}...` : tag}
            </span>
          </Tag>
        );
        return isLongTag ? (
          <Tooltip title={tag} key={tag}>
            {tagElem}
          </Tooltip>
        ) : (
          tagElem
        );
      })}
      {inputVisible ? (
        <Input
          ref={inputRef}
          type="text"
          size="small"
          style={tagInputStyle}
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleInputConfirm}
          onPressEnter={handleInputConfirm}
        />
      ) : (
        <Tag style={tagPlusStyle} icon={<PlusOutlined />} onClick={showInput}>
          添加标签
        </Tag>
      )}
    </Flex>
  );
};

export type FormValueType = {
  id?: number;
  name?: string;
  scriptType?: 'JSP' | 'JSPX' | 'PHP' | 'ASP' | 'ASPX' | 'Other';
  webshellType?: 'Behinder' | 'Godzilla' | 'Antword' | 'Custom' | 'Other';
  url?: string;
  pass?: string;
  key?: string;
  crypto?: string;
  encoding?: string;
  tag?: string;
  notes?: string;
  userAgent?: string;
  proxyAddress?: string;
  status?: 'Disabled' | 'Enabled' | 'Connected' | 'Disconnected';
} & Partial<WebShell>;

export type UpdateFormProps = {
  onCancel: (flag?: boolean, formVals?: FormValueType) => void;
  onSubmit: (values: FormValueType) => Promise<void>;
  updateModalOpen: boolean;
  values: Partial<WebShell>;
};

const UpdateForm: React.FC<UpdateFormProps> = (props) => {
  // 使用内部状态来管理表单值
  const [formValues, setFormValues] = useState<Partial<WebShell>>(props.values);

  // 监听values的变化，更新内部状态
  useEffect(() => {
    setFormValues(props.values);
  }, [props.values]);

  return (
    <ModalForm
      title={'配置 WebShell'}
      width="800px"
      open={props.updateModalOpen}
      onOpenChange={(open) => {
        if (!open) {
          props.onCancel();
        }
      }}
      layout="horizontal"
      onFinish={async (values) => {
        await props.onSubmit(values);
      }}
      initialValues={formValues}
      modalProps={{
        destroyOnClose: true,
      }}
    >
      {/* 基础配置 */}
      <Divider 
        orientation="left" 
        orientationMargin={50}
        style={{ 
          margin: '24px 0', 
          fontSize: '16px', 
          fontWeight: 'bold',
          height: '2px',
          borderTopWidth: '2px',
          borderTopColor: '#d9d9d9'
        }}
      >
        基础配置
      </Divider>
      
      {/* 隐藏的ID字段，用于传递ID */}
      <ProFormText
        name="id"
        hidden
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />
      
      <ProFormText
        rules={[
          {
            required: true,
            message: '请输入WebShell名称',
          },
        ]}
        width="lg"
        name="name"
        label="名称"
        placeholder="请输入WebShell名称"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormSelect
        rules={[
          {
            required: true,
            message: '请选择WebShell类型',
          },
        ]}
        width="lg"
        name="webshellType"
        label="WebShell类型"
        placeholder="请选择WebShell类型"
        options={[
          { label: 'Behinder', value: 'Behinder' },
          { label: 'Godzilla', value: 'Godzilla' },
          { label: 'Antword', value: 'Antword' },
          { label: 'Custom', value: 'Custom' },
          { label: 'Other', value: 'Other' },
        ]}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormText
        rules={[
          {
            required: true,
            message: 'URL为必填项',
          },
        ]}
        width="lg"
        name="url"
        label="URL"
        placeholder="请输入目标URL"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormSelect
        rules={[
          {
            required: true,
            message: '请选择脚本类型',
          },
        ]}
        width="lg"
        name="scriptType"
        label="脚本类型"
        placeholder="请选择脚本类型"
        options={[
          { label: 'PHP', value: 'PHP' },
          { label: 'ASP', value: 'ASP' },
          { label: 'ASPX', value: 'ASPX' },
          { label: 'JSP', value: 'JSP' },
          { label: 'JSPX', value: 'JSPX' },
          { label: '其他', value: 'Other' },
        ]}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormText.Password
        width="lg"
        name="pass"
        label="密码"
        placeholder="请输入密码"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormText
        width="lg"
        name="key"
        label="密钥"
        placeholder="请输入密钥"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormSelect
        width="lg"
        name="crypto"
        label="加密方式"
        placeholder="请选择加密方式"
        options={[
          { label: 'JAVA_AES_BASE64', value: 'JAVA_AES_BASE64' },
          { label: 'JAVA_AES_RAW', value: 'JAVA_AES_RAW' },
          { label: 'CSHARP_AES_BASE64', value: 'CSHARP_AES_BASE64' },
          { label: 'CSHARP_AES_RAW', value: 'CSHARP_AES_RAW' },
          { label: 'PHP_XOR_BASE64', value: 'PHP_XOR_BASE64' },
          { label: 'PHP_XOR_RAW', value: 'PHP_XOR_RAW' },
          { label: 'ASP_XOR_BASE64', value: 'ASP_XOR_BASE64' },
          { label: 'ASP_XOR_RAW', value: 'ASP_XOR_RAW' },
          { label: 'DES', value: 'DES' },
          { label: 'RSA', value: 'RSA' },
          { label: 'BASE64', value: 'BASE64' },
          { label: 'NONE', value: 'NONE' },
        ]}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormSelect
        width="lg"
        name="encoding"
        label="编码方式"
        placeholder="请选择编码方式"
        options={[
          { label: 'UTF-8', value: 'utf8' },
          { label: 'GBK', value: 'gbk' },
          { label: 'GB2312', value: 'gb2312' },
          { label: 'BIG5', value: 'BIG5' },
          { label: 'GB18030', value: 'GB18030' },
          { label: 'ISO-8859-1', value: 'ISO_8859_1' },
          { label: 'Latin1', value: 'latin1' },
          { label: 'UTF-16', value: 'utf16' },
          { label: 'ASCII', value: 'ascii' },
          { label: 'CP850', value: 'cp850' },
        ]}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormSelect
        width="lg"
        name="status"
        label="状态"
        placeholder="请选择状态"
        options={[
          { label: '未启用', value: 'Disabled' },
          { label: '已启用', value: 'Enabled' },
          { label: '已连接', value: 'Connected' },
          { label: '已断开', value: 'Disconnected' },
        ]}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProForm.Item
          label="标签"
          name="tag"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        >
          <UpdateTagInput />
      </ProForm.Item>

      <ProFormTextArea
        width="lg"
        name="notes"
        label="备注"
        placeholder="请输入备注信息"
        fieldProps={{
          rows: 3,
        }}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      {/* 高级配置 */}
      <Divider 
        orientation="left" 
        orientationMargin={50}
        style={{ 
          margin: '24px 0', 
          fontSize: '16px', 
          fontWeight: 'bold',
          height: '2px',
          borderTopWidth: '2px',
          borderTopColor: '#d9d9d9'
        }}
      >
        高级配置
      </Divider>

      <ProFormText
        width="lg"
        name="userAgent"
        label="User-Agent"
        placeholder="请输入User-Agent配置"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      <ProFormText
        width="lg"
        name="proxyAddress"
        label="代理"
        placeholder="请输入代理地址，例如 http://127.0.0.1:8080"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
      />

      {/* 操作按钮 */}
      <ProFormGroup style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
        <Button
          type="default"
          onClick={() => {
            message.info('测试连接功能待实现');
          }}
        >
          测试连接
        </Button>
        <div>
          <Button
            type="primary"
            htmlType="submit"
            style={{ marginRight: 16 }}
          >
            保存
          </Button>
          <Button
            type="default"
            onClick={() => {
              props.onCancel();
            }}
          >
            取消
          </Button>
        </div>
      </ProFormGroup>
    </ModalForm>
  );
};

export default UpdateForm;
