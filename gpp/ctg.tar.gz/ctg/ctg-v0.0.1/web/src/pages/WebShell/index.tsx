import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns, ProDescriptionsItemProps } from '@ant-design/pro-components';
import {
  FooterToolbar,
  ModalForm,
  ProDescriptions,
  ProForm,
  ProFormText,
  ProFormTextArea,
  ProFormDigit,
  ProTable,ProFormGroup, ProFormSelect
} from '@ant-design/pro-components';
import '@umijs/max';
import { Button, Drawer, Tooltip, Input, message, Collapse, Divider, Select, Tag, Flex, theme, Radio, Modal, Row, Col } from 'antd';
import type { InputRef } from 'antd';
import { EditableCell } from '@/components';
import StatusTag from '@/components/StatusTag';
import React, { useRef, useState, useEffect } from 'react';
import { CodeOutlined, FileTextOutlined, ApiOutlined, SettingOutlined, ReloadOutlined, PauseOutlined } from '@ant-design/icons';
import type { FormValueType } from './components/UpdateForm';
import UpdateForm from './components/UpdateForm';
import {
  getWebShellList,
  createWebShell,
  updateWebShell,
  deleteWebShell,
  testConnection,
  getBasicInfo,
  getCommandHistory,
  getWebShellStats,
  getFileList,
  type WebShell,
} from '@/services/webshell';
import commandExecutor, { type CommandResult } from '@/services/commandExecutor';

// TagInput组件
const TagInput: React.FC<{ value?: string; onChange?: (value: string) => void }> = ({ value, onChange }) => {
  const { token } = theme.useToken();
  const [tags, setTags] = useState<string[]>([]);
  const [inputVisible, setInputVisible] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [editInputIndex, setEditInputIndex] = useState(-1);
  const [editInputValue, setEditInputValue] = useState('');
  const inputRef = useRef<InputRef>(null);
  const editInputRef = useRef<InputRef>(null);

  // 初始化标签
  React.useEffect(() => {
    if (value) {
      const tagArray = value.split(',').map(tag => tag.trim()).filter(tag => tag);
      setTags(tagArray);
    }
  }, [value]);

  React.useEffect(() => {
    if (inputVisible) {
      inputRef.current?.focus();
    }
  }, [inputVisible]);

  React.useEffect(() => {
    editInputRef.current?.focus();
  }, [editInputValue]);

  const handleClose = (removedTag: string) => {
    const newTags = tags.filter((tag) => tag !== removedTag);
    setTags(newTags);
    onChange?.(newTags.join(','));
  };

  const showInput = () => {
    setInputVisible(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = () => {
    if (inputValue && !tags.includes(inputValue)) {
      const newTags = [...tags, inputValue];
      setTags(newTags);
      onChange?.(newTags.join(','));
    }
    setInputVisible(false);
    setInputValue('');
  };

  const handleEditInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditInputValue(e.target.value);
  };

  const handleEditInputConfirm = () => {
    const newTags = [...tags];
    newTags[editInputIndex] = editInputValue;
    setTags(newTags);
    onChange?.(newTags.join(','));
    setEditInputIndex(-1);
    setEditInputValue('');
  };

  const tagInputStyle: React.CSSProperties = {
    width: 64,
    height: 22,
    marginInlineEnd: 8,
    verticalAlign: 'top',
  };

  const tagPlusStyle: React.CSSProperties = {
    height: 22,
    background: token.colorBgContainer,
    borderStyle: 'dashed',
  };

  return (
    <Flex gap="4px 0" wrap>
      {tags.map<React.ReactNode>((tag, index) => {
        if (editInputIndex === index) {
          return (
            <Input
              ref={editInputRef}
              key={tag}
              size="small"
              style={tagInputStyle}
              value={editInputValue}
              onChange={handleEditInputChange}
              onBlur={handleEditInputConfirm}
              onPressEnter={handleEditInputConfirm}
            />
          );
        }
        const isLongTag = tag.length > 20;
        const tagElem = (
          <Tag
            key={tag}
            closable
            style={{ userSelect: 'none' }}
            onClose={() => handleClose(tag)}
          >
            <span
              onDoubleClick={(e) => {
                setEditInputIndex(index);
                setEditInputValue(tag);
                e.preventDefault();
              }}
            >
              {isLongTag ? `${tag.slice(0, 20)}...` : tag}
            </span>
          </Tag>
        );
        return isLongTag ? (
          <Tooltip title={tag} key={tag}>
            {tagElem}
          </Tooltip>
        ) : (
          tagElem
        );
      })}
      {inputVisible ? (
        <Input
          ref={inputRef}
          type="text"
          size="small"
          style={tagInputStyle}
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleInputConfirm}
          onPressEnter={handleInputConfirm}
        />
      ) : (
        <Tag style={tagPlusStyle} icon={<PlusOutlined />} onClick={showInput}>
        </Tag>
      )}
    </Flex>
  );
};



/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAdd = async (fields: WebShell) => {
  const hide = message.loading('正在添加');
  try {
    console.log('正在创建WebShell，数据:', fields);
    const result = await createWebShell(fields);
    console.log('创建成功，结果:', result);
    hide();
    message.success('添加成功');
    return true;
  } catch (error) {
    console.error('创建WebShell失败:', error);
    hide();
    message.error(`添加失败: ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
};

/**
 * @en-US Update node
 * @zh-CN 更新节点
 *
 * @param fields
 */
const handleUpdate = async (fields: FormValueType) => {
  const hide = message.loading('配置中');
  try {
    if (!fields.id) {
      throw new Error('缺少WebShell ID');
    }
    
    console.log('开始更新WebShell:', { id: fields.id, fields });
    
    const updateData = {
      name: fields.name,
      scriptType: fields.scriptType,
      webshellType: fields.webshellType,
      url: fields.url,
      pass: fields.pass,
      key: fields.key,
      crypto: fields.crypto,
      encoding: fields.encoding,
      tag: fields.tag,
      notes: fields.notes,
      userAgent: fields.userAgent,
      proxyAddress: fields.proxyAddress,
      status: fields.status,
    };
    
    console.log('更新数据:', updateData);
    console.log('调用updateWebShell API...');
    
    const result = await updateWebShell(fields.id, updateData);
    
    console.log('API调用成功，返回结果:', result);
    
    hide();
    message.success('配置成功');
    return true;
  } catch (error) {
    console.error('更新WebShell失败:', error);
    console.error('错误详情:', {
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      name: error instanceof Error ? error.name : undefined
    });
    
    hide();
    message.error(`配置失败: ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
};

/**
 *  Delete node
 * @zh-CN 删除节点
 *
 * @param selectedRows
 */
const handleRemove = async (selectedRows: WebShell[]) => {
  const hide = message.loading('正在删除');
  if (!selectedRows) return true;
  try {
    await Promise.all(selectedRows.map(row => deleteWebShell(row.id!)));
    hide();
    message.success('删除成功，即将刷新');
    return true;
  } catch (error) {
    hide();
    message.error('删除失败，请重试');
    return false;
  }
};

/**
 * 测试连接
 * @zh-CN 测试WebShell连接
 */
const handleTestConnection = async (id: number) => {
  const hide = message.loading('正在测试连接');
  try {
    const result = await testConnection(id);
    hide();
    if (result.status === '连接成功') {
      message.success('连接测试成功');
    } else {
      message.warning(`连接测试: ${result.message}`);
    }
    return true;
  } catch (error) {
    hide();
    message.error('连接测试失败，请重试');
    return false;
  }
};

/**
 * 获取基础信息
 * @zh-CN 获取WebShell基础信息
 */
const handleGetBasicInfo = async (id: number) => {
  const hide = message.loading('正在获取基础信息');
  try {
    const result = await getBasicInfo(id);
    hide();
    if (result.status === '获取信息成功') {
      message.success('基础信息获取成功');
      // 显示基础信息详情
      Modal.info({
        title: 'WebShell基础信息',
        width: 800,
        content: (
          <div>
            <p><strong>系统信息:</strong></p>
            <pre>{JSON.stringify(result, null, 2)}</pre>
            <p><strong>当前目录:</strong></p>
            <pre>{JSON.stringify(result.currentDirectory, null, 2)}</pre>
            <p><strong>文件系统信息:</strong></p>
            <pre>{JSON.stringify(result.fileSystemInfo, null, 2)}</pre>
          </div>
        ),
      });
    } else {
      message.warning(`获取基础信息: ${result.message}`);
    }
    return true;
  } catch (error) {
    hide();
    message.error('获取基础信息失败，请重试');
    return false;
  }
};

/**
 * 测试目录读取
 * @zh-CN 测试WebShell目录读取功能
 */
const handleTestDirectoryRead = async (id: number) => {
  const hide = message.loading('正在测试目录读取');
  try {
    const result = await getFileList(id, '/');
    hide();
    message.success(`目录读取测试成功，共 ${result.count} 个文件/目录`);
    
    // 显示目录读取结果详情
    Modal.info({
      title: '目录读取测试结果',
      width: 800,
      content: (
        <div>
          <p><strong>当前路径:</strong> {result.path}</p>
          <p><strong>文件/目录总数:</strong> {result.count}</p>
          <p><strong>详细信息:</strong></p>
          <pre style={{ 
            maxHeight: '400px', 
            overflow: 'auto',
            background: '#f5f5f5',
            padding: '12px',
            borderRadius: '4px'
          }}>
            {JSON.stringify(result.fileList, null, 2)}
          </pre>
        </div>
      ),
    });
    
    console.log('目录读取测试结果:', result);
    return true;
  } catch (error) {
    hide();
    message.error(`目录读取测试失败: ${error instanceof Error ? error.message : String(error)}`);
    console.error('目录读取测试失败:', error);
    return false;
  }
};

const WebShellList: React.FC = () => {
  /**
   * @en-US Pop-up window of new window
   * @zh-CN 新建窗口的弹窗
   *  */
  const [createModalOpen, handleModalOpen] = useState<boolean>(false);
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   *  */
  const [updateModalOpen, handleUpdateModalOpen] = useState<boolean>(false);
  const [showDetail, setShowDetail] = useState<boolean>(false);
  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<WebShell>();
  const [selectedRowsState, setSelectedRows] = useState<WebShell[]>([]);
  const [commandInput, setCommandInput] = useState<string>('');
  const [commandHistory, setCommandHistory] = useState<any[]>([]);
  const [executeModalOpen, setExecuteModalOpen] = useState<boolean>(false);
  const [executingCommand, setExecutingCommand] = useState<boolean>(false);
  const [commandResult, setCommandResult] = useState<any>(null);
  
  // 自动刷新相关状态
  const [autoRefresh, setAutoRefresh] = useState<boolean>(false);
  const [refreshInterval, setRefreshInterval] = useState<number>(30); // 默认30秒
  const [refreshTimer, setRefreshTimer] = useState<NodeJS.Timeout | null>(null);

  // 自动刷新逻辑
  useEffect(() => {
    if (autoRefresh && actionRef.current) {
      const timer = setInterval(() => {
        actionRef.current?.reload();
      }, refreshInterval * 1000);
      setRefreshTimer(timer);
      
      return () => {
        clearInterval(timer);
        setRefreshTimer(null);
      };
    } else if (refreshTimer) {
      clearInterval(refreshTimer);
      setRefreshTimer(null);
    }
  }, [autoRefresh, refreshInterval]);

  // 组件卸载时清理定时器
  useEffect(() => {
    return () => {
      if (refreshTimer) {
        clearInterval(refreshTimer);
      }
    };
  }, [refreshTimer]);

  /**
   * 处理标签删除
   */
  const handleRemoveTag = async (record: WebShell, tagToRemove: string) => {
    try {
      // 获取当前标签数组
      let tags = record.tag || '';
      let tagArray: string[] = [];
      
      if (typeof tags === 'string') {
        tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
      } else if (Array.isArray(tags)) {
        tagArray = tags;
      }
      
      // 删除指定的标签（通过值而不是索引）
      const newTagArray = tagArray.filter(tag => tag !== tagToRemove);
      
      // 更新WebShell
      const updateData: Partial<WebShell> = {
        tag: newTagArray.join(','),
      };
      
      if (record.id) {
        await updateWebShell(record.id, updateData);
        message.success('标签删除成功');
        
        // 刷新表格数据
        if (actionRef.current) {
          actionRef.current.reload();
        }
      }
    } catch (error) {
      console.error('删除标签失败:', error);
      message.error(`删除标签失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  /**
   * 处理标签添加
   */
  const handleAddTag = (record: WebShell) => {
    // 使用Input组件让用户输入新标签
    const newTag = window.prompt('请输入新标签:');
    if (newTag && newTag.trim()) {
      handleAddTagConfirm(record, newTag.trim());
    }
  };

  /**
   * 确认添加标签
   */
  const handleAddTagConfirm = async (record: WebShell, newTag: string) => {
    try {
      // 获取当前标签数组
      let tags = record.tag || '';
      let tagArray: string[] = [];
      
      if (typeof tags === 'string') {
        tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
      } else if (Array.isArray(tags)) {
        tagArray = tags;
      }
      
      // 检查标签是否已存在
      if (tagArray.includes(newTag)) {
        message.warning('标签已存在');
        return;
      }
      
      // 添加新标签
      tagArray.push(newTag);
      
      // 更新WebShell
      const updateData: Partial<WebShell> = {
        tag: tagArray.join(','),
      };
      
      if (record.id) {
        await updateWebShell(record.id, updateData);
        message.success('标签添加成功');
        
        // 刷新表格数据
        if (actionRef.current) {
          actionRef.current.reload();
        }
      }
    } catch (error) {
      console.error('添加标签失败:', error);
      message.error(`添加标签失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  /**
   * 编辑标签
   */
  const handleEditTag = async (record: WebShell, oldTag: string, newTag: string) => {
    try {
      // 获取当前标签数组
      let tags = record.tag || '';
      let tagArray: string[] = [];
      
      if (typeof tags === 'string') {
        tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
      } else if (Array.isArray(tags)) {
        tagArray = tags;
      }
      
      // 检查标签是否已存在（排除当前编辑的标签）
      if (tagArray.includes(newTag) && oldTag !== newTag) {
        message.warning('标签已存在');
        return;
      }
      
      // 更新标签
      const tagIndex = tagArray.indexOf(oldTag);
      if (tagIndex !== -1) {
        tagArray[tagIndex] = newTag;
      }
      
      // 更新WebShell
      const updateData: Partial<WebShell> = {
        tag: tagArray.join(','),
      };
      
      if (record.id) {
        await updateWebShell(record.id, updateData);
        message.success('标签编辑成功');
        
        // 刷新表格数据
        if (actionRef.current) {
          actionRef.current.reload();
        }
      }
    } catch (error) {
      console.error('编辑标签失败:', error);
      message.error(`编辑标签失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  /**
   * 处理可编辑单元格的保存
   */
  const handleSave = async (record: WebShell, dataIndex: string, value: string) => {
    try {
      console.log('保存数据:', { record, dataIndex, value });
      
      // 构建更新数据
      const updateData: Partial<WebShell> = {
        [dataIndex]: value,
      };
      
      // 调用API更新数据
      if (record.id) {
        const result = await updateWebShell(record.id, updateData);
        console.log('更新成功:', result);
        message.success('保存成功');
        
        // 刷新表格数据
        if (actionRef.current) {
          actionRef.current.reload();
        }
      }
      
      return Promise.resolve();
    } catch (error) {
      console.error('保存失败:', error);
      message.error(`保存失败: ${error instanceof Error ? error.message : String(error)}`);
      return Promise.reject(error);
    }
  };

  /**
   * 执行命令
   * @zh-CN 执行WebShell命令
   */
  const handleExecuteCommand = async (command: string) => {
    if (!currentRow) {
      message.error('请先选择WebShell');
      return;
    }

    setExecutingCommand(true);
    try {
      // 使用独立的命令执行服务
      const result = await commandExecutor.executeCommand(currentRow, command);
      setCommandResult(result);
      
      // 添加到命令历史
      setCommandHistory(prev => [...prev, {
        id: Date.now(),
        command,
        result: result.output || result.error || '无输出',
        timestamp: new Date().toISOString(),
        webshellId: currentRow.id
      }]);
      
      return result;
    } catch (error) {
      message.error('命令执行失败，请重试');
      setCommandResult({ error: error instanceof Error ? error.message : String(error) });
      return null;
    } finally {
      setExecutingCommand(false);
    }
  };

  const columns: ProColumns<WebShell>[] = [
    {
      title: 'id',
      dataIndex: 'id',
      sorter: true,
      width: 50,
      render: (dom, entity) => {
        return (
          <a
            onClick={() => {
              setCurrentRow(entity);
              setShowDetail(true);
            }}
          >
            {dom || entity.id}
          </a>
        );
      },
    },
    {
      title: '备注',
      dataIndex: 'notes',
      valueType: 'text',
      editable: (record) => record.id !== '1',
      tip: '点击编辑备注',
      width: 120,
      render: (dom, entity) => (
        <EditableCell
          value={String(dom || '')}
          record={entity}
          dataIndex="notes"
          title="备注"
          onSave={handleSave}
        >
          {dom || '-'}
        </EditableCell>
      ),
    },
    {
      title: '标签',
      dataIndex: 'tag',
      valueType: 'text',
      width: 200,
      render: (dom, entity) => {
        const tags = entity.tag || dom;
        if (!tags) return '-';
        
        // 将字符串转换为数组
        let tagArray: string[] = [];
        if (typeof tags === 'string') {
          tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
        } else if (Array.isArray(tags)) {
          tagArray = tags;
        }
        
        if (tagArray.length === 0) return '-';
        
        return (
          <Flex gap="4px 0" wrap>
            {tagArray.map((tag, index) => {
              const isLongTag = tag.length > 20;
              const tagElem = (
                <Tag
                  key={index}
                  closable
                  style={{ userSelect: 'none' }}
                  onClose={() => handleRemoveTag(entity, tag)}
                >
                  <span
                    onDoubleClick={(e) => {
                      // 双击编辑标签功能
                      const newTag = window.prompt('编辑标签:', tag);
                      if (newTag && newTag.trim() && newTag !== tag) {
                        handleEditTag(entity, tag, newTag.trim());
                      }
                      e.preventDefault();
                    }}
                  >
                    {isLongTag ? `${tag.slice(0, 20)}...` : tag}
                  </span>
                </Tag>
              );
              return isLongTag ? (
                <Tooltip title={tag} key={index}>
                  {tagElem}
                </Tooltip>
              ) : (
                tagElem
              );
            })}
            <Tag
              style={{ 
                background: '#fafafa', 
                borderStyle: 'dashed', 
                cursor: 'pointer' 
              }}
              icon={<PlusOutlined />}
              onClick={() => handleAddTag(entity)}
            >
            </Tag>
          </Flex>
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueType: 'select',
      width: 80,
      valueEnum: {
        'Disabled': { text: '未启用', status: 'Default' },
        'Enabled': { text: '已启用', status: 'Processing' },
        'Connected': { text: '已连接', status: 'Success' },
        'Disconnected': { text: '已断开', status: 'Error' },
      },
      render: (dom, entity) => {
        const status = entity.status || dom;
        return <StatusTag status={String(status)} />;
      },
    },
    {
      title: '类型',
      dataIndex: 'scriptType',
      valueType: 'select',
      width: 60,
      valueEnum: {
        'PHP': 'PHP',
        'ASP': 'ASP',
        'ASPX': 'ASPX',
        'JSP': 'JSP',
        'JSPX': 'JSPX',
        'Other': '其他',
      },
      render: (dom, entity) => {
        return (
          <div style={{ cursor: 'pointer' }} title="点击编辑类型">
            {dom || 'PHP'}
          </div>
        );
      },
    },
    {
      title: 'URL',
      dataIndex: 'url',
      valueType: 'text',
      sorter: true,
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (dom, entity) => {
        const url = entity.url || dom;
        if (!url) return '-';
        return (
          <Tooltip placement="topLeft" title={url}>
            {url}
          </Tooltip>
        );
      },
    },
    {
      title: '外网IP',
      dataIndex: 'externalIP',
      valueType: 'text',
      sorter: true,
      width: 150,
      render: (dom, entity) => {
        const ip = String(entity.externalIP || dom);
        if (!ip || ip === 'undefined') return '-';
        
        // 使用后端WebShell.Location字段作为归属地信息
        const getLocation = (ip: string, location?: string) => {
          // 如果有后端提供的Location信息，优先使用
          if (location && location.trim() !== '') {
            return location;
          }
          
          // 如果没有Location信息，则根据IP地址判断内网/外网
          if (ip.startsWith('192.168.') || ip.startsWith('10.0.') || ip.startsWith('172.')) {
            return '内网';
          }
          
          // 外网IP但没有Location信息时，显示"外网IP"
          return '外网';
        };
        
        return (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>{ip}</span>
            <span style={{ fontSize: '12px', color: '#666' }}>
              {getLocation(ip, entity.location)}
            </span>
          </div>
        );
      },
    },
    {
      title: '内网IP',
      dataIndex: 'internalIP',
      valueType: 'text',
      sorter: true,
      width: 120,
    },
    {
      title: '主机名',
      dataIndex: 'hostname',
      valueType: 'text',
      sorter: true,
      width: 120,
    },
    {
      title: '用户名',
      dataIndex: 'username',
      valueType: 'text',
      sorter: true,
      width: 100,
    },
    {
      title: '加密方式',
      dataIndex: 'crypto',
      valueType: 'select',
      width: 140,
      valueEnum: {
        'JAVA_AES_BASE64': 'JAVA_AES_BASE64',
        'JAVA_AES_RAW': 'JAVA_AES_RAW',
        'CSHARP_AES_BASE64': 'CSHARP_AES_BASE64',
        'CSHARP_AES_RAW': 'CSHARP_AES_RAW',
        'PHP_XOR_BASE64': 'PHP_XOR_BASE64',
        'PHP_XOR_RAW': 'PHP_XOR_RAW',
        'ASP_XOR_BASE64': 'ASP_XOR_BASE64',
        'ASP_XOR_RAW': 'ASP_XOR_RAW',
        'DES': 'DES',
        'RSA': 'RSA',
        'BASE64': 'BASE64',
        'NONE': 'NONE',
      },
    },
    {
      title: '编码方式',
      dataIndex: 'encoding',
      valueType: 'select',
      width: 100,
      valueEnum: {
        'utf8': 'UTF-8',
        'gbk': 'GBK',
        'gb2312': 'GB2312',
        'BIG5': 'BIG5',
        'GB18030': 'GB18030',
        'ISO_8859_1': 'ISO-8859-1',
        'latin1': 'Latin1',
        'utf16': 'UTF-16',
        'ascii': 'ASCII',
        'cp850': 'CP850',
      },
    },

    {
      title: '首次连接时间',
      dataIndex: 'firstConnectTime',
      valueType: 'dateTime',
      sorter: true,
      width: 150,
    },
    {
      title: '最后连接时间',
      dataIndex: 'lastConnectTime',
      valueType: 'dateTime',
      sorter: true,
      width: 150,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      fixed: 'right',
      width: 350,
      render: (_, record) => [
        <a
          key="connect"
          onClick={() => {
            handleTestConnection(record.id!);
          }}
        >
          测试
        </a>,
        <a
          key="basicInfo"
          onClick={() => {
            handleGetBasicInfo(record.id!);
          }}
        >
          基础信息
        </a>,
        <a
          key="directoryRead"
          onClick={() => {
            handleTestDirectoryRead(record.id!);
          }}
        >
          目录读取
        </a>,
        <a
          key="execute"
          onClick={() => {
            setCurrentRow(record);
            setExecuteModalOpen(true);
          }}
        >
          执行
        </a>,
        <a
          key="config"
          onClick={() => {
            setCurrentRow(record);
            handleUpdateModalOpen(true);
          }}
        >
          配置
        </a>,
        <a
          key="delete"
          onClick={async () => {
            Modal.confirm({
              title: '确认删除',
              content: `确定要删除WebShell "${record.name}" 吗？此操作不可撤销。`,
              okText: '确认删除',
              okType: 'danger',
              cancelText: '取消',
              onOk: async () => {
                const success = await handleRemove([record]);
                if (success && actionRef.current) {
                  actionRef.current.reload();
                }
              },
            });
          }}
        >
          删除
        </a>,
      ],
    },
  ];

  return (
    <div style={{ 
      height: '100%', 
      display: 'flex', 
      flexDirection: 'column'
    }}>
      <ProTable<WebShell, API.PageParams>
        actionRef={actionRef}
        rowKey="id"
        defaultSize="small"
        search={false}
        style={{
          margin: 0, // 移除表格默认margin
          padding: 0, // 移除表格默认padding
          height: '100%', // 充满容器高度
          flex: 1 // 占据剩余空间
        }}
        toolBarRender={() => [
          <Button
            key="test"
            onClick={async () => {
              try {
                const result = await getWebShellList();
                message.success(`API连接成功，获取到 ${result.length} 个WebShell`);
                console.log('API测试结果:', result);
              } catch (error) {
                message.error(`API连接失败: ${error instanceof Error ? error.message : String(error)}`);
                console.error('API测试失败:', error);
              }
            }}
          >
            测试API
          </Button>,
          <Button
            key="auto-refresh"
            type={autoRefresh ? "primary" : "default"}
            icon={autoRefresh ? <PauseOutlined /> : <ReloadOutlined />}
            onClick={() => {
              setAutoRefresh(!autoRefresh);
              message.info(autoRefresh ? '自动刷新已关闭' : `自动刷新已开启，每${refreshInterval}秒刷新一次`);
            }}
          >
            {autoRefresh ? '停止自动刷新' : '开启自动刷新'}
          </Button>,
          <Select
            key="refresh-interval"
            value={refreshInterval}
            onChange={(value) => setRefreshInterval(value)}
            style={{ width: 100 }}
            disabled={autoRefresh}
            options={[
              { label: '10秒', value: 10 },
              { label: '30秒', value: 30 },
              { label: '60秒', value: 60 },
              { label: '120秒', value: 120 },
            ]}
          />,
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              handleModalOpen(true);
            }}
          ><PlusOutlined /> 添加 WebShell
          </Button>,
        ]}
        request={async (params, sort, filter) => {
          try {
            const data = await getWebShellList();
            return {
              data: data,
              success: true,
              total: data.length,
            };
          } catch (error) {
            console.error('获取WebShell列表失败:', error);
            return {
              data: [],
              success: false,
              total: 0,
            };
          }
        }}
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
        options={{
          // reload: true,
          // density: true,
          setting: true,
        }}
        scroll={{ x: 1800 }}
      />
      {selectedRowsState?.length > 0 && (
        <FooterToolbar
          extra={
            <div>
              已选择{' '}
              <a
                style={{
                  fontWeight: 600,
                }}
              >
                {selectedRowsState.length}
              </a>{' '}
              项
            </div>
          }
        >
          <Button
            onClick={() => {
              Modal.confirm({
                title: '确认批量删除',
                content: `确定要删除选中的 ${selectedRowsState.length} 个WebShell吗？此操作不可撤销。`,
                okText: '确认删除',
                okType: 'danger',
                cancelText: '取消',
                onOk: async () => {
                  const success = await handleRemove(selectedRowsState);
                  if (success) {
                    setSelectedRows([]);
                    actionRef.current?.reloadAndRest?.();
                  }
                },
              });
            }}
          >
            批量删除
          </Button>
          <Button type="primary">批量启用</Button>
        </FooterToolbar>
      )}
      <ModalForm
        title={'添加 WebShell'}
        width="800px"
        open={createModalOpen}
        onOpenChange={handleModalOpen}
        layout="horizontal"
        modalProps={{
          destroyOnClose: true,
        }}
        onFinish={async (value) => {
          const success = await handleAdd(value as WebShell);
          if (success) {
            handleModalOpen(false);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        {/* 基础配置 */}
        <Divider orientation="left" orientationMargin={50}>
          基础配置
        </Divider>
        
        <ProFormText
          rules={[
            {
              required: true,
              message: '请输入WebShell名称',
            },
          ]}
          width="lg"
          name="name"
          label="名称"
          placeholder="请输入WebShell名称"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormText
          rules={[
            {
              required: true,
              message: 'URL为必填项',
            },
          ]}
          width="lg"
          name="url"
          label="URL"
          placeholder="请输入目标URL"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormSelect
          rules={[
            {
              required: true,
              message: '请选择脚本类型',
            },
          ]}
          width="lg"
          name="scriptType"
          label="脚本类型"
          placeholder="请选择脚本类型"
          options={[
            { label: 'PHP', value: 'PHP' },
            { label: 'ASP', value: 'ASP' },
            { label: 'ASPX', value: 'ASPX' },
            { label: 'JSP', value: 'JSP' },
            { label: 'JSPX', value: 'JSPX' },
            { label: '其他', value: 'Other' },
          ]}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormSelect
          rules={[
            {
              required: true,
              message: '请选择WebShell类型',
            },
          ]}
          width="lg"
          name="webshellType"
          label="WebShell类型"
          placeholder="请选择WebShell类型"
          options={[
            { label: 'Behinder', value: 'Behinder' },
            { label: 'Godzilla', value: 'Godzilla' },
            { label: 'Antword', value: 'Antword' },
            { label: 'Custom', value: 'Custom' },
            { label: 'Other', value: 'Other' },
          ]}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormText.Password
          rules={[
            {
              required: true,
              message: '请输入密码',
            },
          ]}        
          width="lg"
          name="pass"
          label="密码"
          placeholder="请输入密码"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormText
          width="lg"
          name="key"
          label="密钥"
          placeholder="请输入密钥"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormSelect
          width="lg"
          name="crypto"
          label="加密方式"
          placeholder="请选择加密方式"
          options={[
            { label: 'JAVA_AES_BASE64', value: 'JAVA_AES_BASE64' },
            { label: 'JAVA_AES_RAW', value: 'JAVA_AES_RAW' },
            { label: 'CSHARP_AES_BASE64', value: 'CSHARP_AES_BASE64' },
            { label: 'CSHARP_AES_RAW', value: 'CSHARP_AES_RAW' },
            { label: 'PHP_XOR_BASE64', value: 'PHP_XOR_BASE64' },
            { label: 'PHP_XOR_RAW', value: 'PHP_XOR_RAW' },
            { label: 'ASP_XOR_BASE64', value: 'ASP_XOR_BASE64' },
            { label: 'ASP_XOR_RAW', value: 'ASP_XOR_RAW' },
            { label: 'DES', value: 'DES' },
            { label: 'RSA', value: 'RSA' },
            { label: 'BASE64', value: 'BASE64' },
            { label: 'NONE', value: 'NONE' },
          ]}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormSelect
          width="lg"
          name="encoding"
          label="编码方式"
          placeholder="请选择编码方式"
          options={[
            { label: 'UTF-8', value: 'utf8' },
            { label: 'GBK', value: 'gbk' },
            { label: 'GB2312', value: 'gb2312' },
            { label: 'BIG5', value: 'BIG5' },
            { label: 'GB18030', value: 'GB18030' },
            { label: 'ISO-8859-1', value: 'ISO_8859_1' },
            { label: 'Latin1', value: 'latin1' },
            { label: 'UTF-16', value: 'utf16' },
            { label: 'ASCII', value: 'ascii' },
            { label: 'CP850', value: 'cp850' },
          ]}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProForm.Item
          label="标签"
          name="tag"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        >
          <TagInput />
        </ProForm.Item>

        <ProFormTextArea
          width="lg"
          name="notes"
          label="备注"
          placeholder="请输入备注信息"
          fieldProps={{
            rows: 3,
          }}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        {/* 高级配置 */}
        <Divider orientation="left" orientationMargin={50}>
          高级配置
        </Divider>

        <ProFormText
          width="lg"
          name="userAgent"
          label="User-Agent"
          placeholder="请输入User-Agent配置"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        <ProFormText
          width="lg"
          name="proxyAddress"
          label="代理"
          placeholder="请输入代理地址，例如 http://127.0.0.1:8080"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />

        {/* 操作按钮 */}
        <ProFormGroup style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
          <Button
            type="default"
            onClick={() => {
              message.info('测试连接功能待实现');
            }}
          >
            测试连接
          </Button>
          <div>
            <Button
              type="primary"
              htmlType="submit"
              style={{ marginRight: 16 }}
            >
              保存
            </Button>
            <Button
              type="default"
              onClick={() => {
                handleModalOpen(false);
              }}
            >
              取消
            </Button>
          </div>
        </ProFormGroup>
      </ModalForm>
      
      <UpdateForm
        onSubmit={async (value) => {
          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalOpen(false);
            setCurrentRow(undefined);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        onCancel={() => {
          handleUpdateModalOpen(false);
          if (!showDetail) {
            setCurrentRow(undefined);
          }
        }}
        updateModalOpen={updateModalOpen}
        values={currentRow || {}}
      />

      {/* 命令执行模态框 */}
      <ModalForm
        title={`执行命令 - ${currentRow?.name || 'WebShell'}`}
        width="800px"
        open={executeModalOpen}
        onOpenChange={(open) => {
          setExecuteModalOpen(open);
          if (!open) {
            // 不重置 currentRow，保持详情面板的数据
            setCommandResult(null);
          }
        }}
        layout="horizontal"
        onFinish={async (values) => {
          await handleExecuteCommand(values.command);
          return false; // 返回false阻止模态框自动关闭
        }}
        modalProps={{
          destroyOnClose: true,
        }}
      >
        <ProFormText
          rules={[
            {
              required: true,
              message: '请输入要执行的命令',
            },
          ]}
          width="lg"
          name="command"
          label="命令"
          placeholder="请输入要执行的命令，如: whoami, ls, pwd等"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 20 }}
        />
        
        {/* 提示信息 */}
        {/* <div style={{ 
          marginTop: 8, 
          padding: '8px 12px', 
          background: '#f6ffed', 
          border: '1px solid #b7eb8f', 
          borderRadius: 4,
          fontSize: '12px',
          color: '#52c41a'
        }}>
          💡 执行命令后，您可以查看执行结果和命令历史。完成后请点击"关闭"按钮关闭窗口。
        </div> */}

        {/* 命令执行结果 */}
        {commandResult && (
          <div style={{ marginTop: 16 }}>
            <Divider orientation="left">执行结果</Divider>
            <div style={{ 
              background: '#f5f5f5', 
              padding: 16, 
              borderRadius: 6,
              fontFamily: 'monospace',
              fontSize: '12px',
              maxHeight: '300px',
              overflow: 'auto'
            }}>
              {commandResult.error ? (
                <div style={{ color: '#ff4d4f' }}>
                  错误: {commandResult.error}
                </div>
              ) : (
                <div>
                  {commandResult.output ? (
                    <div>
                      <pre style={{ 
                        background: '#fff', 
                        padding: 8, 
                        borderRadius: 4,
                        margin: 0,
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-all',
                        fontSize: '13px',
                        lineHeight: '1.5'
                      }}>
                        {(() => {
                          let content = '';
                          if (typeof commandResult.output === 'string') {
                            // 转义常见字符
                            content = commandResult.output
                              .replace(/\\r\\n/g, '\n')  // \r\n -> 换行
                              .replace(/\\n/g, '\n')     // \n -> 换行
                              .replace(/\\r/g, '\n')     // \r -> 换行
                              .replace(/\\t/g, '\t')     // \t -> 制表符
                              .replace(/\\\\/g, '\\')    // \\ -> \
                              .replace(/\\"/g, '"')      // \" -> "
                              .replace(/\\'/g, "'");     // \' -> '
                          } else {
                            content = JSON.stringify(commandResult.output, null, 2);
                          }
                          return content;
                        })()}
                      </pre>
                    </div>
                  ) : (
                    <div style={{ color: '#666', fontStyle: 'italic' }}>
                      无输出内容
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 命令历史 */}
        {commandHistory.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <Divider orientation="left">命令历史</Divider>
            <div style={{ maxHeight: '200px', overflow: 'auto' }}>
              {commandHistory
                .filter(h => h.webshellId === currentRow?.id)
                .slice(-5)
                .reverse()
                .map((history) => (
                  <div key={history.id} style={{ 
                    border: '1px solid #d9d9d9', 
                    borderRadius: 4, 
                    padding: 8, 
                    marginBottom: 8,
                    background: '#fafafa'
                  }}>
                    <div style={{ fontWeight: 'bold', marginBottom: 4 }}>
                      {history.command}
                    </div>
                    <div style={{ fontSize: '12px', color: '#666', marginBottom: 4 }}>
                      {new Date(history.timestamp).toLocaleString()}
                    </div>
                    <div style={{ 
                      fontFamily: 'monospace', 
                      fontSize: '11px',
                      background: '#fff',
                      padding: 4,
                      borderRadius: 2,
                      maxHeight: '100px',
                      overflow: 'auto'
                    }}>
                      {(() => {
                        let content = '';
                        if (typeof history.result === 'string') {
                          // 转义常见字符
                          content = history.result
                            .replace(/\\r\\n/g, '\n')  // \r\n -> 换行
                            .replace(/\\n/g, '\n')     // \n -> 换行
                            .replace(/\\r/g, '\n')     // \r -> 换行
                            .replace(/\\t/g, '\t')     // \t -> 制表符
                            .replace(/\\\\/g, '\\')    // \\ -> \
                            .replace(/\\"/g, '"')      // \" -> "
                            .replace(/\\'/g, "'");     // \' -> '
                        } else {
                          content = JSON.stringify(history.result, null, 2);
                        }
                        return content;
                      })()}
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* 操作按钮 */}
        <ProFormGroup style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
          <Button
            type="default"
            onClick={() => {
              setCommandInput('');
              setCommandResult(null);
            }}
          >
            清空
          </Button>
          <div>
            <Button
              type="primary"
              htmlType="submit"
              loading={executingCommand}
              style={{ marginRight: 16 }}
            >
              {executingCommand ? '执行中...' : '执行命令'}
            </Button>
            <Button
              type="default"
              onClick={() => {
                setExecuteModalOpen(false);
                setCommandResult(null);
                // 不重置 currentRow，保持详情面板的数据
              }}
            >
              关闭
            </Button>
          </div>
        </ProFormGroup>
      </ModalForm>

      <Drawer
        width={600}
        open={showDetail}
        onClose={() => {
          setCurrentRow(undefined);
          setShowDetail(false);
        }}
        closable={false}
      >
        {currentRow?.name && (
          <ProDescriptions<WebShell>
            column={2}
            title={currentRow?.name}
            request={async () => ({
              data: currentRow || {},
            })}
            params={{
              id: currentRow?.name,
            }}
            columns={columns as ProDescriptionsItemProps<WebShell>[]}
          />
        )}
      </Drawer>
    </div>
  );
};

export default WebShellList;
