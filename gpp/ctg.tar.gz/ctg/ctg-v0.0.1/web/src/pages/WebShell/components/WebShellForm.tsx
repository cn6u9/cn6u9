import React from 'react';
import {
  ModalForm,
  ProFormText,
  ProFormSelect,
  ProFormTextArea,
  ProFormGroup,
} from '@ant-design/pro-components';
import type { WebShell } from '@/services/webshell';

export type WebShellFormProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFinish: (values: Partial<WebShell>) => Promise<boolean>;
  initialValues?: Partial<WebShell>;
  title: string;
};

const WebShellForm: React.FC<WebShellFormProps> = ({
  open,
  onOpenChange,
  onFinish,
  initialValues,
  title,
}) => {
  return (
    <ModalForm
      title={title}
      width="800px"
      open={open}
      onOpenChange={onOpenChange}
      layout="horizontal"
      onFinish={onFinish}
      initialValues={initialValues}
    >
      {/* 基础配置 */}
      <ProFormGroup>
        <ProFormText
          rules={[
            {
              required: true,
              message: '请输入WebShell名称',
            },
          ]}
          width="md"
          name="name"
          label="名称"
          placeholder="请输入WebShell名称"
        />
        
        <ProFormSelect
          rules={[
            {
              required: true,
              message: '请选择WebShell类型',
            },
          ]}
          width="md"
          name="webshellType"
          label="WebShell类型"
          placeholder="请选择WebShell类型"
          options={[
            { label: 'Godzilla', value: 'Godzilla' },
            { label: 'Behinder', value: 'Behinder' },
            { label: 'Antword', value: 'Antword' },
            { label: 'Custom', value: 'Custom' },
            { label: 'Other', value: 'Other' },
          ]}
        />
      </ProFormGroup>

      <ProFormGroup>
        <ProFormSelect
          rules={[
            {
              required: true,
              message: '请选择脚本类型',
            },
          ]}
          width="md"
          name="scriptType"
          label="脚本类型"
          placeholder="请选择脚本类型"
          options={[
            { label: 'JSP', value: 'JSP' },
            { label: 'JSPX', value: 'JSPX' },
            { label: 'PHP', value: 'PHP' },
            { label: 'ASP', value: 'ASP' },
            { label: 'ASPX', value: 'ASPX' },
            { label: 'Other', value: 'Other' },
          ]}
        />
        
        <ProFormText
          rules={[
            {
              required: true,
              message: '请输入目标URL',
            },
          ]}
          width="md"
          name="url"
          label="目标URL"
          placeholder="请输入目标URL"
        />
      </ProFormGroup>

      <ProFormGroup>
        <ProFormText
          rules={[
            {
              required: true,
              message: '请输入密码',
            },
          ]}
          width="md"
          name="pass"
          label="密码"
          placeholder="请输入密码"
        />
        
        <ProFormText
          width="md"
          name="key"
          label="密钥"
          placeholder="请输入加密密钥"
        />
      </ProFormGroup>

      <ProFormGroup>
        <ProFormSelect
          width="md"
          name="crypto"
          label="加密方式"
          placeholder="请选择加密方式"
          options={[
            { label: 'JAVA_AES_BASE64', value: 'JAVA_AES_BASE64' },
            { label: 'JAVA_AES_RAW', value: 'JAVA_AES_RAW' },
            { label: 'CSHARP_AES_BASE64', value: 'CSHARP_AES_BASE64' },
            { label: 'CSHARP_AES_RAW', value: 'CSHARP_AES_RAW' },
            { label: 'PHP_XOR_BASE64', value: 'PHP_XOR_BASE64' },
            { label: 'PHP_XOR_RAW', value: 'PHP_XOR_RAW' },
            { label: 'ASP_XOR_BASE64', value: 'ASP_XOR_BASE64' },
            { label: 'ASP_XOR_RAW', value: 'ASP_XOR_RAW' },
            { label: 'NONE', value: 'NONE' },
          ]}
        />
        
        <ProFormSelect
          width="md"
          name="encoding"
          label="编码方式"
          placeholder="请选择编码方式"
          options={[
            { label: 'UTF-8', value: 'UTF-8' },
            { label: 'GBK', value: 'GBK' },
            { label: 'GB2312', value: 'GB2312' },
            { label: 'BIG5', value: 'BIG5' },
            { label: 'ASCII', value: 'ASCII' },
            { label: 'Base64', value: 'BASE64' },
            { label: 'ISO-8859-1', value: 'ISO-8859-1' },
            { label: 'Latin1', value: 'latin1' },
            { label: 'UTF-16', value: 'UTF16' },
            { label: 'CP850', value: 'cp850' },
          ]}
        />
      </ProFormGroup>

      <ProFormGroup>
        <ProFormText
          width="md"
          name="group"
          label="分组"
          placeholder="请输入分组"
        />
        
        <ProFormText
          width="md"
          name="tag"
          label="标签"
          placeholder="请输入标签，多个标签用逗号分隔"
        />
      </ProFormGroup>

      <ProFormTextArea
        name="notes"
        label="备注"
        placeholder="请输入备注信息"
        rows={3}
      />
    </ModalForm>
  );
};

export default WebShellForm;
