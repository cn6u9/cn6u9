import React, { useEffect, useState } from 'react';
import { notification, Button, Space } from 'antd';
import { BellOutlined, CloseOutlined } from '@ant-design/icons';

interface GlobalNotificationProps {
  // 可以添加props来控制通知的显示
}

const GlobalNotification: React.FC<GlobalNotificationProps> = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // 检查是否需要显示全局通知
    const shouldShow = localStorage.getItem('showGlobalNotification') !== 'false';
    if (shouldShow) {
      setVisible(true);
    }
  }, []);

  const handleClose = () => {
    setVisible(false);
    localStorage.setItem('showGlobalNotification', 'false');
  };

  const showNotification = () => {
    notification.open({
      message: '系统通知',
      description: '这是一个全局通知组件，可以在任何页面显示。',
      icon: <BellOutlined style={{ color: '#108ee9' }} />,
      duration: 4.5,
      placement: 'topRight',
    });
  };

  if (!visible) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 20,
      right: 20,
      zIndex: 9999,
      background: '#fff',
      padding: '12px 16px',
      borderRadius: '6px',
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
      border: '1px solid #d9d9d9',
      maxWidth: '300px'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
            <BellOutlined style={{ marginRight: '8px', color: '#1890ff' }} />
            系统通知
          </div>
          <div style={{ fontSize: '12px', color: '#666' }}>
            欢迎使用WebShell管理系统
          </div>
        </div>
        <Space>
          <Button size="small" type="primary" onClick={showNotification}>
            显示通知
          </Button>
          <Button 
            size="small" 
            type="text" 
            icon={<CloseOutlined />} 
            onClick={handleClose}
          />
        </Space>
      </div>
    </div>
  );
};

export default GlobalNotification;
