import React, { useState, useEffect } from 'react';
import { Badge, Space, Typography, Tooltip } from 'antd';
import { 
  WifiOutlined, 
  DatabaseOutlined, 
  ClockCircleOutlined,
  UserOutlined,
  ExpandOutlined,
  ShrinkOutlined
} from '@ant-design/icons';

const { Text } = Typography;

interface SystemStatus {
  webshellCount: number;
  connectedCount: number;
  lastUpdate: string;
  userCount: number;
}

const GlobalStatusBar: React.FC = () => {
  const [status, setStatus] = useState<SystemStatus>({
    webshellCount: 0,
    connectedCount: 0,
    lastUpdate: new Date().toLocaleTimeString(),
    userCount: 1
  });
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    // 模拟获取系统状态
    const updateStatus = () => {
      setStatus(prev => ({
        ...prev,
        lastUpdate: new Date().toLocaleTimeString()
      }));
    };

    // 每30秒更新一次状态
    const interval = setInterval(updateStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  // 圆圈状态 - 显示连接状态
  const getCircleColor = () => {
    if (status.connectedCount > 0) return '#52c41a'; // 绿色 - 有连接
    return '#d9d9d9'; // 灰色 - 无连接
  };

  const getCircleStatus = () => {
    if (status.connectedCount > 0) return 'success';
    return 'default';
  };

  return (
    <div style={{
      position: 'fixed',
      bottom: 20,
      right: 20,
      zIndex: 1000,
      transition: 'all 0.3s ease'
    }}>
      {isExpanded ? (
        // 展开状态 - 保持之前的样式
        <div style={{
          background: 'rgba(255, 255, 255, 0.95)',
          padding: '8px 16px',
          borderRadius: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          display: 'flex',
          alignItems: 'center',
          gap: '16px'
        }}>
          <Space size="large">
            <Tooltip title="WebShell总数">
              <Space size="small">
                <DatabaseOutlined style={{ color: '#1890ff' }} />
                <Text strong>{status.webshellCount}</Text>
              </Space>
            </Tooltip>
            
            <Tooltip title="已连接数量">
              <Space size="small">
                <Badge 
                  status={status.connectedCount > 0 ? 'success' : 'default'} 
                  text={
                    <Space size="small">
                      <WifiOutlined style={{ color: status.connectedCount > 0 ? '#52c41a' : '#d9d9d9' }} />
                      <Text>{status.connectedCount}</Text>
                    </Space>
                  } 
                />
              </Space>
            </Tooltip>
            
            <Tooltip title="在线用户">
              <Space size="small">
                <UserOutlined style={{ color: '#722ed1' }} />
                <Text>{status.userCount}</Text>
              </Space>
            </Tooltip>
            
            <Tooltip title="最后更新">
              <Space size="small">
                <ClockCircleOutlined style={{ color: '#fa8c16' }} />
                <Text type="secondary" style={{ fontSize: '12px' }}>
                  {status.lastUpdate}
                </Text>
              </Space>
            </Tooltip>
          </Space>
          
          {/* 收缩按钮 */}
          <Tooltip title="收缩">
            <div
              onClick={toggleExpanded}
              style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                background: '#f5f5f5',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'background-color 0.2s ease',
                marginLeft: '8px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#e6f7ff';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#f5f5f5';
              }}
            >
              <ShrinkOutlined style={{ fontSize: '12px', color: '#666' }} />
            </div>
          </Tooltip>
        </div>
      ) : (
        // 圆圈状态 - 调整到合适的大小
        <Tooltip title="点击展开状态信息">
          <div
            onClick={toggleExpanded}
            style={{
              width: '41.6px', // 调整到合适的大小
              height: '41.6px', // 圆形，所以高度与宽度一致
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.95)',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              position: 'relative'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'scale(1.05)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1)';
              e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            }}
          >
            {/* 状态指示圆圈 */}
            <div style={{
              width: '16px',
              height: '16px',
              borderRadius: '50%',
              background: getCircleColor(),
              position: 'relative'
            }}>
              {/* 连接数量指示 */}
              {status.connectedCount > 0 && (
                <div style={{
                  position: 'absolute',
                  top: '-4px',
                  right: '-4px',
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: '#ff4d4f',
                  fontSize: '8px',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 'bold'
                }}>
                  {status.connectedCount}
                </div>
              )}
            </div>
          </div>
        </Tooltip>
      )}
    </div>
  );
};

export default GlobalStatusBar;
