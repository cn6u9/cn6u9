import React, { useState, useEffect } from 'react';
import { Tree, Table, Button, Space, Tag, Tooltip, message, Card, Select, Tabs, Modal, Breadcrumb } from 'antd';
import { 
  FolderOutlined, 
  FileOutlined, 
  DownloadOutlined, 
  UploadOutlined,
  DeleteOutlined,
  EditOutlined,
  ReloadOutlined,
  PlusOutlined,
  PlayCircleOutlined,
  HomeOutlined,
  ApiOutlined,
  FileTextOutlined,
  CodeOutlined,
  SafetyOutlined,
  KeyOutlined
} from '@ant-design/icons';
import type { WebShell, FileInfo, FileListResponse } from '@/services/webshell';
import { getFileList } from '@/services/webshell';
import './FileManagerPanel.less';

const { DirectoryTree } = Tree;
const { Option } = Select;

// 文件/文件夹信息接口
interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'directory';
  size?: number;
  modifiedTime: string;
  permissions: string;
  path: string;
  children?: FileItem[];
}

// 模拟文件系统数据
const mockFileSystem: FileItem[] = [
  {
    id: '1',
    name: 'home',
    type: 'directory',
    modifiedTime: '2024-01-15 10:30:00',
    permissions: 'drwxr-xr-x',
    path: '/home',
    children: [
      {
        id: '2',
        name: 'user',
        type: 'directory',
        modifiedTime: '2024-01-15 10:30:00',
        permissions: 'drwxr-xr-x',
        path: '/home/user',
        children: [
          {
            id: '3',
            name: 'Documents',
            type: 'directory',
            modifiedTime: '2024-01-14 15:20:00',
            permissions: 'drwxr-xr-x',
            path: '/home/user/Documents',
            children: [
              {
                id: '4',
                name: 'project1.txt',
                type: 'file',
                size: 1024,
                modifiedTime: '2024-01-14 15:20:00',
                permissions: '-rw-r--r--',
                path: '/home/user/Documents/project1.txt'
              },
              {
                id: '5',
                name: 'readme.md',
                type: 'file',
                size: 2048,
                modifiedTime: '2024-01-13 09:15:00',
                permissions: '-rw-r--r--',
                path: '/home/user/Documents/readme.md'
              }
            ]
          },
          {
            id: '6',
            name: 'Downloads',
            type: 'directory',
            modifiedTime: '2024-01-15 08:45:00',
            permissions: 'drwxr-xr-x',
            path: '/home/user/Downloads',
            children: [
              {
                id: '7',
                name: 'file1.zip',
                type: 'file',
                size: 1024000,
                modifiedTime: '2024-01-15 08:45:00',
                permissions: '-rw-r--r--',
                path: '/home/user/Downloads/file1.zip'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: '8',
    name: 'var',
    type: 'directory',
    modifiedTime: '2024-01-15 10:30:00',
    permissions: 'drwxr-xr-x',
    path: '/var',
    children: [
      {
        id: '9',
        name: 'log',
        type: 'directory',
        modifiedTime: '2024-01-15 10:30:00',
        permissions: 'drwxr-xr-x',
        path: '/var/log',
        children: [
          {
            id: '10',
            name: 'system.log',
            type: 'file',
            size: 512000,
            modifiedTime: '2024-01-15 10:30:00',
            permissions: '-rw-r--r--',
            path: '/var/log/system.log'
          }
        ]
      }
    ]
  }
];

interface FileManagerPanelProps {
  webshells: WebShell[];
  selectedWebShell: WebShell | null;
  onWebShellChange: (webshell: WebShell | null) => void;
  onFileSelect: (file: FileItem) => void;
  onExecuteCommand?: (command: string, webshell: WebShell | null) => void;
  isCollapsed?: boolean; // 新增：Splitter是否收起
}

// 目录标签页接口
interface DirectoryTab {
  key: string;
  label: string;
  path: string;
  files: FileItem[];
  fileStats: {
    total: number;
    directories: number;
    files: number;
  };
  currentPage: number;
  pageSize: number;
  selectedWebShellId?: number;
}

const FileManagerPanel: React.FC<FileManagerPanelProps> = ({
  webshells,
  selectedWebShell,
  onWebShellChange,
  onFileSelect,
  onExecuteCommand,
  isCollapsed = false
}) => {
  const [fileTree, setFileTree] = useState<FileItem[]>([]);
  const [directoryTabs, setDirectoryTabs] = useState<DirectoryTab[]>([]);
  const [activeTab, setActiveTab] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [fileToDelete, setFileToDelete] = useState<FileItem | null>(null);
  const [selectedPath, setSelectedPath] = useState<string>('/');
  
  // 获取当前活动Tab的状态
  const getCurrentTab = (): DirectoryTab | undefined => {
    return directoryTabs.find(tab => tab.key === activeTab);
  };
  
  // 更新Tab状态的辅助函数
  const updateTabState = (tabKey: string, updates: Partial<DirectoryTab>) => {
    setDirectoryTabs(prev => prev.map(tab => 
      tab.key === tabKey ? { ...tab, ...updates } : tab
    ));
  };

  // 分页处理函数
  const getPaginatedFiles = (files: FileItem[], page: number, size: number) => {
    const startIndex = (page - 1) * size;
    const endIndex = startIndex + size;
    return files.slice(startIndex, endIndex);
  };

  // 处理分页变化
  const handlePageChange = (page: number, size?: number) => {
    const currentTab = getCurrentTab();
    if (currentTab) {
      updateTabState(activeTab, { 
        currentPage: page,
        ...(size && size !== currentTab.pageSize && { pageSize: size })
      });
    }
  };

  // 重置分页到第一页
  const resetPagination = () => {
    updateTabState(activeTab, { currentPage: 1 });
  };

  // 从WebShell获取文件列表
  const fetchFilesFromWebShell = async (webshellId: number, path: string): Promise<FileItem[]> => {
    try {
      console.log('调用API获取文件列表:', {
        webshellId,
        path,
        apiUrl: `/api/webshell/${webshellId}/files?path=${encodeURIComponent(path)}`
      });
      
      const response: FileListResponse = await getFileList(webshellId, path);
      
      console.log('API响应:', response);
      
      const files = response.fileList.map((file: FileInfo, index: number) => ({
        id: `${webshellId}-${path}-${index}`,
        name: file.name,
        type: (file.isDirectory ? 'directory' : 'file') as 'directory' | 'file',
        size: file.type === 'file' ? parseInt(file.size) || 0 : undefined,
        modifiedTime: file.lastModified,
        permissions: file.permissions,
        path: path === '/' ? `/${file.name}` : `${path}/${file.name}`,
      }));

      // 添加当前目录和父目录导航
      const navigationFiles: FileItem[] = [];
      
      // 添加当前目录 "."
      navigationFiles.push({
        id: `${webshellId}-${path}-current`,
        name: '.',
        type: 'directory',
        modifiedTime: new Date().toISOString(),
        permissions: 'drwxr-xr-x',
        path: path,
      });
      
      // 如果不是根目录，添加父目录 ".."
      if (path !== '/') {
        const parentPath = path.split('/').slice(0, -1).join('/') || '/';
        navigationFiles.push({
          id: `${webshellId}-${path}-parent`,
          name: '..',
          type: 'directory',
          modifiedTime: new Date().toISOString(),
          permissions: 'drwxr-xr-x',
          path: parentPath,
        });
      }
      
      // 将导航文件放在最前面
      const allFiles = [...navigationFiles, ...files];
      
      console.log('转换后的文件列表:', allFiles);
      
      return allFiles;
    } catch (error) {
      console.error('Failed to fetch files from WebShell:', error);
      message.error('获取文件列表失败');
      return [];
    }
  };

  // 从WebShell加载文件列表
  const loadFilesFromWebShell = async (path: string) => {
    if (!selectedWebShell) {
      console.warn('loadFilesFromWebShell: 没有选择WebShell');
      return;
    }
    
    console.log('loadFilesFromWebShell: 开始加载文件', {
      webshellId: selectedWebShell.id,
      path: path,
      webshellName: selectedWebShell.name
    });
    
    setLoading(true);
    try {
      const files = await fetchFilesFromWebShell(selectedWebShell.id!, path);
      
      // 更新文件统计信息（排除导航目录 . 和 ..）
      const realFiles = files.filter(f => f.name !== '.' && f.name !== '..');
      const stats = {
        total: realFiles.length,
        directories: realFiles.filter(f => f.type === 'directory').length,
        files: realFiles.filter(f => f.type === 'file').length,
      };
      
      // 更新当前标签页的文件列表、路径、统计信息和分页
      updateTabState(activeTab, { 
        files: files, 
        path: path, 
        fileStats: stats,
        currentPage: 1 // 重置到第一页
      });
      
      // 更新目录树结构（只显示目录）
      const directories = buildDirectoryTree(files, path);
      if (path === '/') {
        setFileTree(directories);
      }
      
      console.log('loadFilesFromWebShell: 成功加载文件', {
        path: path,
        fileCount: files.length,
        stats: stats
      });
    } catch (error) {
      console.error('loadFilesFromWebShell: 加载失败', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // 构建目录树结构（只包含目录，排除导航目录）
  const buildDirectoryTree = (files: FileItem[], currentPath: string): FileItem[] => {
    const directories: FileItem[] = [];
    
    files.forEach(file => {
      if (file.type === 'directory' && file.name !== '.' && file.name !== '..') {
        directories.push({
          ...file,
          children: [] // 初始为空，点击时动态加载
        });
      }
    });
    
    return directories;
  };

  // 根据路径获取文件列表（兼容旧代码）
  const getFilesByPath = (path: string): FileItem[] => {
    const currentTab = directoryTabs.find(tab => tab.path === path);
    return currentTab ? currentTab.files : [];
  };

  // 处理目录树选择
  const handleTreeSelect = async (selectedKeys: React.Key[], info: any) => {
    console.log('目录树选择事件:', { selectedKeys, info });
    
    if (selectedKeys.length > 0) {
      const selectedPath = selectedKeys[0] as string;
      console.log('选择的路径:', selectedPath);
      
      setSelectedPath(selectedPath);
      
      // 直接加载文件列表，不创建新标签页
      await loadFilesFromWebShell(selectedPath);
    }
  };

  // 处理WebShell选择变化
  const handleWebShellChange = async (webshellId: number) => {
    console.log('WebShell选择变化:', {
      webshellId: webshellId,
      availableWebShells: webshells?.map(w => ({ id: w.id, name: w.name })) || []
    });
    
    const ws = webshells?.find(w => w.id === webshellId);
    console.log('找到的WebShell:', ws ? { id: ws.id, name: ws.name, webshellType: ws.webshellType } : null);
    
    onWebShellChange(ws || null);
    
    if (ws) {
      console.log('开始加载WebShell数据:', ws.name);
      setLoading(true);
      try {
        // 重置当前路径到根目录
        setSelectedPath('/');
        
        // 检查是否已存在该WebShell的标签页
        const existingTabKey = findExistingWebShellTab(ws.id!);
        if (existingTabKey) {
          // 如果存在，切换到该标签页
          setActiveTab(existingTabKey);
          message.info(`切换到已存在的WebShell标签页: ${ws.name}`);
        } else {
          // 如果不存在，创建新的标签页
          addOrSwitchToWebShellTab(ws);
        }
        
        // 加载根目录的文件列表
        await loadFilesFromWebShell('/');
        
        console.log('WebShell数据加载完成');
      } catch (error) {
        console.error('Failed to load WebShell data:', error);
        message.error(`加载WebShell数据失败: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        setLoading(false);
      }
    } else {
      console.warn('未找到指定的WebShell');
      // 清空数据
      setFileTree([]);
      setDirectoryTabs([]);
      setActiveTab('');
      setSelectedPath('/');
    }
  };

  // 刷新当前目录
  const handleRefresh = async () => {
    if (!selectedWebShell) {
      message.warning('请先选择一个WebShell');
      return;
    }
    
    try {
      await loadFilesFromWebShell(selectedPath);
      message.success('刷新成功');
    } catch (error) {
      console.error('刷新失败:', error);
      message.error(`刷新失败: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  // 删除文件/文件夹
  const deleteFile = (file: FileItem) => {
    setFileToDelete(file);
    setDeleteModalVisible(true);
  };

  // 确认删除
  const confirmDelete = () => {
    if (!fileToDelete) return;

    // 从文件树中删除
    const removeFromTree = (nodes: FileItem[], targetId: string): FileItem[] => {
      return nodes.filter(node => {
        if (node.id === targetId) {
          return false; // 删除匹配的节点
        }
        if (node.children) {
          node.children = removeFromTree(node.children, targetId);
        }
        return true; // 保留其他节点
      });
    };

    setFileTree(prev => removeFromTree(prev, fileToDelete.id));

    // 更新所有标签页的文件列表和统计信息
    setDirectoryTabs(prev => prev.map(tab => {
      const updatedFiles = removeFromTree(tab.files, fileToDelete.id);
      const realFiles = updatedFiles.filter(f => f.name !== '.' && f.name !== '..');
      const stats = {
        total: realFiles.length,
        directories: realFiles.filter(f => f.type === 'directory').length,
        files: realFiles.filter(f => f.type === 'file').length,
      };
      return {
        ...tab,
        files: updatedFiles,
        fileStats: stats
      };
    }));

    message.success(`已删除: ${fileToDelete.name}`);
    setDeleteModalVisible(false);
    setFileToDelete(null);
  };

  // 取消删除
  const cancelDelete = () => {
    setDeleteModalVisible(false);
    setFileToDelete(null);
  };

  // 智能Tab管理：检查是否已存在WebShell标签页
  const findExistingWebShellTab = (webshellId: number): string | null => {
    const tabKey = `webshell-${webshellId}`;
    return directoryTabs.find(tab => tab.key.startsWith(tabKey))?.key || null;
  };

  // 智能Tab管理：添加或切换到WebShell标签页
  const addOrSwitchToWebShellTab = (webshell: WebShell) => {
    // 移除自动切换逻辑，允许同一个WebShell多次打开
    // const existingTabKey = findExistingWebShellTab(webshell.id!);
    // 
    // if (existingTabKey) {
    //   // 如果Tab已存在，直接切换
    //   setActiveTab(existingTabKey);
    //   message.info(`切换到已存在的WebShell标签页: ${webshell.name}`);
    //   return;
    // }
    
    // 检查Tab数量限制（最多5个Tab）
    const MAX_TABS = 5;
    if (directoryTabs.length >= MAX_TABS) {
      // 关闭最旧的Tab（除了默认Tab）
      const tabsToKeep = directoryTabs.filter(tab => tab.key !== 'webshell-default');
      const oldestTab = tabsToKeep[0]; // 第一个非默认Tab是最旧的
      
      if (oldestTab) {
        const newTabs = directoryTabs.filter(tab => tab.key !== oldestTab.key);
        setDirectoryTabs(newTabs);
        message.info(`已关闭最旧的标签页: ${oldestTab.label}`);
      }
    }
    
    // 创建新的WebShell标签页，支持同一个WebShell多次打开
    const existingTabsCount = directoryTabs.filter(tab => tab.key.startsWith(`webshell-${webshell.id}`)).length;
    const tabSuffix = existingTabsCount > 0 ? ` (${existingTabsCount + 1})` : '';
    
    const newTab: DirectoryTab = {
      key: `webshell-${webshell.id}-${Date.now()}`,
      label: `WebShell: ${webshell.name}${tabSuffix}`,
      path: '/',
      files: [],
      fileStats: { total: 0, directories: 0, files: 0 },
      currentPage: 1,
      pageSize: 20,
      selectedWebShellId: webshell.id
    };
    
    setDirectoryTabs(prev => [...prev, newTab]);
    setActiveTab(newTab.key);
    message.success(`已添加新的WebShell标签页: ${webshell.name}`);
  };

  // 处理标签页编辑（添加/删除）
  const handleTabEdit = (targetKey: string | React.MouseEvent | React.KeyboardEvent, action: 'add' | 'remove') => {
    const key = typeof targetKey === 'string' ? targetKey : '';
    if (action === 'add') {
      // 添加新WebShell标签页
      if (!webshells || webshells.length === 0) {
        message.warning('没有可用的WebShell');
        return;
      }
      
      // 选择第一个可用的WebShell
      const firstWebShell = webshells?.[0];
      addOrSwitchToWebShellTab(firstWebShell);

      // 自动选择新的WebShell并加载数据
      handleWebShellChange(firstWebShell.id!);
    } else if (action === 'remove') {
      // 删除标签页
      const newTabs = directoryTabs.filter(tab => tab.key !== key);
      setDirectoryTabs(newTabs);
      
      // 如果删除的是当前活动标签页
      if (key === activeTab) {
        if (newTabs.length > 0) {
          // 如果还有其他标签页，切换到第一个
          setActiveTab(newTabs[0].key);
        } else {
          // 如果没有标签页了，设置为空字符串，显示空白页
          setActiveTab('');
        }
      }
    }
  };

  // 格式化文件大小
  const formatFileSize = (size?: number): string => {
    if (!size) return '-';
    const units = ['B', 'KB', 'MB', 'GB'];
    let unitIndex = 0;
    let fileSize = size;

    while (fileSize >= 1024 && unitIndex < units.length - 1) {
      fileSize /= 1024;
      unitIndex++;
    }

    return `${fileSize.toFixed(1)} ${units[unitIndex]}`;
  };

  // 格式化日期时间
  const formatDateTime = (time: string): string => {
    if (!time) return '-';
    
    try {
      let date: Date;
      
      // 检查是否是ISO格式（包含T和Z）
      if (time.includes('T') && time.includes('Z')) {
        date = new Date(time);
      } else {
        // 普通格式，直接解析
        date = new Date(time);
      }
      
      // 检查日期是否有效
      if (isNaN(date.getTime())) {
        return time; // 如果解析失败，返回原始字符串
      }
      
      // 格式化为 YYYY-MM-DD HH:mm:ss
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    } catch (error) {
      console.error('Date formatting error:', error);
      return time; // 如果出错，返回原始字符串
    }
  };

  // 转换树数据
  const convertToTreeData = (nodes: FileItem[]): any[] => {
    return nodes.map(node => ({
      key: node.path,
      title: (
        <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {node.type === 'directory' ? <FolderOutlined /> : <FileOutlined />}
          <span>{node.name}</span>
        </span>
      ),
      icon: node.type === 'directory' ? <FolderOutlined /> : <FileOutlined />,
      children: node.children ? convertToTreeData(node.children) : undefined,
    }));
  };

  // 文件列表列配置
  const fileColumns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: FileItem) => (
        <Space>
          {record.type === 'directory' ? <FolderOutlined /> : <FileOutlined />}
          <span>{text}</span>
        </Space>
      ),
    },
    {
      title: '大小',
      dataIndex: 'size',
      key: 'size',
      render: (size: number) => formatFileSize(size),
      width: 80,
    },
    {
      title: '修改时间',
      dataIndex: 'modifiedTime',
      key: 'modifiedTime',
      width: 120,
      render: (time: string) => formatDateTime(time), // 统一格式化日期时间
    },
    {
      title: '权限',
      dataIndex: 'permissions',
      key: 'permissions',
      width: 120,
      render: (permissions: string, record: FileItem) => {
        // 导航目录 "." 和 ".." 不显示权限
        if (record.name === '.' || record.name === '..') {
          return <span style={{ color: '#999' }}>-</span>;
        }

        const getPermissionColor = (perm: string) => {
          if (perm.startsWith('d')) return '#1890ff'; // 目录 - 蓝色
          if (perm.includes('rwx')) return '#52c41a'; // 完全权限 - 绿色
          if (perm.includes('rw')) return '#faad14'; // 读写权限 - 橙色
          if (perm.includes('r')) return '#13c2c2'; // 只读权限 - 青色
          return '#ff4d4f'; // 无权限 - 红色
        };

        const getPermissionTooltip = (perm: string) => {
          if (perm.startsWith('d')) return '目录';
          if (perm.includes('rwx')) return '完全权限 (读写执行)';
          if (perm.includes('rw')) return '读写权限';
          if (perm.includes('r')) return '只读权限';
          return '无权限';
        };

        return (
          <Tooltip title={getPermissionTooltip(permissions)}>
            <span style={{ 
              fontFamily: 'monospace', 
              fontSize: '12px',
              color: getPermissionColor(permissions),
              fontWeight: 'bold'
            }}>
              {permissions}
            </span>
          </Tooltip>
        );
      },
    },
    {
      title: '操作',
      key: 'actions',
      width: 160,
      render: (text: any, record: FileItem) => (
        <Space size="small">
          {record.type === 'file' && (
            <Tooltip title="下载">
              <Button 
                type="text" 
                icon={<DownloadOutlined />} 
                size="small"
                onClick={() => message.info(`下载文件: ${record.name}`)}
              />
            </Tooltip>
          )}
          {record.type === 'file' && (
            <Tooltip title="在终端中执行">
              <Button 
                type="text" 
                icon={<PlayCircleOutlined />} 
                size="small"
                onClick={() => {
                  if (onExecuteCommand) {
                    onExecuteCommand(`./${record.name}`, selectedWebShell);
                    message.success(`在终端中执行: ${record.name}`);
                  } else {
                    message.info(`执行文件: ${record.name}`);
                  }
                }}
              />
            </Tooltip>
          )}
          <Tooltip title="修改权限">
            <Button 
              type="text" 
              icon={<SafetyOutlined />} 
              size="small"
              onClick={() => {
                const currentPerm = record.permissions;
                message.info(`当前权限: ${currentPerm}`);
                // TODO: 实现权限修改功能
                if (onExecuteCommand) {
                  onExecuteCommand(`chmod 755 ${record.name}`, selectedWebShell);
                  message.success(`已修改权限: ${record.name}`);
                }
              }}
            />
          </Tooltip>
          <Tooltip title="删除">
            <Button 
              type="text" 
              danger
              icon={<DeleteOutlined />} 
              size="small"
              onClick={() => deleteFile(record)}
            />
          </Tooltip>
        </Space>
      ),
    },
  ];

  // 初始化根目录文件列表
  useEffect(() => {
    const rootFiles = getFilesByPath('/');
    setDirectoryTabs(prev => prev.map(tab => 
      tab.key === 'root' ? { ...tab, files: rootFiles } : tab
    ));
  }, []);

  return (
    <div className="file-manager-panel">
      <div className="file-manager-content">
        {/* 左侧目录树 */}
        <div className="file-tree-section">
          <div className="tree-controls">
            <Select
              placeholder="选择WebShell"
              value={selectedWebShell?.id}
              onChange={handleWebShellChange}
              style={{ flex: 1 }}
              size="small"
              optionLabelProp="label"
              dropdownStyle={{ fontSize: '10px' }}
            >
              {webshells?.map(ws => (
                <Option key={ws.id} value={ws.id} label={ws.name.length > 14 ? `${ws.name.slice(0, 12)}...` : ws.name}>
                  {ws.name}
                </Option>
              )) || []}
            </Select>
            <Button 
              icon={<ReloadOutlined />} 
              onClick={handleRefresh}
              loading={loading}
              size="small"
              style={{ marginLeft: '8px' }}
            >
              刷新
            </Button>
          </div>
          <DirectoryTree
            treeData={convertToTreeData(fileTree)}
            onSelect={handleTreeSelect}
            selectedKeys={[selectedPath]}
            defaultExpandAll
            showIcon
            style={{ background: 'transparent' }}
          />
        </div>

        {/* 右侧文件列表 */}
        <div className="file-list-section">
          <Tabs
            type="editable-card"
            size="small"
            activeKey={activeTab}
            onChange={(key) => {
              setActiveTab(key);
              const tab = directoryTabs.find(t => t.key === key);
              if (tab) {
                setSelectedPath(tab.path);
                if (tab.selectedWebShellId && onWebShellChange) {
                  const webshell = webshells?.find(ws => ws.id === tab.selectedWebShellId);
                  if (webshell) {
                    onWebShellChange(webshell);
                  }
                }
              }
            }}
            onEdit={handleTabEdit}
            items={directoryTabs.length === 0 ? [] : directoryTabs.map(tab => {
              // 只渲染当前活动Tab的内容
              if (tab.key !== activeTab) {
                return {
                  key: tab.key,
                  label: (
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      {tab.key.startsWith('webshell-') ? <CodeOutlined /> : <FolderOutlined />}
                      {tab.label}
                    </span>
                  ),
                  closable: true,
                  children: null // 非活动Tab不渲染内容
                };
              }
              
              // 当前活动Tab渲染完整内容
              const currentTabFiles = tab.files;
              const paginatedFiles = getPaginatedFiles(currentTabFiles, tab.currentPage, tab.pageSize);
              
              return {
                key: tab.key,
                label: (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    {tab.key.startsWith('webshell-') ? <CodeOutlined /> : <FolderOutlined />}
                    {tab.label}
                  </span>
                ),
                closable: true,
                children: (
                  <div style={{ 
                    height: '100%', 
                    display: 'flex', 
                    flexDirection: 'column',
                    overflow: 'hidden'
                  }}>
                    <div className="section-header" style={{ flexShrink: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, minWidth: 0, overflow: 'hidden' }}>
                        <span className="section-title" style={{ 
                          fontSize: '12px', 
                          color: '#666', 
                          whiteSpace: 'nowrap',
                          overflow: 'visible',
                          textOverflow: 'unset',
                          flex: 1,
                          minWidth: 0
                        }}>
                          当前路径: {tab.path}
                        </span>
                      </div>
                      <Space size="small" style={{ flexShrink: 0 }}>
                        <Tag color="blue" style={{ fontSize: '11px', padding: '2px 6px' }}>总数: {tab.fileStats.total}</Tag>
                        <Tag color="green" style={{ fontSize: '11px', padding: '2px 6px' }}>目录: {tab.fileStats.directories}</Tag>
                        <Tag color="orange" style={{ fontSize: '11px', padding: '2px 6px' }}>文件: {tab.fileStats.files}</Tag>
                        <Tag color="purple" style={{ fontSize: '11px', padding: '2px 6px' }}>当前页: {tab.currentPage}</Tag>
                      </Space>
                    </div>
                    <div style={{ 
                      flex: 1, 
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column'
                    }}>
                      <Table
                        columns={fileColumns}
                        dataSource={paginatedFiles}
                        rowKey="id"
                        size="small"
                        pagination={{
                          current: tab.currentPage,
                          pageSize: tab.pageSize,
                          total: currentTabFiles.length,
                          showSizeChanger: true,
                          showQuickJumper: true,
                          showTotal: (total, range) => 
                            `第 ${range[0]}-${range[1]} 条，共 ${total} 条`,
                          pageSizeOptions: ['10', '20', '50', '100'],
                          onChange: handlePageChange,
                          onShowSizeChange: handlePageChange,
                          size: 'small',
                          style: { marginTop: '8px' }
                        }}
                        loading={loading}
                        scroll={{ y: isCollapsed ? 'calc(100vh - 110px)' : '350px' }}
                        onRow={(record) => ({
                          onDoubleClick: async () => {
                            console.log('双击文件/目录:', record);
                            
                            if (record.type === 'directory') {
                              // 双击目录时，直接切换到该目录
                              console.log('进入目录:', record.path);
                              setSelectedPath(record.path);
                              await loadFilesFromWebShell(record.path);
                              
                              // 特殊处理导航目录
                              if (record.name === '.') {
                                message.info('当前目录');
                              } else if (record.name === '..') {
                                message.info(`返回上级目录: ${record.path}`);
                              } else {
                                message.info(`进入目录: ${record.name}`);
                              }
                            } else {
                              onFileSelect(record);
                            }
                          }
                        })}
                      />
                    </div>
                  </div>
                )
              };
            })}
            style={{ height: '100%' }}
            tabBarStyle={{ margin: 0, padding: '0' }}
          />
          
          {/* 当没有Tab时显示空白页 */}
          {directoryTabs.length === 0 && (
            <div style={{ 
              height: '3000px', 
              display: 'flex', 
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#999',
              fontSize: '14px'
            }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ marginBottom: '8px' }}>
                  暂无文件浏览目录
                </div>
                <div style={{ fontSize: '12px', color: '#ccc' }}>
                  点击 + 按钮添加目录浏览
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* 确认删除对话框 */}
      <Modal
        title="确认删除"
        open={deleteModalVisible}
        onOk={confirmDelete}
        onCancel={cancelDelete}
        okText="确认删除"
        cancelText="取消"
        okButtonProps={{ danger: true }}
        centered
      >
        <div style={{ padding: '16px 0' }}>
          <p>确定要删除以下{fileToDelete?.type === 'directory' ? '文件夹' : '文件'}吗？</p>
          <div style={{ 
            background: '#f5f5f5', 
            padding: '12px', 
            borderRadius: '4px',
            margin: '12px 0'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {fileToDelete?.type === 'directory' ? <FolderOutlined /> : <FileOutlined />}
              <span style={{ fontWeight: 'bold' }}>{fileToDelete?.name}</span>
            </div>
            <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
              路径: {fileToDelete?.path}
            </div>
          </div>
          <p style={{ color: '#ff4d4f', fontSize: '12px' }}>
            ⚠️ 此操作不可撤销，请谨慎操作！
          </p>
        </div>
      </Modal>
    </div>
  );
};

export default FileManagerPanel;
