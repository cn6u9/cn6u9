import React, { useState, useRef, useEffect } from 'react';
import { Button, Space, Tabs, Dropdown, Menu, Modal } from 'antd';
import { ClearOutlined, PlusOutlined, DownOutlined } from '@ant-design/icons';
import type { WebShell } from '@/services/webshell';
import commandExecutor, { type CommandResult } from '@/services/commandExecutor';
import './TerminalPanel.less';

interface TerminalLine {
  id: number;
  content: string;
  type: 'input' | 'output' | 'error';
  timestamp: Date;
  selected?: boolean; // 添加选择状态
}

interface WebShellTab {
  key: string;
  label: string;
  webshell: WebShell | null; // 关联的WebShell对象
  lines: TerminalLine[];
  currentInput: string;
  commandHistory: string[];
  historyIndex: number;
  isExecuting: boolean;
}

interface TerminalPanelProps {
  webshells?: WebShell[];
  onExecuteExternalCommand?: (command: string, webshell: WebShell | null) => void;
}

const TerminalPanel: React.FC<TerminalPanelProps> = ({ webshells = [], onExecuteExternalCommand }) => {
  const [activeTab, setActiveTab] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false); // 选择模式状态
  const [tabs, setTabs] = useState<WebShellTab[]>([]);
  
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 获取当前活动标签页
  const getCurrentTab = () => tabs.find(tab => tab.key === activeTab) || tabs[0];
  
  // 自动滚动到底部
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [tabs, activeTab]);

  // 聚焦输入框
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  // 处理外部命令执行（从文件管理器调用）
  const executeExternalCommand = (command: string, webshell: WebShell | null) => {
    const currentTab = getCurrentTab();
    if (!currentTab) return;

    // 如果指定了WebShell，切换到对应的标签页
    if (webshell) {
      const targetTab = tabs.find(tab => tab.webshell?.id === webshell.id);
      if (targetTab) {
        setActiveTab(targetTab.key);
      }
    }

    // 执行命令
    executeCommand(command);
  };

  // 暴露executeExternalCommand方法给父组件
  useEffect(() => {
    if (onExecuteExternalCommand) {
      // 将方法绑定到全局，这样父组件可以调用
      (window as any).executeTerminalCommand = executeExternalCommand;
    }
    
    return () => {
      // 清理
      if ((window as any).executeTerminalCommand) {
        delete (window as any).executeTerminalCommand;
      }
    };
  }, [onExecuteExternalCommand, tabs, activeTab]);

  // 处理命令执行
  const executeCommand = async (command: string) => {
    const trimmedCommand = command.trim();
    if (!trimmedCommand) return;

    const currentTab = getCurrentTab();
    if (!currentTab) return;

    // 更新当前标签页的执行状态
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { ...tab, isExecuting: true }
        : tab
    ));

    // 添加到历史记录
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { 
            ...tab, 
            commandHistory: [...tab.commandHistory, trimmedCommand],
            historyIndex: -1
          }
        : tab
    ));

    // 添加输入行
    const inputLine: TerminalLine = {
      id: Date.now(),
      content: `$ ${trimmedCommand}`,
      type: 'input',
      timestamp: new Date()
    };

    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { ...tab, lines: [...tab.lines, inputLine] }
        : tab
    ));

    // 处理特殊命令（本地命令）
    if (trimmedCommand.toLowerCase() === 'clear') {
      setTabs(prev => prev.map(tab => 
        tab.key === activeTab 
          ? { ...tab, lines: [], isExecuting: false }
          : tab
      ));
      return;
    }

    // 如果有WebShell，使用真实的命令执行服务
    if (currentTab.webshell) {
      try {
        const result = await commandExecutor.executeCommand(currentTab.webshell, trimmedCommand);
        
        // 添加输出行
        const outputLine: TerminalLine = {
          id: Date.now() + 1,
          content: result.output || result.error || 'No output',
          type: result.status === '执行成功' ? 'output' : 'error',
          timestamp: new Date()
        };

        setTabs(prev => prev.map(tab => 
          tab.key === activeTab 
            ? { ...tab, lines: [...tab.lines, outputLine], isExecuting: false }
            : tab
        ));
      } catch (error) {
        // 处理执行错误
        const errorLine: TerminalLine = {
          id: Date.now() + 1,
          content: `Error: ${error instanceof Error ? error.message : String(error)}`,
          type: 'error',
          timestamp: new Date()
        };

        setTabs(prev => prev.map(tab => 
          tab.key === activeTab 
            ? { ...tab, lines: [...tab.lines, errorLine], isExecuting: false }
            : tab
        ));
      }
    } else {
      // 没有WebShell时，使用模拟命令
      setTimeout(() => {
        let output = '';
        let type: 'output' | 'error' = 'output';

        switch (trimmedCommand.toLowerCase()) {
          case 'help':
            output = `Available commands:
  help     - Show this help message
  clear    - Clear the terminal
  date     - Show current date and time
  whoami   - Show current user
  pwd      - Show current directory
  ls       - List files and directories
  echo     - Echo back the input
  version  - Show terminal version
  webshell - Show WebShell status

Note: Connect to a WebShell to execute real commands.`;
            break;
          case 'date':
            output = new Date().toString();
            break;
          case 'whoami':
            output = `ctg-user@${currentTab.label.toLowerCase()}`;
            break;
          case 'pwd':
            output = `/home/ctg-user/${currentTab.label.toLowerCase()}`;
            break;
          case 'ls':
            output = `drwxr-xr-x  2 ctg-user ctg-user 4096 Dec 15 10:30 documents
drwxr-xr-x  3 ctg-user ctg-user 4096 Dec 15 10:25 projects
-rw-r--r--  1 ctg-user ctg-user 1024 Dec 15 10:20 readme.txt
drwxr-xr-x  2 ctg-user ctg-user 4096 Dec 15 10:15 scripts`;
            break;
          case 'version':
            output = 'CTG Terminal v1.0.0 - Built with React & TypeScript';
            break;
          case 'webshell':
            output = `WebShell Status (${currentTab.label}):
  No WebShell connected
  This is a local terminal session
  Please select a WebShell to execute real commands.`;
            break;
          default:
            if (trimmedCommand.startsWith('echo ')) {
              output = trimmedCommand.substring(5);
            } else {
              output = `Command not found: ${trimmedCommand}. Type "help" for available commands.
Note: Connect to a WebShell to execute real commands.`;
              type = 'error';
            }
            break;
        }

        // 添加输出行
        const outputLine: TerminalLine = {
          id: Date.now() + 1,
          content: output,
          type,
          timestamp: new Date()
        };

        setTabs(prev => prev.map(tab => 
          tab.key === activeTab 
            ? { ...tab, lines: [...tab.lines, outputLine], isExecuting: false }
            : tab
        ));
      }, 500); // 500ms延迟模拟命令执行
    }
  };

  // 处理键盘事件
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const currentTab = getCurrentTab();
    if (!currentTab) return;

    if (e.key === 'Enter') {
      executeCommand(currentTab.currentInput);
      setTabs(prev => prev.map(tab => 
        tab.key === activeTab 
          ? { ...tab, currentInput: '' }
          : tab
      ));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (currentTab.commandHistory.length > 0) {
        const newIndex = currentTab.historyIndex === -1 ? currentTab.commandHistory.length - 1 : Math.max(0, currentTab.historyIndex - 1);
        setTabs(prev => prev.map(tab => 
          tab.key === activeTab 
            ? { 
                ...tab, 
                historyIndex: newIndex,
                currentInput: currentTab.commandHistory[newIndex]
              }
            : tab
        ));
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (currentTab.historyIndex !== -1) {
        const newIndex = currentTab.historyIndex + 1;
        if (newIndex >= currentTab.commandHistory.length) {
          setTabs(prev => prev.map(tab => 
            tab.key === activeTab 
              ? { ...tab, historyIndex: -1, currentInput: '' }
              : tab
          ));
        } else {
          setTabs(prev => prev.map(tab => 
            tab.key === activeTab 
              ? { 
                  ...tab, 
                  historyIndex: newIndex,
                  currentInput: currentTab.commandHistory[newIndex]
                }
              : tab
          ));
        }
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // 简单的自动补全
      const commands = ['help', 'clear', 'date', 'whoami', 'pwd', 'ls', 'echo', 'version', 'webshell'];
      const matches = commands.filter(cmd => cmd.startsWith(currentTab.currentInput.toLowerCase()));
      if (matches.length === 1) {
        setTabs(prev => prev.map(tab => 
          tab.key === activeTab 
            ? { ...tab, currentInput: matches[0] }
            : tab
        ));
      }
    }
  };

  // 处理输入变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { ...tab, currentInput: e.target.value, historyIndex: -1 }
        : tab
    ));
  };

  // 点击终端区域聚焦输入框
  const handleTerminalClick = (e: React.MouseEvent) => {
    // 如果点击的是终端行，不聚焦输入框
    if ((e.target as HTMLElement).closest('.terminal-line')) {
      return;
    }
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // 清空当前标签页终端
  const clearTerminal = () => {
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { ...tab, lines: [] }
        : tab
    ));
  };

  // 切换选择模式
  const toggleSelectionMode = () => {
    setSelectionMode(!selectionMode);
    // 退出选择模式时清除所有选择
    if (selectionMode) {
      setTabs(prev => prev.map(tab => 
        tab.key === activeTab 
          ? { ...tab, lines: tab.lines.map(line => ({ ...line, selected: false })) }
          : tab
      ));
    }
  };

  // 切换行的选择状态
  const toggleLineSelection = (lineId: number) => {
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { 
            ...tab, 
            lines: tab.lines.map(line => 
              line.id === lineId 
                ? { ...line, selected: !line.selected }
                : line
            )
          }
        : tab
    ));
  };

  // 删除选中的行
  const deleteSelectedLines = () => {
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { 
            ...tab, 
            lines: tab.lines.filter(line => !line.selected)
          }
        : tab
    ));
    setSelectionMode(false); // 删除后退出选择模式
  };

  // 全选/取消全选
  const toggleSelectAll = () => {
    const currentTab = getCurrentTab();
    if (!currentTab) return;
    
    const allSelected = currentTab.lines.every(line => line.selected);
    setTabs(prev => prev.map(tab => 
      tab.key === activeTab 
        ? { 
            ...tab, 
            lines: tab.lines.map(line => ({ ...line, selected: !allSelected }))
          }
        : tab
    ));
  };

  // 添加新标签页（选择WebShell）
  const addNewTab = (webshell?: WebShell) => {
    const newTabNumber = tabs.length + 1;
    const selectedWebShell = webshell || null;
    
    // 为同一个WebShell创建多个标签页时，添加序号
    let tabLabel: string;
    let tabKey: string;
    
    if (selectedWebShell) {
      // 计算该WebShell已存在的标签页数量
      const existingTabsCount = tabs.filter(tab => tab.webshell?.id === selectedWebShell.id).length;
      const tabSuffix = existingTabsCount > 0 ? ` (${existingTabsCount + 1})` : '';
      tabLabel = `${selectedWebShell.name}${tabSuffix}`;
      tabKey = `webshell-${selectedWebShell.id}-${Date.now()}`;
    } else {
      tabLabel = `WebShell-${newTabNumber}`;
      tabKey = `webshell-${newTabNumber}`;
    }
    
    const newTab: WebShellTab = {
      key: tabKey,
      label: tabLabel,
      webshell: selectedWebShell,
      lines: [
        {
          id: 1,
          content: selectedWebShell 
            ? `${selectedWebShell.name} (${selectedWebShell.url})`
            : `CTG Terminal(WebShell-${newTabNumber})`,
          type: 'output',
          timestamp: new Date()
        }
      ],
      currentInput: '',
      commandHistory: [],
      historyIndex: -1,
      isExecuting: false
    };
    
    setTabs(prev => [...prev, newTab]);
    setActiveTab(newTab.key);
    setModalVisible(false); // 关闭Modal
  };



  // 删除标签页
  const removeTab = (targetKey: string) => {
    const newTabs = tabs.filter(tab => tab.key !== targetKey);
    setTabs(newTabs);
    
    // 如果删除的是当前活动标签页
    if (targetKey === activeTab) {
      if (newTabs.length > 0) {
        // 如果还有其他标签页，切换到第一个
        setActiveTab(newTabs[0].key);
      } else {
        // 如果没有标签页了，设置为空字符串，显示空白页
        setActiveTab('');
      }
    }
  };

  const currentTab = getCurrentTab();

  return (
    <div className="terminal-panel">
      {/* 标签页 */}
      <Tabs
        type="editable-card"
        size="small"
        activeKey={activeTab}
        onChange={setActiveTab}
        onEdit={(targetKey, action) => {
          if (action === 'add') {
            // 显示WebShell选择Modal
            setModalVisible(true);
          } else if (action === 'remove') {
            removeTab(targetKey as string);
          }
        }}
        items={tabs.length === 0 ? [] : tabs.map(tab => ({
          key: tab.key,
          label: (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '0 8px' }}>
              <span>{tab.label}</span>
              <Space size="small">
                <Button 
                  icon={<ClearOutlined />}
                  size="small"
                  onClick={(e) => {
                    e.stopPropagation();
                    clearTerminal();
                  }}
                  style={{ minWidth: 'auto', padding: '0 6px' }}
                />
                <Button 
                  type={selectionMode ? 'primary' : 'default'}
                  size="small"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSelectionMode();
                  }}
                  style={{ minWidth: 'auto', padding: '0 6px' }}
                >
                  {selectionMode ? '取消选择' : '选择'}
                </Button>
                {selectionMode && (
                  <>
                    <Button 
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelectAll();
                      }}
                      style={{ minWidth: 'auto', padding: '0 6px' }}
                    >
                      全选
                    </Button>
                    <Button 
                      danger
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteSelectedLines();
                      }}
                      disabled={!tab.lines.some(line => line.selected)}
                      style={{ minWidth: 'auto', padding: '0 6px' }}
                    >
                      删除选中
                    </Button>
                  </>
                )}
              </Space>
            </div>
          ),
          closable: true,
          children: (
            <div 
              ref={terminalRef}
              className="terminal-container"
              onClick={handleTerminalClick}
              style={{ height: '100%' }}
            >
              {/* 可滚动的命令输出区域 */}
              <div className="terminal-output">
                {tab.lines.map((line) => (
                  <div 
                    key={line.id} 
                    className={`terminal-line ${line.type} ${line.selected ? 'selected' : ''}`}
                    onClick={() => selectionMode && toggleLineSelection(line.id)}
                    style={{
                      cursor: selectionMode ? 'pointer' : 'default',
                      backgroundColor: line.selected ? '#e6f7ff' : 'transparent',
                      border: 'none', // 移除边框
                      borderRadius: '4px',
                      margin: '2px 0',
                      padding: '3px 6px', // 调整内边距，上下3px，左右12px
                      transition: 'all 0.2s ease'
                    }}
                  >
                    {selectionMode && (
                      <span 
                        style={{
                          marginRight: '8px',
                          color: line.selected ? '#1890ff' : '#ccc',
                          fontSize: '12px',
                          fontWeight: 'bold'
                        }}
                      >
                        {line.selected ? '✓' : '○'}
                      </span>
                    )}
                    <span className="terminal-timestamp">
                      {line.timestamp.toLocaleTimeString()}
                    </span>
                    <span className="terminal-text">{line.content}</span>
                  </div>
                ))}
              </div>
              
              {/* 固定的输入区域 */}
              <div className="terminal-input-line">
                <span className="terminal-prompt">$ </span>
                <input
                  ref={inputRef}
                  type="text"
                  value={tab.currentInput || ''}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  className="terminal-input"
                  placeholder="Type a command..."
                  autoComplete="off"
                  spellCheck={false}
                  disabled={tab.isExecuting || false}
                />
              </div>
            </div>
          )
        }))}
        style={{ height: '100%' }}
        tabBarStyle={{ margin: 0, padding: '0' }}
      />
      
      {/* 当没有Tab时显示空白页 */}
      {tabs.length === 0 && (
        <div style={{ 
          height: '3000px', 
          display: 'flex', 
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#1e1e1e',
          color: '#00ff00',
          fontFamily: "'Cascadia Mono', 'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
          fontSize: '16px'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ marginBottom: '8px'}}>
            👻 There is no Ghost in the shell.
            </div>
            <div style={{ fontSize: '12px', color: '#666' }}>
              点击 + 按钮添加新的终端
            </div>
          </div>
        </div>
      )}
      
      {/* WebShell选择Modal */}
      <Modal
        title="选择WebShell"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={500}
        centered
      >
        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
          {/* 新建空白终端选项 */}
          <div 
            style={{ 
              padding: '12px 16px', 
              border: '1px solid #d9d9d9', 
              borderRadius: '6px', 
              marginBottom: '12px',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}
            onClick={() => addNewTab()}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#1890ff';
              e.currentTarget.style.backgroundColor = '#f0f8ff';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#d9d9d9';
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <div style={{ fontWeight: 'bold', fontSize: '14px', color: '#1890ff' }}>
              新建空白终端
            </div>
            <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
              创建一个新的空白终端会话
            </div>
          </div>
          
          {/* WebShell列表 */}
          {webshells?.map(ws => (
            <div 
              key={ws.id}
              style={{ 
                padding: '12px 16px', 
                border: '1px solid #d9d9d9', 
                borderRadius: '6px', 
                marginBottom: '12px',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              onClick={() => addNewTab(ws)}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#1890ff';
                e.currentTarget.style.backgroundColor = '#f0f8ff';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#d9d9d9';
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <div style={{ fontWeight: 'bold', fontSize: '14px' }}>
                {ws.name}
              </div>
              <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                {ws.url}
              </div>
              <div style={{ fontSize: '12px', color: '#999', marginTop: '2px' }}>
                {ws.webshellType} | {ws.status}
              </div>
            </div>
          ))}
          
          {/* 如果没有可用的WebShell */}
          {webshells?.filter(ws => !tabs.some(tab => tab.webshell?.id === ws.id)).length === 0 && (
            <div style={{ 
              textAlign: 'center', 
              padding: '20px', 
              color: '#999',
              fontSize: '14px'
            }}>
              没有可用的WebShell
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default TerminalPanel;
