import React, { useState, useRef, useEffect } from 'react';
import { Card, Typography, Space, Tag } from 'antd';
import { 
  CodeOutlined, 
  DatabaseOutlined, 
  SettingOutlined,
  InfoCircleOutlined,
  FileTextOutlined,
  DragOutlined,
  UpOutlined,
  DownOutlined,
  ConsoleSqlOutlined,
  PlayCircleOutlined
} from '@ant-design/icons';
import TerminalPanel from './TerminalPanel';
import FileManagerPanel from './FileManagerPanel';
import type { WebShell } from '@/services/webshell';

const { Title, Text, Paragraph } = Typography;

// 左侧面板内容 - 文件管理
const LeftPanelContent: React.FC<{ 
  webshells: WebShell[];
  selectedWebShell: WebShell | null;
  onWebShellChange: (webshell: WebShell | null) => void;
  onFileSelect: (file: any) => void;
  onExecuteCommand: (command: string, webshell: WebShell | null) => void;
  isCollapsed: boolean;
}> = ({ webshells, selectedWebShell, onWebShellChange, onFileSelect, onExecuteCommand, isCollapsed }) => (
  <FileManagerPanel 
    webshells={webshells}
    selectedWebShell={selectedWebShell}
    onWebShellChange={onWebShellChange}
    onFileSelect={onFileSelect}
    onExecuteCommand={onExecuteCommand}
    isCollapsed={isCollapsed}
  />
);

// 右侧面板内容 - 终端
const RightPanelContent: React.FC<{ 
  webshells?: WebShell[];
  onExecuteExternalCommand?: (command: string, webshell: WebShell | null) => void;
}> = ({ webshells = [], onExecuteExternalCommand }) => (
  <div style={{ height: '100%', background: '#fff' }}>
    <TerminalPanel 
      webshells={webshells} 
      onExecuteExternalCommand={onExecuteExternalCommand}
    />
  </div>
);

interface GlobalSplitterProps {
  webshells?: WebShell[];
}

const GlobalSplitter: React.FC<GlobalSplitterProps> = ({ webshells = [] }) => {
  const [leftWidth, setLeftWidth] = useState(35);
  const [isResizingWidth, setIsResizingWidth] = useState(false);
  const [isHidden, setIsHidden] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false); // 新增：控制是否收起
  const [selectedWebShell, setSelectedWebShell] = useState<WebShell | null>(null);
  const [rightActiveTab, setRightActiveTab] = useState('terminal'); // 右侧面板活动标签页
  const containerRef = useRef<HTMLDivElement>(null);

  // 使用flex布局，让splitter占据剩余空间

  // 由于现在使用flex布局，不再需要动态管理paddingBottom
  // 主内容区域和splitter区域通过flex自然排列

  // 处理文件选择
  const handleFileSelect = (file: any) => {
    console.log('Selected file:', file);
    // 可以在这里添加文件选择的逻辑，比如在终端中显示文件路径
  };

  // 处理命令执行（从文件管理器到终端）
  const handleExecuteCommand = (command: string, webshell: WebShell | null) => {
    // 调用终端的外部命令执行方法
    if ((window as any).executeTerminalCommand) {
      (window as any).executeTerminalCommand(command, webshell);
    }
  };

  // 保存设置到localStorage
  useEffect(() => {
    localStorage.setItem('splitterLeftWidth', leftWidth.toString());
  }, [leftWidth]);

  useEffect(() => {
    localStorage.setItem('splitterHidden', isHidden.toString());
  }, [isHidden]);

  useEffect(() => {
    localStorage.setItem('splitterCollapsed', isCollapsed.toString());
  }, [isCollapsed]);

  // 从localStorage恢复设置
  useEffect(() => {
    const savedLeftWidth = localStorage.getItem('splitterLeftWidth');
    const savedHidden = localStorage.getItem('splitterHidden');
    const savedCollapsed = localStorage.getItem('splitterCollapsed');
    
    if (savedLeftWidth) {
      setLeftWidth(parseInt(savedLeftWidth));
    }
    if (savedHidden) {
      setIsHidden(savedHidden === 'true');
    }
    if (savedCollapsed) {
      setIsCollapsed(savedCollapsed === 'true');
    }
  }, []);

  // 切换隐藏状态
  const toggleHidden = () => {
    setIsHidden(!isHidden);
  };

  // 切换收起/展开状态
  const toggleCollapsed = () => {
    const newCollapsedState = !isCollapsed;
    console.log('toggleCollapsed: 当前状态:', isCollapsed, '新状态:', newCollapsedState);
    setIsCollapsed(newCollapsedState);
    // 立即保存到localStorage
    localStorage.setItem('splitterCollapsed', newCollapsedState.toString());
    console.log('toggleCollapsed: 已保存到localStorage:', newCollapsedState);
    // 触发自定义事件，通知app.tsx状态变化
    window.dispatchEvent(new CustomEvent('splitterStateChange'));
    console.log('toggleCollapsed: 已触发自定义事件');
  };

  // 三角形点击处理 - 同时处理隐藏和收起功能
  const handleTriangleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('Triangle clicked! isHidden:', isHidden, 'isCollapsed:', isCollapsed);
    console.log('Triangle should show:', isHidden ? 'down triangle' : (isCollapsed ? 'up blue triangle' : 'up gray triangle'));
    
    // 如果当前是隐藏状态，先显示面板
    if (isHidden) {
      console.log('Showing hidden panel');
      toggleHidden();
    } else {
      // 如果当前是显示状态，则切换收起/展开
      console.log('Toggling collapsed state');
      toggleCollapsed();
    }
  };

  // 处理宽度调整
  const handleWidthMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizingWidth(true);
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    
    // 禁用页面滚动
    document.body.style.overflow = 'hidden';
  };



  const handleMouseMove = (e: MouseEvent) => {
    e.preventDefault();
    
    if (isResizingWidth && containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const newLeftWidth = ((e.clientX - containerRect.left) / containerRect.width) * 100;
      const minWidth = 20;
      const maxWidth = 70;
      
      const clampedWidth = Math.max(minWidth, Math.min(maxWidth, newLeftWidth));
      setLeftWidth(clampedWidth);
    }
  };

  const handleMouseUp = () => {
    setIsResizingWidth(false);
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    
    // 恢复页面滚动
    document.body.style.overflow = '';
  };

  useEffect(() => {
    if (isResizingWidth) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizingWidth]);

  // 组件卸载时清理状态
  useEffect(() => {
    return () => {
      // 恢复页面状态
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      document.body.style.overflow = '';
    };
  }, []);

  // 监听isCollapsed状态变化
  useEffect(() => {
    console.log('GlobalSplitter useEffect: isCollapsed changed to:', isCollapsed, 'height =', isCollapsed ? '40px' : '500px');
  }, [isCollapsed]);

  // 如果隐藏，只显示一个小的显示条
  if (isHidden) {
    return (
      <div style={{
        height: '24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#f5f5f5',
        borderTop: '1px solid #000000', // 只保留顶部细线，改为黑色
        borderLeft: 'none',
        borderRight: 'none',
        borderBottom: 'none',
        borderRadius: '0px', // 直角边角
        cursor: 'pointer',
        transition: 'all 0.2s ease',
        position: 'relative'
      }}
      onClick={toggleHidden}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = '#e6f7ff';
        e.currentTarget.style.borderTopColor = '#1890ff';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = '#f5f5f5';
        e.currentTarget.style.borderTopColor = '#000000';
      }}
      >
        {/* 显示提示文字 */}
        <span style={{
          fontSize: '12px',
          color: '#666',
          fontWeight: '500'
        }}>
          点击显示分割面板
        </span>
      </div>
    );
  }
  
  return (
    <div 
      ref={containerRef}
      style={{ 
        height: isCollapsed ? '20px' : '500px', // 收起时20px，展开时500px
        borderTop: '1px solid #d9d9d9', // 只保留顶部细线，改为灰色
        borderLeft: 'none',
        borderRight: 'none',
        borderBottom: 'none',
        borderRadius: '0px', // 直角边角
        overflow: 'visible', // 改为visible确保按钮不被裁剪
        display: 'flex',
        flexDirection: 'column',
        background: '#fff',
        position: 'relative',
        transition: 'height 0.3s ease' // 添加平滑过渡动画
      }}
    >

      {/* 收起状态 - 只显示向上三角形 */}
      {isCollapsed && (
        <div 
          onClick={toggleCollapsed}
          style={{
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#f5f5f5',
            position: 'relative',
            cursor: 'pointer'
          }}
        >
          {/* 向下三角形 - 用于展开Splitter */}
          <div
            style={{
              width: 0,
              height: 0,
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderBottom: '8px solid #1890ff', // 向下蓝色三角形
              transition: 'all 0.2s ease',
              filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))',
              zIndex: 1001,
              background: 'transparent'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderBottomColor = '#40a9ff';
              e.currentTarget.style.filter = 'drop-shadow(0 2px 4px rgba(24, 144, 255, 0.3))';
              e.currentTarget.style.transform = 'scale(1.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderBottomColor = '#1890ff';
              e.currentTarget.style.filter = 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          />
        </div>
      )}

      {/* 主要内容区域 */}
      <div style={{ 
        display: isCollapsed ? 'none' : 'flex', // 收起时隐藏
        height: '100%',
        background: '#f5f5f5'
      }}>
       {/* 左侧面板 */}
        <div style={{ 
          width: `${leftWidth}%`, 
          minWidth: '200px',
          borderRight: 'none', // 移除右边框
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <div style={{ 
            flex: 1, 
            overflow: 'auto', 
            padding: '0',
            scrollbarWidth: 'none', // 隐藏滚动条
            msOverflowStyle: 'none' // IE/Edge 隐藏滚动条
          }}>
            <LeftPanelContent 
              webshells={webshells}
              selectedWebShell={selectedWebShell}
              onWebShellChange={setSelectedWebShell}
              onFileSelect={handleFileSelect}
              onExecuteCommand={handleExecuteCommand}
              isCollapsed={isCollapsed}
            />
          </div>
        </div>
        
        {/* 垂直分割条 */}
        <div style={{
          width: '4px',
          background: isResizingWidth ? '#1890ff' : '#e8e8e8',
          cursor: 'col-resize',
          position: 'relative',
          transition: 'background-color 0.2s ease',
          userSelect: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 100
        }}
        onMouseDown={handleWidthMouseDown}
        onMouseEnter={(e) => {
          if (!isResizingWidth) {
            e.currentTarget.style.background = '#1890ff';
          }
        }}
        onMouseLeave={(e) => {
          if (!isResizingWidth) {
            e.currentTarget.style.background = '#e8e8e8';
          }
        }}
        >
          {/* 分割条装饰 - 已移除边框装饰 */}
          
          {/* 隐藏/显示/收起三角形 - 位于上边界和分割线交界处 */}
          <div
            onClick={handleTriangleClick}
            style={{
              position: 'absolute',
              top: '0px', // 三角形的底部与Splitter边框重合
              left: '50%',
              transform: 'translateX(-50%)',
              width: 0,
              height: 0,
              // 根据状态显示不同的三角形
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderBottom: isHidden ? '8px solid #666' : 'none',
              borderTop: isHidden ? 'none' : (isCollapsed ? '8px solid #1890ff' : '8px solid #666'),
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))',
              zIndex: 1001, // 确保在最上层
              background: 'transparent'
            }}
            onMouseEnter={(e) => {
              if (isHidden) {
                e.currentTarget.style.borderBottomColor = '#1890ff';
              } else {
                e.currentTarget.style.borderTopColor = '#1890ff';
              }
              e.currentTarget.style.filter = 'drop-shadow(0 2px 4px rgba(24, 144, 255, 0.3))';
              e.currentTarget.style.transform = 'translateX(-50%) scale(1.1)';
            }}
            onMouseLeave={(e) => {
              if (isHidden) {
                e.currentTarget.style.borderBottomColor = '#666';
              } else {
                e.currentTarget.style.borderTopColor = isCollapsed ? '#1890ff' : '#666';
              }
              e.currentTarget.style.filter = 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))';
              e.currentTarget.style.transform = 'translateX(-50%) scale(1)';
            }}
          />
        </div>
        
        {/* 右侧面板 */}
        <div style={{ 
          flex: 1,
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <div style={{ 
            flex: 1, 
            overflow: 'auto', 
            padding: '0',
            scrollbarWidth: 'none', // 隐藏滚动条
            msOverflowStyle: 'none' // IE/Edge 隐藏滚动条
          }}>
            <RightPanelContent 
              webshells={webshells} 
              onExecuteExternalCommand={handleExecuteCommand}
            />
          </div>
        </div>
      </div>
      
      {/* 水平分割线 - 现在在splitter内部 */}
      <div style={{
        position: 'absolute',
        top: '0',
        left: '0',
        right: '0',
        height: '1px',
        background: '#d9d9d9',
        zIndex: -1
      }}>
      </div>
    </div>
  );
};

export default GlobalSplitter;