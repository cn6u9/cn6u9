import React from 'react';
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  MinusCircleOutlined,
} from '@ant-design/icons';
import { Tag } from 'antd';
import './styles.css';

export interface StatusTagProps {
  status: string;
  showIcon?: boolean;
}

const StatusTag: React.FC<StatusTagProps> = ({ status, showIcon = true }) => {
  const config = {
    'Disabled': { text: '未启用', color: 'default', icon: <MinusCircleOutlined /> },
    'Enabled': { text: '已启用', color: 'processing', icon: <ClockCircleOutlined /> },
    'Connected': { text: '已连接', color: 'success', icon: <CheckCircleOutlined /> },
    'Disconnected': { text: '已断开', color: 'error', icon: <CloseCircleOutlined /> },
  }[status] || { text: status, color: 'default', icon: <MinusCircleOutlined /> };

  return (
    <Tag
      color={config.color}
      icon={showIcon ? config.icon : undefined}
      className={`status-tag-custom status-tag-${config.color}`}
    >
      {config.text}
    </Tag>
  );
};

export default StatusTag;
