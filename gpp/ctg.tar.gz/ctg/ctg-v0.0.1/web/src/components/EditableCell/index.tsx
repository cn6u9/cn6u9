import React, { useState, useRef, useEffect } from 'react';
import { Input, message, Tooltip } from 'antd';
import type { InputRef } from 'antd';

interface EditableCellProps {
  value: string;
  record: any;
  dataIndex: string;
  title: string;
  onSave: (record: any, dataIndex: string, value: string) => void;
  children: React.ReactNode;
}

const EditableCell: React.FC<EditableCellProps> = ({
  value,
  record,
  dataIndex,
  title,
  onSave,
  children,
  ...restProps
}) => {
  const [editing, setEditing] = useState(false);
  const [inputValue, setInputValue] = useState(value);
  const [saving, setSaving] = useState(false);

  const inputRef = useRef<InputRef>(null);

  useEffect(() => {
    if (editing) {
      inputRef.current?.focus();
    }
  }, [editing]);

  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const toggleEdit = () => {
    setEditing(!editing);
  };

  const save = async () => {
    // 防止重复调用
    if (saving) {
      return;
    }
    
    try {
      setSaving(true);
      if (inputValue !== value) {
        await onSave(record, dataIndex, inputValue);
        // 移除这里的message.success，让父组件统一处理消息显示
      }
      setEditing(false);
    } catch (errInfo) {
      message.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      save();
    } else if (e.key === 'Escape') {
      setEditing(false);
      setInputValue(value);
    }
  };

  const handleBlur = () => {
    // 延迟执行，避免与onPressEnter冲突
    setTimeout(() => {
      if (editing && !saving) {
        save();
      }
    }, 100);
  };

  let childNode = children;

  if (editing) {
    childNode = (
      <Input
        ref={inputRef}
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onPressEnter={save}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        style={{ width: '100%' }}
      />
    );
  } else {
    childNode = (
      <Tooltip title="点击编辑">
        <div
          className="editable-cell-value-wrap"
          style={{
            paddingRight: 24,
            cursor: 'pointer',
            minHeight: '22px',
            maxHeight: '22px',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            position: 'relative',
          }}
          onClick={toggleEdit}
        >
          {inputValue || '-'}
        </div>
      </Tooltip>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};

export default EditableCell;
