import { message } from 'antd';
import { executeCommand, type ExecuteCommandRequest, type WebShell } from './webshell';

// 命令执行结果接口
export interface CommandResult {
  status: string;
  output?: string;
  error?: string;
  message?: string;
  timestamp: Date;
  webshellId: number;
  command: string;
}

// 命令历史记录接口
export interface CommandHistory {
  id: number;
  command: string;
  result: string;
  timestamp: string;
  webshellId: number;
}

// 命令执行器类
class CommandExecutor {
  private commandHistory: CommandHistory[] = [];
  private listeners: ((result: CommandResult) => void)[] = [];

  /**
   * 执行命令
   * @param webshell WebShell对象
   * @param command 要执行的命令
   * @param timeout 超时时间（秒），默认30秒
   * @returns Promise<CommandResult>
   */
  async executeCommand(
    webshell: WebShell, 
    command: string, 
    timeout: number = 30
  ): Promise<CommandResult> {
    if (!webshell?.id) {
      throw new Error('WebShell ID is required');
    }

    const trimmedCommand = command.trim();
    if (!trimmedCommand) {
      throw new Error('Command cannot be empty');
    }

    try {
      const request: ExecuteCommandRequest = {
        command: trimmedCommand,
        timeout,
      };

      const result = await executeCommand(webshell.id, request);
      
      const commandResult: CommandResult = {
        status: result.status || '执行成功',
        output: result.output,
        error: result.error,
        message: result.message,
        timestamp: new Date(),
        webshellId: webshell.id,
        command: trimmedCommand,
      };

      // 添加到命令历史
      this.addToHistory(commandResult);

      // 通知监听器
      this.notifyListeners(commandResult);

      // 显示成功消息
      if (result.status === '执行成功') {
        message.success('命令执行成功');
      } else {
        message.warning(`命令执行: ${result.message}`);
      }

      return commandResult;
    } catch (error) {
      const errorResult: CommandResult = {
        status: '执行失败',
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date(),
        webshellId: webshell.id,
        command: trimmedCommand,
      };

      // 添加到命令历史
      this.addToHistory(errorResult);

      // 通知监听器
      this.notifyListeners(errorResult);

      // 显示错误消息
      message.error('命令执行失败，请重试');
      
      return errorResult;
    }
  }

  /**
   * 添加到命令历史
   */
  private addToHistory(result: CommandResult) {
    const historyItem: CommandHistory = {
      id: Date.now(),
      command: result.command,
      result: result.output || result.error || '无输出',
      timestamp: result.timestamp.toISOString(),
      webshellId: result.webshellId,
    };

    this.commandHistory.push(historyItem);

    // 限制历史记录数量，保留最近1000条
    if (this.commandHistory.length > 1000) {
      this.commandHistory = this.commandHistory.slice(-1000);
    }
  }

  /**
   * 获取命令历史
   * @param webshellId 可选的WebShell ID，用于过滤特定WebShell的历史
   * @param limit 限制返回数量，默认50条
   */
  getCommandHistory(webshellId?: number, limit: number = 50): CommandHistory[] {
    let history = this.commandHistory;

    if (webshellId) {
      history = history.filter(h => h.webshellId === webshellId);
    }

    return history.slice(-limit).reverse();
  }

  /**
   * 清空命令历史
   * @param webshellId 可选的WebShell ID，用于清空特定WebShell的历史
   */
  clearCommandHistory(webshellId?: number) {
    if (webshellId) {
      this.commandHistory = this.commandHistory.filter(h => h.webshellId !== webshellId);
    } else {
      this.commandHistory = [];
    }
  }

  /**
   * 添加结果监听器
   * @param listener 监听器函数
   */
  addListener(listener: (result: CommandResult) => void) {
    this.listeners.push(listener);
  }

  /**
   * 移除结果监听器
   * @param listener 监听器函数
   */
  removeListener(listener: (result: CommandResult) => void) {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }

  /**
   * 通知所有监听器
   */
  private notifyListeners(result: CommandResult) {
    this.listeners.forEach(listener => {
      try {
        listener(result);
      } catch (error) {
        console.error('Error in command result listener:', error);
      }
    });
  }

  /**
   * 获取所有命令历史
   */
  getAllCommandHistory(): CommandHistory[] {
    return [...this.commandHistory];
  }

  /**
   * 获取指定WebShell的最近命令
   * @param webshellId WebShell ID
   * @param limit 限制数量
   */
  getRecentCommands(webshellId: number, limit: number = 10): CommandHistory[] {
    return this.getCommandHistory(webshellId, limit);
  }
}

// 创建全局单例实例
const commandExecutor = new CommandExecutor();

export default commandExecutor;

// 导出类型
export type { CommandResult, CommandHistory };
