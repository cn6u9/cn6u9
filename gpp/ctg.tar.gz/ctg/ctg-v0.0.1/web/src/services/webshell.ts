import { request } from '@umijs/max';

// WebShell 数据类型定义
export interface WebShell {
  id?: number;
  name: string;
  scriptType: 'JSP' | 'JSPX' | 'PHP' | 'ASP' | 'ASPX' | 'Other';
  webshellType: 'Behinder' | 'Godzilla' | 'Antword' | 'Custom' | 'Other';
  url: string;
  pass: string;
  key?: string;
  crypto?: string;
  encoding?: string;
  group?: string;
  tag?: string;
  notes?: string;
  userAgent?: string;
  proxyAddress?: string;
  status?: 'Disabled' | 'Enabled' | 'Connected' | 'Disconnected';
  firstConnectTime?: string;
  lastConnectTime?: string;
  externalIP?: string;
  location?: string;
  internalIP?: string;
  hostname?: string;
  username?: string;
  createdAt?: string;
  updatedAt?: string;
}

// 命令执行请求参数
export interface ExecuteCommandRequest {
  command: string;
  timeout?: number;
}

// 命令执行响应
export interface ExecuteCommandResponse {
  id: number;
  name: string;
  command: string;
  output: string;
  exitCode: number;
  executedAt: string;
  executionTime: number;
  status: string;
  message: string;
  rawResult?: any;
}

// 连接测试响应
export interface TestConnectionResponse {
  id: number;
  name: string;
  url: string;
  status: string;
  message: string;
  testTime: number;
  output?: string;
  rawResult?: any;
}

// 命令历史记录
export interface CommandHistory {
  id: number;
  webshellID: number;
  command: string;
  output: string;
  exitCode: number;
  executedAt: string;
  executionTime: number;
}

// WebShell统计信息
export interface WebShellStats {
  total: number;
  enabled: number;
  connected: number;
  disconnected: number;
  byType: Record<string, number>;
  byScriptType: Record<string, number>;
}

// API 响应格式
export interface ApiResponse<T> {
  status: string;
  message?: string;
  data: T;
}

/**
 * 获取WebShell列表
 */
export async function getWebShellList(): Promise<WebShell[]> {
  const response = await request<ApiResponse<WebShell[]>>('/api/webshell', {
    method: 'GET',
  });
  return response.data;
}

/**
 * 根据ID获取WebShell
 */
export async function getWebShellById(id: number): Promise<WebShell> {
  const response = await request<ApiResponse<WebShell>>(`/api/webshell/${id}`, {
    method: 'GET',
  });
  return response.data;
}

/**
 * 创建WebShell
 */
export async function createWebShell(webshell: Omit<WebShell, 'id'>): Promise<WebShell> {
  const response = await request<ApiResponse<WebShell>>('/api/webshell', {
    method: 'POST',
    data: webshell,
  });
  return response.data;
}

/**
 * 更新WebShell
 */
export async function updateWebShell(id: number, webshell: Partial<WebShell>): Promise<WebShell> {
  const response = await request<ApiResponse<WebShell>>(`/api/webshell/${id}`, {
    method: 'PUT',
    data: webshell,
  });
  return response.data;
}

/**
 * 删除WebShell
 */
export async function deleteWebShell(id: number): Promise<void> {
  await request(`/api/webshell/${id}`, {
    method: 'DELETE',
  });
}

/**
 * 测试WebShell连接
 */
export async function testConnection(id: number): Promise<TestConnectionResponse> {
  const response = await request<ApiResponse<TestConnectionResponse>>(`/api/webshell/${id}/test`, {
    method: 'POST',
  });
  return response.data;
}

/**
 * 执行WebShell命令
 */
export async function executeCommand(
  id: number,
  commandRequest: ExecuteCommandRequest,
): Promise<ExecuteCommandResponse> {
  const response = await request<ApiResponse<ExecuteCommandResponse>>(`/api/webshell/${id}/execute`, {
    method: 'POST',
    data: commandRequest,
  });
  return response.data;
}

/**
 * 获取命令历史记录
 */
export async function getCommandHistory(
  id: number,
  limit: number = 50,
  offset: number = 0,
): Promise<CommandHistory[]> {
  const response = await request<ApiResponse<CommandHistory[]>>(`/api/webshell/${id}/history`, {
    method: 'GET',
    params: { limit, offset },
  });
  return response.data;
}

/**
 * 获取WebShell统计信息
 */
export async function getWebShellStats(): Promise<WebShellStats> {
  const response = await request<ApiResponse<WebShellStats>>('/api/webshell/stats', {
    method: 'GET',
  });
  return response.data;
}

// 基础信息响应
export interface BasicInfoResponse {
  id: number;
  name: string;
  url: string;
  status: string;
  message: string;
  infoTime: number;
  systemInfo?: any;
  currentDirectory?: any;
  fileSystemInfo?: any;
}

// 文件信息
export interface FileInfo {
  name: string;
  type: string;
  size: string;
  lastModified: string;
  permissions: string;
  isDirectory: boolean;
}

// 文件列表响应
export interface FileListResponse {
  path: string;
  fileList: FileInfo[];
  count: number;
}

/**
 * 获取WebShell基础信息
 */
export async function getBasicInfo(id: number): Promise<BasicInfoResponse> {
  const response = await request<ApiResponse<BasicInfoResponse>>(`/api/webshell/${id}/basic_info`, {
    method: 'POST',
  });
  return response.data;
}

/**
 * 获取WebShell文件列表
 */
export async function getFileList(id: number, path: string = '/'): Promise<FileListResponse> {
  const response = await request<ApiResponse<FileListResponse>>(`/api/webshell/${id}/files`, {
    method: 'GET',
    params: { path },
  });
  return response.data;
}
