#!/usr/bin/env node

/**
 * 配置同步脚本
 * 从后端获取配置并更新前端环境变量
 */

const fs = require('fs');
const path = require('path');

// 配置路径
const ENV_CONFIG_PATH = path.join(__dirname, '../config/env.ts');
const BACKEND_CONFIG_URL = 'http://127.0.0.1:1225/uDVHAREj/config';

async function getBackendConfig() {
  try {
    console.log('🔄 正在从后端获取配置...');
    const response = await fetch(BACKEND_CONFIG_URL);
    
    if (response.ok) {
      const result = await response.json();
      if (result.success && result.data) {
        console.log('✅ 成功获取后端配置');
        return result.data;
      }
    }
    
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  } catch (error) {
    console.warn('⚠️  无法获取后端配置，使用默认值:', error.message);
    return null;
  }
}

function updateEnvConfig(config) {
  const basePath = config?.base_path || '/uDVHAREj';
  const backendUrl = config ? `http://${config.ip}:${config.port}` : 'http://127.0.0.1:1225';
  
  const envConfig = `/**
 * 环境变量配置
 * 此文件由 sync-config.js 脚本自动生成
 * 请勿手动修改，如需修改请运行 npm run sync-config
 */

// 从环境变量获取配置，如果没有则使用默认值
export const API_CONFIG = {
  // 后端服务地址
  BACKEND_URL: process.env.BACKEND_URL || '${backendUrl}',
  
  // API基础路径 - 从环境变量获取，如果没有则使用默认值
  BASE_PATH: process.env.API_BASE_PATH || '${basePath}',
  
  // 代理配置
  PROXY_TARGET: process.env.PROXY_TARGET || '${backendUrl}',
};

// 生成完整的API URL
export const getApiUrl = (endpoint: string = '') => {
  return \`\${API_CONFIG.BACKEND_URL}\${API_CONFIG.BASE_PATH}\${endpoint}\`;
};

// 生成代理路径重写规则
export const getProxyRewrite = () => {
  return { '^/api': API_CONFIG.BASE_PATH };
};
`;

  fs.writeFileSync(ENV_CONFIG_PATH, envConfig, 'utf8');
  console.log(`✅ 环境配置已更新:`);
  console.log(`   - 后端地址: ${backendUrl}`);
  console.log(`   - 基础路径: ${basePath}`);
}

function createEnvFile() {
  const envPath = path.join(__dirname, '../.env.local');
  const envContent = `# 前端环境变量配置
# 此文件由 sync-config.js 脚本自动生成

# 后端服务地址
BACKEND_URL=http://127.0.0.1:1225

# API基础路径
API_BASE_PATH=/uDVHAREj

# 代理目标地址
PROXY_TARGET=http://127.0.0.1:1225
`;

  fs.writeFileSync(envPath, envContent, 'utf8');
  console.log('✅ .env.local 文件已创建');
}

async function main() {
  console.log('🚀 开始同步配置...');
  
  try {
    // 获取后端配置
    const config = await getBackendConfig();
    
    // 更新环境配置
    updateEnvConfig(config);
    
    // 创建环境变量文件
    createEnvFile();
    
    console.log('🎉 配置同步完成！');
    console.log('💡 提示: 如果后端配置发生变化，请重新运行此脚本');
    
  } catch (error) {
    console.error('❌ 配置同步失败:', error.message);
    process.exit(1);
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  main();
}

module.exports = { getBackendConfig, updateEnvConfig, createEnvFile };
