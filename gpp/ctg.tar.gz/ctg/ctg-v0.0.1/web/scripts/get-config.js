#!/usr/bin/env node

/**
 * 获取后端配置并更新前端代理配置的脚本
 * 在开发前运行此脚本来同步配置
 */

const fs = require('fs');
const path = require('path');

// 后端配置URL
const BACKEND_CONFIG_URL = 'http://127.0.0.1:1225/config';
const PROXY_CONFIG_PATH = path.join(__dirname, '../config/proxy.ts');

async function getBackendConfig() {
  try {
    const response = await fetch(BACKEND_CONFIG_URL);
    if (response.ok) {
      const config = await response.json();
      return config.base_path || '/uDVHAREj';
    }
  } catch (error) {
    console.warn('无法获取后端配置，使用默认值:', error.message);
  }
  return '/uDVHAREj'; // 默认值
}

function updateProxyConfig(basePath) {
  const proxyConfig = `/**
 * @name 代理的配置
 * @see 在生产环境 代理是无法生效的，所以这里没有生产环境的配置
 * -------------------------------
 * The agent cannot take effect in the production environment
 * so there is no configuration of the production environment
 * For details, please see
 * https://pro.ant.design/docs/deploy
 *
 * @doc https://umijs.org/docs/guides/proxy
 */

// 此文件由 get-config.js 脚本自动生成
// 请勿手动修改，如需修改请运行 npm run sync-config

export default {
  dev: {
    '/api/': {
      target: 'http://127.0.0.1:1225',
      changeOrigin: true,
      pathRewrite: { '^/api': '${basePath}' },
    },
  },
};
`;

  fs.writeFileSync(PROXY_CONFIG_PATH, proxyConfig, 'utf8');
  console.log(`✅ 代理配置已更新，base_path: ${basePath}`);
}

async function main() {
  console.log('🔄 正在获取后端配置...');
  const basePath = await getBackendConfig();
  updateProxyConfig(basePath);
  console.log('🎉 配置同步完成！');
}

// 如果直接运行此脚本
if (require.main === module) {
  main().catch(console.error);
}

module.exports = { getBackendConfig, updateProxyConfig };
