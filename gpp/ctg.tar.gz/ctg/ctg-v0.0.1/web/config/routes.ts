export default [
  // 临时注释掉用户登录页面
  // {
  //   path: '/user',
  //   layout: false,
  //   routes: [{ name: '登录', path: '/user/login', component: './User/Login' }],
  // },  
  
  // 临时注释掉Dashboard页面
  // { path: '/welcome', name: 'Dashboard', icon: 'DashboardFilled', component: './Welcome' },
  
  // 临时注释掉客户端管理页面
  // {
  //   path: '/admin',
  //   name: '客户端管理',
  //   icon: 'RobotFilled',
  //   access: 'canAdmin',
  //   routes: [
  //     { path: '/admin', redirect: '/admin/sub-page' },
  //     { path: '/admin/sub-page', name: '二级管理页', component: './Admin' },
  //   ],
  // },
  
  // 临时注释掉其他管理页面
  // { name: '监听管理', icon: 'CustomerServiceFilled', path: '/list', component: './TableList' },
  
  // 只保留WebShell管理页面
  { name: 'WebShell管理', icon: 'CodeOutlined', path: '/webshell', component: './WebShell' },

  // 临时注释掉其他功能页面
  // { name: '客户端生成', icon: 'CodeFilled', path: '/list', component: './TableList' },
  // { name: '插件管理', icon: 'ProductFilled', path: '/list', component: './TableList' },
  // { name: '隧道管理', icon: 'MergeFilled', path: '/list', component: './TableList' },
  // { name: '系统设置', icon: 'ToolFilled', path: '/list', component: './TableList' },

  // 将根路径重定向到WebShell页面
  { path: '/', redirect: '/webshell' },
  
  // 临时注释掉404页面
  // { path: '*', layout: false, component: './404' },
  
  // 将所有未匹配的路径重定向到WebShell页面
  { path: '*', redirect: '/webshell' },
];
