/**
 * 环境变量配置
 * 根据后端配置动态生成
 */

// 从环境变量获取配置，如果没有则使用默认值
export const API_CONFIG = {
  // 后端服务地址
  BACKEND_URL: process.env.BACKEND_URL || 'http://127.0.0.1:1225',
  
  // API基础路径 - 从环境变量获取，如果没有则使用默认值
  BASE_PATH: process.env.API_BASE_PATH || '/uDVHAREj',
  
  // 代理配置
  PROXY_TARGET: process.env.PROXY_TARGET || 'http://127.0.0.1:1225',
};

// 生成完整的API URL
export const getApiUrl = (endpoint: string = '') => {
  return `${API_CONFIG.BACKEND_URL}${API_CONFIG.BASE_PATH}${endpoint}`;
};

// 生成代理路径重写规则
export const getProxyRewrite = () => {
  return { '^/api': API_CONFIG.BASE_PATH };
};
