import { Request, Response } from 'express';
import moment from 'moment';
import { parse } from 'url';

// mock tableListDataSource
const genList = (current: number, pageSize: number) => {
  const tableListDataSource: API.RuleListItem[] = [];

  for (let i = 0; i < pageSize; i += 1) {
    const index = (current - 1) * 10 + i;
    tableListDataSource.push({
      key: index,
      disabled: i % 6 === 0,
      href: 'https://ant.design',
      avatar: [
        'https://gw.alipayobjects.com/zos/rmsportal/eeHMaZBwmTvLdIwMfBpg.png',
        'https://gw.alipayobjects.com/zos/rmsportal/udxAbMEhpwthVVcjLXik.png',
      ][i % 2],
      callNo: Math.floor(Math.random() * 1000),
      status: Math.floor(Math.random() * 10) % 4,
      updatedAt: moment().format('YYYY-MM-DD'),
      createdAt: moment().format('YYYY-MM-DD'),
      progress: Math.ceil(Math.random() * 100),
      os: ['windows', 'mac', 'linux', 'windows10', 'windows11'][i % 5], // 添加操作系统字段
      id: `HOST-${String(index).padStart(6, '0')}`, // 主机唯一标识
      externalIp: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`, // 外网IP
      internalIp: `10.0.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`, // 内网IP
      architecture: ['x86_64', 'arm64', 'i386', 'amd64'][i % 4], // 架构
      url: `https://host-${index}.example.com`, // URL
      hostname: `host-${index}.example.com`, // 主机名
      process: ['nginx', 'apache', 'mysql', 'redis', 'node'][i % 5], // 进程
      username: ['admin', 'user', 'root', 'guest'][i % 4], // 用户名
      language: ['zh-CN', 'en-US', 'ja-JP', 'ko-KR'][i % 4], // 语言
      heartbeatInterval: Math.floor(Math.random() * 60) + 30, // 心跳间隔（30-90秒）
      onlineTime: moment().subtract(Math.floor(Math.random() * 30), 'days').format('YYYY-MM-DD HH:mm:ss'), // 上线时间
      webshellType: ['behinder', 'godzilla', 'custom'][i % 3], // Webshell类型
      password: `pass_${Math.random().toString(36).substr(2, 8)}`, // 密码
      secretKey: i % 3 === 1 ? `key_${Math.random().toString(36).substr(2, 12)}` : undefined, // 密钥（仅Godzilla有）
      slogan: `标语${index}`, // 标语
      content: `内容${index}`, // 内容
      proxyAddress: i % 4 === 0 ? `proxy_${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}:${Math.floor(Math.random() * 65535)}` : undefined, // 代理地址
      category: ['Web服务器', '数据库服务器', '应用服务器', '文件服务器'][i % 4], // 分类
      tag: ['重要', '测试', '生产', '开发'][i % 4], // 标签
      customHeaders: i % 3 === 0 ? '{"User-Agent": "CustomAgent", "X-Forwarded-For": "127.0.0.1"}' : undefined, // 自定义请求头
      remark: `主机${index}的备注信息`, // 备注
    });
  }
  tableListDataSource.reverse();
  return tableListDataSource;
};

let tableListDataSource = genList(1, 100);

function getRule(req: Request, res: Response, u: string) {
  let realUrl = u;
  if (!realUrl || Object.prototype.toString.call(realUrl) !== '[object String]') {
    realUrl = req.url;
  }
  const { current = 1, pageSize = 10 } = req.query;
  const params = parse(realUrl, true).query as unknown as API.PageParams &
    API.RuleListItem & {
      sorter: any;
      filter: any;
    };

  let dataSource = [...tableListDataSource];
  
  // 先进行排序
  if (params.sorter) {
    try {
      const sorter = JSON.parse(params.sorter);
      dataSource = dataSource.sort((prev, next) => {
        const keys = Object.keys(sorter);
        if (keys.length === 0) return 0;
        
        const key = keys[0]; // 只处理第一个排序字段
        const order = sorter[key];
        
        let prevValue = (prev as any)[key];
        let nextValue = (next as any)[key];
        
        // 处理不同类型的字段
        if (typeof prevValue === 'number' && typeof nextValue === 'number') {
          if (order === 'descend') {
            return nextValue - prevValue;
          } else {
            return prevValue - nextValue;
          }
        } else if (typeof prevValue === 'string' && typeof nextValue === 'string') {
          if (order === 'descend') {
            return nextValue.localeCompare(prevValue);
          } else {
            return prevValue.localeCompare(nextValue);
          }
        }
        return 0;
      });
    } catch (error) {
      console.error('排序参数解析错误:', error);
    }
  }
  
  // 再进行分页
  const startIndex = ((current as number) - 1) * (pageSize as number);
  const endIndex = startIndex + (pageSize as number);
  dataSource = dataSource.slice(startIndex, endIndex);

  if (params.filter) {
    const filter = JSON.parse(params.filter as any) as {
      [key: string]: string[];
    };
    if (Object.keys(filter).length > 0) {
      dataSource = dataSource.filter((item) => {
        return (Object.keys(filter) as Array<keyof API.RuleListItem>).some((key) => {
          if (!filter[key]) {
            return true;
          }
          if (filter[key].includes(`${item[key]}`)) {
            return true;
          }
          return false;
        });
      });
    }
  }

  if (params.name) {
    dataSource = dataSource.filter((data) => data?.name?.includes(params.name || ''));
  }
  
  const result = {
    data: dataSource,
    total: tableListDataSource.length,
    success: true,
    pageSize: parseInt(`${pageSize}`, 10),
    current: parseInt(`${current}`, 10),
  };

  return res.json(result);
}

function postRule(req: Request, res: Response, u: string, b: Request) {
  let realUrl = u;
  if (!realUrl || Object.prototype.toString.call(realUrl) !== '[object String]') {
    realUrl = req.url;
  }

  const body = (b && b.body) || req.body;
  const { method, name, desc, key } = body;

  switch (method) {
    /* eslint no-case-declarations:0 */
    case 'delete':
      tableListDataSource = tableListDataSource.filter((item) => key.indexOf(item.key) === -1);
      break;
    case 'post':
      (() => {
        const i = Math.ceil(Math.random() * 10000);
        const newRule: API.RuleListItem = {
          key: tableListDataSource.length,
          href: 'https://ant.design',
          avatar: [
            'https://gw.alipayobjects.com/zos/rmsportal/eeHMaZBwmTvLdIwMfBpg.png',
            'https://gw.alipayobjects.com/zos/rmsportal/udxAbMEhpwthVVcjLXik.png',
          ][i % 2],
          name,
          owner: '曲丽丽',
          desc,
          callNo: Math.floor(Math.random() * 1000),
          status: Math.floor(Math.random() * 10) % 2,
          updatedAt: moment().format('YYYY-MM-DD'),
          createdAt: moment().format('YYYY-MM-DD'),
          progress: Math.ceil(Math.random() * 100),
        };
        tableListDataSource.unshift(newRule);
        return res.json(newRule);
      })();
      return;

    case 'update':
      (() => {
        let newRule = {};
        tableListDataSource = tableListDataSource.map((item) => {
          if (item.key === key) {
            newRule = { ...item, desc, name };
            return { ...item, desc, name };
          }
          return item;
        });
        return res.json(newRule);
      })();
      return;
    default:
      break;
  }

  const result = {
    list: tableListDataSource,
    pagination: {
      total: tableListDataSource.length,
    },
  };

  res.json(result);
}

export default {
  'GET /api/rule': getRule,
  'POST /api/rule': postRule,
};