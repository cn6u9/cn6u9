# CTG Docker 构建和运行

## 快速开始

### Windows
```cmd
# 构建Docker镜像
docker\build.bat build

# 运行容器
docker\build.bat run

# 查看日志
docker\build.bat logs

# 停止容器
docker\build.bat stop
```

### Linux/macOS
```bash
# 给脚本执行权限
chmod +x docker/build.sh

# 构建Docker镜像
./docker/build.sh build

# 运行容器
./docker/build.sh run

# 查看日志
./docker/build.sh logs

# 停止容器
./docker/build.sh stop
```

## 访问应用

- **地址**: http://localhost:8080
- **用户名**: admin_RKXqIK
- **密码**: inYyGlldU32Q

## 镜像交付

构建完成后，镜像标签为：
- `ctg:latest` - 最新版本
- `ctg:YYYYMMDD_HHMMSS` - 带时间戳的版本

可以使用以下命令导出镜像：
```bash
# 导出镜像
docker save ctg:latest -o ctg-latest.tar

# 在目标机器导入镜像
docker load -i ctg-latest.tar
```

## 可用命令

| 命令 | 说明 |
|------|------|
| `build` | 构建Docker镜像 |
| `run` | 运行容器 |
| `stop` | 停止容器 |
| `restart` | 重启容器 |
| `logs` | 查看日志 |
| `clean` | 清理Docker资源 |
| `help` | 显示帮助信息 |
