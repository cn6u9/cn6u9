# CTG 项目部署指南

## 概述

CTG项目包含Go后端API和React前端，本文档介绍如何将两者打包成一个制品并进行部署。

## 打包方式

### 1. 使用Docker（推荐）

#### 构建镜像
```bash
# 构建Docker镜像
docker build -t ctg:latest .

# 或者使用Makefile
make docker-build
```

#### 运行容器
```bash
# 运行容器
docker run -d -p 8080:8080 --name ctg-container ctg:latest

# 或者使用Makefile
make docker-run

# 或者使用Docker Compose
docker-compose up -d
```

### 2. 使用构建脚本

#### Linux/macOS
```bash
# 给脚本执行权限
chmod +x build.sh

# 运行构建脚本
./build.sh
```

#### Windows
```cmd
# 运行批处理脚本
build.bat
```

### 3. 使用Makefile
```bash
# 查看可用命令
make help

# 构建项目
make build

# 清理构建目录
make clean

# 安装依赖
make deps
```

## 制品结构

构建完成后，制品包含以下文件：

```
ctg_YYYYMMDD_HHMMSS.tar.gz
├── ctg-api          # 后端服务程序
├── ctg.conf         # 配置文件
├── wsm/             # WebShell模块
├── web/             # 前端静态文件
├── database/        # 数据库目录
├── start.sh         # 启动脚本
└── README.md        # 说明文档
```

## 部署步骤

### 1. 解压制品
```bash
tar -xzf ctg_YYYYMMDD_HHMMSS.tar.gz
cd ctg_YYYYMMDD_HHMMSS
```

### 2. 配置环境
```bash
# 编辑配置文件
vim ctg.conf

# 确保配置文件中的端口和路径设置正确
```

### 3. 启动服务
```bash
# 使用启动脚本
./start.sh

# 或者直接运行
./ctg-api
```

### 4. 验证部署
```bash
# 检查服务状态
curl http://localhost:8080/health

# 访问前端页面
open http://localhost:8080
```

## 环境要求

### 系统要求
- Linux/Windows/macOS
- 至少1GB可用内存
- 至少100MB可用磁盘空间

### 依赖要求
- SQLite 3.x
- 网络端口8080可用

### Docker环境
- Docker 20.10+
- Docker Compose 2.0+

## 配置说明

### 主要配置项
- `port`: 服务监听端口
- `base_path`: API基础路径
- `domain_name`: 域名设置
- `ip`: 监听IP地址

### 环境变量
- `GIN_MODE`: Gin运行模式（debug/release）
- `TZ`: 时区设置

## 监控和维护

### 日志查看
```bash
# 查看容器日志
docker logs ctg-container

# 查看应用日志
tail -f logs/ctg.log
```

### 健康检查
```bash
# 检查服务健康状态
curl http://localhost:8080/health
```

### 备份和恢复
```bash
# 备份数据库
cp database/ctg.db backup/ctg_$(date +%Y%m%d).db

# 恢复数据库
cp backup/ctg_YYYYMMDD.db database/ctg.db
```

## 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   # 检查端口占用
   netstat -tlnp | grep 8080
   
   # 修改配置文件中的端口
   vim ctg.conf
   ```

2. **权限问题**
   ```bash
   # 给执行文件添加权限
   chmod +x ctg-api start.sh
   ```

3. **数据库连接失败**
   ```bash
   # 检查SQLite安装
   sqlite3 --version
   
   # 检查数据库文件权限
   ls -la database/
   ```

### 日志分析
```bash
# 查看错误日志
grep ERROR logs/ctg.log

# 查看访问日志
grep "HTTP" logs/ctg.log
```

## 性能优化

### 系统优化
- 调整文件描述符限制
- 优化内存分配
- 启用TCP优化

### 应用优化
- 启用Gzip压缩
- 配置静态文件缓存
- 优化数据库查询

## 安全建议

1. 修改默认配置
2. 启用HTTPS
3. 配置防火墙规则
4. 定期更新依赖
5. 监控异常访问

## 联系支持

如遇到问题，请提供以下信息：
- 错误日志
- 系统环境
- 部署方式
- 复现步骤
